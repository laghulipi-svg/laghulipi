// Root startup file for Hostinger hPanel Node.js Application Loader
import "./dist/server.js";
