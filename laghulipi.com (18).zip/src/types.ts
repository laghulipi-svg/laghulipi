export interface UpdateItem {
  id: string;
  textEn: string;
  textGu: string;
  date: string;
  pdfUrl?: string; // uploaded files path
}

export interface WordItem {
  id: string;
  wordEn: string;
  wordGu: string;
  phraseEn: string;
  phraseGu: string;
  audioUrl?: string;
  category?: "words" | "symbol" | "phrases" | "dual";
}

export interface ParagraphItem {
  id: string;
  titleEn: string;
  titleGu: string;
  topicEn: string;
  topicGu: string;
  speed: number; // 60, 75, 90, 100, 120
  narrator: string;
  transcript: string;
  audioUrl?: string;
}

export interface BookItem {
  id: string;
  titleEn: string;
  titleGu: string;
  authorEn: string;
  authorGu: string;
  descriptionEn: string;
  descriptionGu: string;
  price: number; // 0 for free
  coverUrl?: string;
  fileUrl?: string;
}

export interface DirectoryItem {
  id: string;
  name: string;
  designation: string;
  department: string;
  landline: string;
  mobile: string;
  batchYear?: string; // for secretaries only
  district?: string; // for collectors and ddos
}

export interface UtilityPage {
  id: string; // 1 to 5
  titleEn: string;
  titleGu: string;
  embedCode: string;
}

export interface TeamMember {
  id: string;
  nameEn: string;
  nameGu: string;
  roleEn: string;
  roleGu: string;
  orgEn: string;
  orgGu: string;
  photoUrl: string;
}

export interface PillarItem {
  id: string;
  titleEn: string;
  titleGu: string;
  descEn: string;
  descGu: string;
  iconName: string;
}

export interface SocialLink {
  id: string;
  platform: 'facebook' | 'twitter' | 'youtube' | 'instagram' | 'linkedin';
  url: string;
}

export interface QuickLink {
  id: string;
  nameEn: string;
  nameGu: string;
  url: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  action: string;
  details: string;
}

export interface UserItem {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  createdAt: string;
}

export interface HomeContent {
  welcomeTitleEn: string;
  welcomeTitleGu: string;
  welcomeTextEn: string;
  welcomeTextGu: string;
  overviewHeadingEn: string;
  overviewHeadingGu: string;
  overviewContentEn: string;
  overviewContentGu: string;
  objectivesHeadingEn: string;
  objectivesHeadingGu: string;
  objectivesEn: string[];
  objectivesGu: string[];
  bentoCards: {
    id: string;
    titleEn: string;
    titleGu: string;
    descEn: string;
    descGu: string;
  }[];
}

export interface HeaderSettings {
  logoUrl: string;
  titleEn: string;
  titleGu: string;
  taglineEn: string;
  taglineGu: string;
  logoSize?: number; // width/height in px, e.g. 80, 96, 120
  headerBg?: string; // background style/color, e.g., gradient css or hex
  headerTextColor?: string; // text color, e.g., #ffffff
  menuBg?: string; // menu background style/color
  menuTextColor?: string; // menu text color
}

export interface FooterSettings {
  addressEn: string;
  addressGu: string;
  mobile: string;
  email: string;
}

export interface DownloadItem {
  id: string;
  titleEn: string;
  titleGu: string;
  category: "photo" | "audio" | "video" | "pdf" | "other";
  fileUrl: string;
  fileSize?: string;
  dateAdded?: string;
  descriptionEn?: string;
  descriptionGu?: string;
}

export interface DatabaseState {
  updates: UpdateItem[];
  words: WordItem[];
  paragraphs: ParagraphItem[];
  books: BookItem[];
  downloads: DownloadItem[];
  directories: {
    secretaries: DirectoryItem[];
    stenographers: DirectoryItem[];
    collectors: DirectoryItem[];
    ddos: DirectoryItem[];
  };
  utilities: UtilityPage[];
  aboutUs: {
    missionEn: string;
    missionGu: string;
    pillars: PillarItem[];
    team: TeamMember[];
  };
  footer: FooterSettings;
  socialLinks: SocialLink[];
  quickLinks: QuickLink[];
  homeContent: HomeContent;
  header: HeaderSettings;
  users: UserItem[];
  auditLogs: AuditLogItem[];
  siteVisitors: number;
}
