import React, { useState } from "react";
import { DatabaseState, HomeContent } from "../types";
import { Award, BookOpen, Clock, FileText, ChevronRight, Sparkles, BookCheck, ShieldCheck, Users } from "lucide-react";

interface HomeViewProps {
  lang: "en" | "gu";
  db: DatabaseState;
  setView: (v: string) => void;
  setDictationTab: (tab: "words" | "paragraphs") => void;
}

export default function HomeView({ lang, db, setView, setDictationTab }: HomeViewProps) {
  const content = db.homeContent;

  const cardsIconMap: Record<string, React.ReactNode> = {
    bc1: <Clock className="w-6 h-6" />,
    bc2: <BookOpen className="w-6 h-6" />,
    bc3: <Users className="w-6 h-6" />,
    bc4: <FileText className="w-6 h-6" />
  };

  const getObjectiveIcon = (index: number) => {
    switch (index) {
      case 0: return <Clock className="w-5 h-5 text-sky-600 dark:text-sky-400 shrink-0 mt-0.5" />;
      case 1: return <BookCheck className="w-5 h-5 text-cyan-600 dark:text-cyan-400 shrink-0 mt-0.5" />;
      case 2: return <ShieldCheck className="w-5 h-5 text-sky-600 dark:text-sky-400 shrink-0 mt-0.5" />;
      default: return <Sparkles className="w-5 h-5 text-cyan-600 dark:text-cyan-400 shrink-0 mt-0.5" />;
    }
  };

  const getBentoCardStyles = (id: string) => {
    switch (id) {
      case "bc1": // Dictation
        return {
          cardBg: "bg-gradient-to-br from-indigo-500/10 via-purple-500/5 to-white dark:bg-slate-900 dark:bg-none border-indigo-200/50 hover:border-indigo-400 hover:shadow-indigo-100/40 dark:border-indigo-900/50 dark:hover:border-indigo-600",
          iconBg: "bg-indigo-600 text-white shadow-lg shadow-indigo-100 dark:shadow-none",
          titleColor: "text-indigo-900 dark:text-indigo-200",
          descColor: "text-indigo-805/80 dark:text-slate-400"
        };
      case "bc2": // Library
        return {
          cardBg: "bg-gradient-to-br from-sky-500/10 via-teal-500/5 to-white dark:bg-slate-900 dark:bg-none border-sky-200/50 hover:border-sky-400 hover:shadow-sky-100/40 dark:border-sky-900/50 dark:hover:border-sky-600",
          iconBg: "bg-sky-600 text-white shadow-lg shadow-sky-100 dark:shadow-none",
          titleColor: "text-sky-900 dark:text-sky-200",
          descColor: "text-sky-805/80 dark:text-slate-400"
        };
      case "bc3": // Directory
        return {
          cardBg: "bg-gradient-to-br from-emerald-500/10 via-teal-500/5 to-white dark:bg-slate-900 dark:bg-none border-emerald-200/50 hover:border-emerald-400 hover:shadow-emerald-100/40 dark:border-emerald-900/50 dark:hover:border-emerald-600",
          iconBg: "bg-emerald-600 text-white shadow-lg shadow-emerald-100 dark:shadow-none",
          titleColor: "text-emerald-900 dark:text-emerald-200",
          descColor: "text-emerald-805/80 dark:text-slate-400"
        };
      default: // bc4 - Utilities
        return {
          cardBg: "bg-gradient-to-br from-pink-550/10 via-rose-500/5 to-white dark:bg-slate-900 dark:bg-none border-[#fb7185]/30 hover:border-[#f43f5e] hover:shadow-rose-105/20 dark:border-rose-955/40 dark:hover:border-rose-600",
          iconBg: "bg-rose-600 text-white shadow-lg shadow-rose-200 dark:shadow-none",
          titleColor: "text-rose-900 dark:text-rose-200",
          descColor: "text-rose-805/80 dark:text-slate-400"
        };
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Dynamic Welcome Hero Section (Selected Element - Styled Colourful Pastel Royal Blue and Indigo) */}
      <div className="relative overflow-hidden rounded-3xl p-8 md:p-12 mb-6 bg-gradient-to-br from-[#eff6ff] via-[#e0e7ff] to-[#dbeafe] dark:bg-slate-900 dark:bg-none text-slate-800 dark:text-white shadow-xl shadow-[#3b82f6]/10 dark:shadow-none border border-[#bfdbfe]/60 dark:border-[#312e81]/70">
        <div className="absolute top-0 right-0 p-8 opacity-15 pointer-events-none">
          <BookOpen className="w-64 h-64 text-[#2563eb] dark:text-[#818cf8]" />
        </div>
        <div className="relative max-w-3xl space-y-4">
          <h1 className="text-3xl md:text-5xl font-bold font-serif-literata text-[#1e3a8a] dark:text-[#e0e7ff] leading-tight tracking-tight">
            {lang === "en" ? content.welcomeTitleEn : content.welcomeTitleGu}
          </h1>
          <p className="text-base md:text-lg text-slate-700 dark:text-slate-300 leading-relaxed max-w-2xl">
            {lang === "en" ? content.welcomeTextEn : content.welcomeTextGu}
          </p>
          <div className="flex flex-wrap gap-4 pt-4">
            <button
              onClick={() => {
                setView("dictation");
                setDictationTab("paragraphs");
              }}
              className="px-6 py-3 bg-[#1e40af] hover:bg-[#1d4ed8] text-white font-bold rounded-xl shadow-lg shadow-[#1e40af]/30 dark:shadow-none transition-all flex items-center gap-2 cursor-pointer text-xs md:text-sm"
            >
              <span>{lang === "en" ? "Start Shorthand Practice" : "શ્રુતલેખન પ્રેક્ટિસ શરૂ કરો"}</span>
              <ChevronRight className="w-4 h-4 text-white" />
            </button>
            <button
              onClick={() => setView("library")}
              className="px-6 py-3 bg-white hover:bg-[#eff6ff] dark:bg-slate-800 dark:hover:bg-slate-700 text-[#1e40af] dark:text-[#818cf8] border border-[#bfdbfe] dark:border-[#312e81] font-semibold rounded-xl transition-all cursor-pointer text-xs md:text-sm"
            >
              {lang === "en" ? "SortHand Library" : "લઘુલિપિ લાઇબ્રેરી "}
            </button>
          </div>
        </div>
      </div>

      {/* Bento Cards Grid (Selected Elements 3-6 - Styled Dynamic & Colourful) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {content.bentoCards.map((card, i) => {
          const colors = getBentoCardStyles(card.id);
          return (
            <div
              key={card.id}
              onClick={() => {
                if (card.id === "bc1") {
                  setView("dictation");
                  setDictationTab("paragraphs");
                } else if (card.id === "bc2") {
                  setView("library");
                } else if (card.id === "bc3") {
                  setView("directory");
                } else {
                  setView("utilities");
                }
              }}
              className={`group relative rounded-2xl p-6 border hover:shadow-xl hover:translate-y-[-2px] transition-all duration-300 cursor-pointer ${colors.cardBg}`}
            >
              <div className={`p-3 rounded-xl w-fit mb-4 group-hover:scale-110 transition-transform ${colors.iconBg}`}>
                {cardsIconMap[card.id] || <Sparkles className="w-6 h-6" />}
              </div>
              <h3 className={`text-lg font-bold mb-2 ${colors.titleColor}`}>
                {lang === "en" ? card.titleEn : card.titleGu}
              </h3>
              <p className={`text-xs md:text-sm leading-relaxed ${colors.descColor}`}>
                {lang === "en" ? card.descEn : card.descGu}
              </p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-4">
        {/* Platform Overview (Selected Element 2 - Styled Pastel Royal Blue and Indigo) */}
        <div className="rounded-2xl bg-gradient-to-br from-[#eff6ff]/70 via-white to-[#e0e7ff]/40 dark:bg-slate-900 dark:bg-none p-6 space-y-4 border border-[#bfdbfe]/60 dark:border-[#312e81]/60 shadow-md">
          <div className="flex items-center gap-2 border-b border-blue-100/80 dark:border-indigo-950 pb-3">
            <Award className="w-5 h-5 text-[#2563eb] dark:text-[#818cf8]" />
            <h2 className="text-xl font-bold font-serif-literata text-[#1e3a8a] dark:text-[#e0e7ff] tracking-tight uppercase">
              {lang === "en" ? content.overviewHeadingEn : content.overviewHeadingGu}
            </h2>
          </div>
          <p className="text-slate-750 dark:text-slate-300 leading-relaxed text-sm md:text-base">
            {lang === "en" ? content.overviewContentEn : content.overviewContentGu}
          </p>
          <div className="p-4 bg-orange-500/5 dark:bg-amber-500/10 border border-orange-500/20 rounded-xl">
            <p className="text-xs text-orange-850 dark:text-amber-300 leading-relaxed font-sans">
              <strong>{lang === "en" ? "Did You Know?" : "શું તમે જાણો છો?"}</strong>{" "}
              {lang === "en" 
                ? "Speed, accuracy, and concentration are essential aspects to master shorthand.."
                : "લઘુલિપિમાં પ્રાવિણ્ય મેળવવા માટે ઝડપ, ચોકસાઈ અને એકાગ્રતા આવશ્યક પાસા છે."}
            </p>
          </div>
        </div>

        {/* Platform Objectives (Selected Element 3 - Styled Pastel Royal Blue and Indigo) */}
        <div className="rounded-2xl bg-gradient-to-br from-[#edf2ff]/70 via-white to-[#eff6ff]/40 dark:bg-slate-900 dark:bg-none p-6 space-y-4 border border-[#c7d2fe]/60 dark:border-[#312e81]/60 shadow-md">
          <div className="flex items-center gap-2 border-b border-indigo-100/80 dark:border-indigo-950 pb-3">
            <Sparkles className="w-5 h-5 text-[#4f46e5] dark:text-[#818cf8]" />
            <h2 className="text-xl font-bold font-serif-literata text-[#1e3a8a] dark:text-[#e0e7ff] tracking-tight uppercase">
              {lang === "en" ? content.objectivesHeadingEn : content.objectivesHeadingGu}
            </h2>
          </div>
          <div className="space-y-4">
            {(lang === "en" ? content.objectivesEn : content.objectivesGu).map((obj, i) => (
              <div key={i} className="flex gap-3 items-start">
                <div className="mt-0.5">
                  {getObjectiveIcon(i)}
                </div>
                <p className="text-sm text-slate-750 dark:text-slate-300 leading-relaxed font-sans">
                  {obj}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Shorthand Vision Board */}
      <div className="rounded-2xl bg-gradient-to-br from-indigo-500/10 via-purple-500/5 to-white dark:bg-slate-900 border border-indigo-100 dark:border-indigo-950/60 p-8 overflow-hidden relative shadow-lg shadow-indigo-100/30 dark:shadow-none">
        <div className="absolute inset-0 opacity-5 dark:opacity-10 bg-[radial-gradient(#4f46e5_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="relative flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="space-y-2 text-center md:text-left">
            <p className="text-indigo-600 dark:text-indigo-400 text-xs font-bold uppercase tracking-wider">
              {lang === "en" ? "COACHING AND INSIGHTS" : "કોચિંગ અને આંતરદૃષ્ટિ"}
            </p>
            <h3 className="text-2xl font-serif-literata font-bold text-indigo-950 dark:text-white">
              {lang === "en" ? "“ShortHand” a Key to Success" : "“લઘુલેખન” સફળતાની ચાવી"}
            </h3>
            <p className="text-slate-600 dark:text-slate-300 text-sm max-w-xl leading-relaxed">
              {lang === "en"
                ? "Enhance your dictation capability across standard speed brackets from 60 WPM to 120 WPM narrator modules."
                : "60 WPM થી 120 WPM સુધીના સ્પીડ બ્રેકેટ્સ સાથે ઓડિયો દ્વારા તમારી ક્ષમતામાં સુધારો કરો."}
            </p>
          </div>
          <div className="flex gap-4 shrink-0">
            <button
              onClick={() => {
                setView("dictation");
                setDictationTab("words");
              }}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-100 dark:shadow-none transition-all cursor-pointer"
            >
              {lang === "en" ? "Learn Words" : "શબ્દો શીખો"}
            </button>
            <button
              onClick={() => setView("about")}
              className="px-5 py-2.5 bg-white hover:bg-indigo-50/50 dark:bg-slate-800 dark:hover:bg-slate-700 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-900/50 rounded-xl text-sm font-semibold transition cursor-pointer"
            >
              {lang === "en" ? "About Authors" : "લેખકો વિશે"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
