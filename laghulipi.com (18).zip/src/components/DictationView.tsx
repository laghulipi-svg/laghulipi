import React, { useState, useRef, useEffect } from "react";
import { DatabaseState, ParagraphItem, WordItem } from "../types";
import {
  Play,
  Pause,
  FileCheck,
  Eye,
  EyeOff,
  Sparkles,
  Volume2,
  Search,
  RotateCcw,
  ShieldAlert,
  Plus,
  Trash2,
  Edit,
  Upload,
  X,
  Check,
  ChevronRight,
  Loader2,
  VolumeX,
} from "lucide-react";

interface DictationViewProps {
  lang: "en" | "gu";
  db: DatabaseState;
  activeTab: "words" | "paragraphs";
  setActiveTab: (tab: "words" | "paragraphs") => void;
  currentUser?: any;
  onSaveDB?: (newState: DatabaseState, action: string) => Promise<void>;
}

export default function DictationView({
  lang,
  db,
  activeTab,
  setActiveTab,
  currentUser,
  onSaveDB,
}: DictationViewProps) {
  const isAdmin = currentUser !== null;

  // Visual/Interactive filters
  const [selectedLang, setSelectedLang] = useState<"en" | "gu">(lang);
  const [selectedCategory, setSelectedCategory] = useState<"words" | "symbol" | "phrases" | "dual">("words");
  const [speedFilter, setSpeedFilter] = useState<number | "All">("All");
  const [searchWord, setSearchWord] = useState("");
  const [selectedParaId, setSelectedParaId] = useState<string>("");

  // Playback states
  const [wordPlaying, setWordPlaying] = useState<string | null>(null);
  const [paraPlaying, setParaPlaying] = useState<string | null>(null);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [showTranscripts, setShowTranscripts] = useState<Record<string, boolean>>({});

  // Gemini evaluation states
  const [userTranscripts, setUserTranscripts] = useState<Record<string, string>>({});
  const [evaluating, setEvaluating] = useState<Record<string, boolean>>({});
  const [evalResults, setEvalResults] = useState<Record<string, any>>({});
  const [evalError, setEvalError] = useState<string | null>(null);

  // File uploading proxy feedback state
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);

  // Form Management states (Modals)
  const [isWordModalOpen, setIsWordModalOpen] = useState(false);
  const [wordForm, setWordForm] = useState<{
    id?: string;
    wordEn: string;
    wordGu: string;
    phraseEn: string;
    phraseGu: string;
    audioUrl: string;
    category: "words" | "symbol" | "phrases" | "dual";
  }>({
    wordEn: "",
    wordGu: "",
    phraseEn: "",
    phraseGu: "",
    audioUrl: "",
    category: "words",
  });

  const [isParaModalOpen, setIsParaModalOpen] = useState(false);
  const [paraForm, setParaForm] = useState<{
    id?: string;
    titleEn: string;
    titleGu: string;
    topicEn: string;
    topicGu: string;
    speed: number;
    narrator: string;
    transcript: string;
    audioUrl: string;
  }>({
    titleEn: "",
    titleGu: "",
    topicEn: "",
    topicGu: "",
    speed: 80,
    narrator: "",
    transcript: "",
    audioUrl: "",
  });

  const audioRefs = useRef<Record<string, HTMLAudioElement | null>>({});

  // Clean play speed changes
  useEffect(() => {
    Object.keys(audioRefs.current).forEach((id) => {
      const audio = audioRefs.current[id];
      if (audio) {
        audio.playbackRate = playbackSpeed;
      }
    });
  }, [playbackSpeed]);

  // Set the default selected paragraph when items list or speed changes
  const paragraphsList = db.paragraphs || [];
  const currentFilteredParas = [...paragraphsList]
    .filter((p) => speedFilter === "All" || p.speed === speedFilter)
    .sort((a, b) => {
      const nameA = (lang === "en" ? a.titleEn : a.titleGu) || "";
      const nameB = (lang === "en" ? b.titleEn : b.titleGu) || "";
      return nameA.localeCompare(nameB, lang === "gu" ? "gu" : "en");
    });

  useEffect(() => {
    if (currentFilteredParas.length > 0) {
      // Keep selected or pick first in current list
      const stillValid = currentFilteredParas.some((p) => p.id === selectedParaId);
      if (!stillValid) {
        setSelectedParaId(currentFilteredParas[0].id);
      }
    } else {
      setSelectedParaId("");
    }
  }, [speedFilter, paragraphsList, lang]);

  // Protect Copy-Paste, Selection and Right Click inside the audio player or text areas
  useEffect(() => {
    const preventActions = (e: Event) => {
      e.preventDefault();
      alert(
        lang === "en"
          ? "PROTECTED CONTENT: Copying, downloading, printing, or screenshotting is strictly prohibited."
          : "સંરક્ષિત સામગ્રી: કૉપિ કરવા, ડાઉનલોડ કરવા, પ્રિન્ટ કરવા અથવા સ્ક્રીનશોટ લેવાની સખત મનાઈ છે."
      );
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        (e.ctrlKey || e.metaKey) &&
        ["c", "p", "u", "s", "x"].includes(e.key.toLowerCase())
      ) {
        e.preventDefault();
        preventActions(e);
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    document.addEventListener("copy", preventActions);
    document.addEventListener("contextmenu", handleContextMenu);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("copy", preventActions);
      document.removeEventListener("contextmenu", handleContextMenu);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [lang]);

  // Helper dynamic matching for Word Categories
  const getWordCategory = (item: WordItem): "words" | "symbol" | "phrases" | "dual" => {
    if (item.category) return item.category;
    const isPhrase = item.wordEn.includes(" ") || (item.phraseEn.toLowerCase().includes(item.wordEn.toLowerCase()) && item.wordEn.split(" ").length > 1);
    if (isPhrase) return "phrases";
    if (item.wordEn.includes("/") || item.wordEn.includes(",")) return "dual";
    return "words";
  };

  // Web Speak Fallback trigger for audio
  const playTTS = (text: string, lCode: string) => {
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lCode;
      utterance.rate = 0.85;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("Speech Synthesis fallback error:", e);
    }
  };

  const handleWordPlay = (item: WordItem) => {
    if (item.audioUrl) {
      if (wordPlaying === item.id) {
        const audio = audioRefs.current[item.id];
        if (audio) {
          audio.pause();
          setWordPlaying(null);
        }
      } else {
        if (wordPlaying) {
          const prevAudio = audioRefs.current[wordPlaying];
          if (prevAudio) prevAudio.pause();
        }
        setWordPlaying(item.id);
        const audio = new Audio(item.audioUrl);
        audioRefs.current[item.id] = audio;
        audio.play().catch(() => {
          // Fallback to TTS if block/invalid url
          playTTS(selectedLang === "en" ? item.wordEn : item.wordGu, selectedLang === "en" ? "en-US" : "gu-IN");
        });
        audio.onended = () => setWordPlaying(null);
      }
    } else {
      setWordPlaying(item.id);
      // Play word + sample phrase via TTS
      const textToSpeak = selectedLang === "en" 
        ? `${item.wordEn}. ${item.phraseEn}` 
        : `${item.wordGu}. ${item.phraseGu}`;
      const langCode = selectedLang === "en" ? "en-US" : "gu-IN";
      playTTS(textToSpeak, langCode);
      setTimeout(() => setWordPlaying(null), 3000);
    }
  };

  const handleParaPlay = (para: ParagraphItem) => {
    const id = para.id;
    const audioUrl = para.audioUrl;

    if (!audioUrl) {
      alert(
        lang === "en"
          ? "No audio file has been uploaded for this paragraph yet."
          : "આ ફકરા માટે હજી સુધી કોઈ ઓડિયો ફાઇલ અપલોડ કરવામાં આવી નથી."
      );
      return;
    }

    if (paraPlaying === id) {
      const audio = audioRefs.current[id];
      if (audio) {
        audio.pause();
        setParaPlaying(null);
      }
    } else {
      if (paraPlaying) {
        const activeAudio = audioRefs.current[paraPlaying];
        if (activeAudio) activeAudio.pause();
      }
      setParaPlaying(id);

      let audio = audioRefs.current[id];
      if (!audio) {
        audio = new Audio(audioUrl);
        audio.playbackRate = playbackSpeed;
        audioRefs.current[id] = audio;
      }
      audio.play().catch((err) => {
        alert("Audio failed to load from: " + audioUrl);
        setParaPlaying(null);
      });
      audio.onended = () => {
        setParaPlaying(null);
      };
    }
  };

  const toggleTranscript = (id: string) => {
    setShowTranscripts((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Submit typed Shorthand to Backend server for analysis
  const evaluateTranscript = async (para: ParagraphItem) => {
    const typedText = userTranscripts[para.id];
    if (!typedText || typedText.trim().length === 0) {
      alert(
        lang === "en"
          ? "Please type your transcribed shorthand outline in the textbox before evaluating."
          : "કૃપા કરીને મૂલ્યાંકન કરતા પહેલા તમારું લખેલું લઘુલેખન ટેક્સ્ટ બોક્સમાં લખો."
      );
      return;
    }

    setEvaluating((prev) => ({ ...prev, [para.id]: true }));
    setEvalError(null);

    try {
      const response = await fetch("/api/dictation/evaluate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userTranscript: typedText,
          paragraphId: para.id,
          speed: para.speed,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to evaluate transcript from cloud Gemini endpoint.");
      }

      const result = await response.json();
      setEvalResults((prev) => ({ ...prev, [para.id]: result }));
    } catch (err: any) {
      console.error(err);
      setEvalError(err.message || "Failed to contact Shorthand evaluation coach.");
    } finally {
      setEvaluating((prev) => ({ ...prev, [para.id]: false }));
    }
  };

  // Spreadsheet/API file attachment proxy uploader
  const handleUploadFile = async (e: React.ChangeEvent<HTMLInputElement>, fieldName: "word" | "para") => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadProgress(lang === "en" ? "Uploading track..." : "ઓડિયો અપલોડ થઈ રહ્યો છે...");
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) throw new Error("Upload response was bad.");

      const data = await res.json();
      if (fieldName === "word") {
        setWordForm((prev) => ({ ...prev, audioUrl: data.fileUrl }));
      } else {
        setParaForm((prev) => ({ ...prev, audioUrl: data.fileUrl }));
      }
      setUploadProgress(lang === "en" ? "Upload successful!" : "અપલોડ સફળ થયું!");
      setTimeout(() => setUploadProgress(null), 2500);
    } catch (err) {
      setUploadProgress(null);
      alert(lang === "en" ? "Failed to upload audio track." : "ઓડિયો ટ્રેક અપલોડ કરવામાં નિષ્ફળતા.");
    }
  };

  // --- CRUD DB SAVE ACTIONS ---
  const saveWordFlow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onSaveDB) return;

    try {
      let updatedWordsList = [...(db.words || [])];
      
      if (wordForm.id) {
        // Edit flow
        updatedWordsList = updatedWordsList.map((w) =>
          w.id === wordForm.id ? (wordForm as WordItem) : w
        );
      } else {
        // Add flow
        const brandWord: WordItem = {
          ...wordForm,
          id: `w_${Date.now()}`,
        };
        updatedWordsList.push(brandWord);
      }

      const updatedDb: DatabaseState = {
        ...db,
        words: updatedWordsList,
      };

      await onSaveDB(
        updatedDb,
        wordForm.id
          ? `Modified Word/Outline specification: ${wordForm.wordEn}`
          : `Created Shorthand Outline entry: ${wordForm.wordEn}`
      );

      setIsWordModalOpen(false);
      resetWordForm();
    } catch (err) {
      alert("Error saving word details.");
    }
  };

  const deleteWordFlow = async (word: WordItem) => {
    if (!onSaveDB) return;
    const confirmMsg = lang === "en"
      ? `Are you sure you want to permanently delete outlines for "${word.wordEn}"?`
      : `શું તમે "${word.wordEn}" માટે શોર્ટહેન્ડ ડેટા કાયમ માટે કાઢી નાખવા માંગો છો?`;
    
    if (window.confirm(confirmMsg)) {
      const updatedDb: DatabaseState = {
        ...db,
        words: (db.words || []).filter((w) => w.id !== word.id),
      };
      await onSaveDB(updatedDb, `Deleted Shorthand Outline row: ${word.wordEn}`);
    }
  };

  const saveParaFlow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onSaveDB) return;

    try {
      let updatedParas = [...(db.paragraphs || [])];
      if (paraForm.id) {
        // Edit
        updatedParas = updatedParas.map((p) =>
          p.id === paraForm.id ? (paraForm as ParagraphItem) : p
        );
      } else {
        // Add
        const brandPara: ParagraphItem = {
          ...paraForm,
          id: `p_${Date.now()}`,
        };
        updatedParas.push(brandPara);
      }

      const updatedDb: DatabaseState = {
        ...db,
        paragraphs: updatedParas,
      };

      await onSaveDB(
        updatedDb,
        paraForm.id
          ? `Updated Dictation paragraph metrics: ${paraForm.titleEn}`
          : `Added new Dictation Practice paragraph: ${paraForm.titleEn}`
      );

      setIsParaModalOpen(false);
      resetParaForm();
    } catch (err) {
      alert("Error saving paragraph metrics.");
    }
  };

  const deleteParaFlow = async (para: ParagraphItem) => {
    if (!onSaveDB) return;
    const confirmMsg = lang === "en"
      ? `Are you sure you want to permanently delete dictation drill "${para.titleEn}"?`
      : `શું તમે ખરેખર "${para.titleEn}" પ્રેક્ટિસ ડ્રીલ કાયમ માટે કાઢી નાખવા માંગો છો?`;

    if (window.confirm(confirmMsg)) {
      const updatedDb: DatabaseState = {
        ...db,
        paragraphs: (db.paragraphs || []).filter((p) => p.id !== para.id),
      };
      await onSaveDB(updatedDb, `Deleted Shorthand dictation item: ${para.titleEn}`);
    }
  };

  const resetWordForm = () => {
    setWordForm({
      wordEn: "",
      wordGu: "",
      phraseEn: "",
      phraseGu: "",
      audioUrl: "",
      category: "words",
    });
  };

  const resetParaForm = () => {
    setParaForm({
      titleEn: "",
      titleGu: "",
      topicEn: "",
      topicGu: "",
      speed: 80,
      narrator: "",
      transcript: "",
      audioUrl: "",
    });
  };

  // Filtering for UI tables
  const displayedWordRows = (db.words || []).filter((item) => {
    const cat = getWordCategory(item);
    if (cat !== selectedCategory) return false;

    if (!searchWord) return true;
    const query = searchWord.toLowerCase();
    return (
      item.wordEn.toLowerCase().includes(query) ||
      item.wordGu.includes(query) ||
      item.phraseEn.toLowerCase().includes(query) ||
      item.phraseGu.includes(query)
    );
  });

  const activeSelectedPara = (db.paragraphs || []).find((p) => p.id === selectedParaId);

  return (
    <div className="space-y-6 animate-fade-in no-copy-protect no-print-protect text-slate-700 dark:text-slate-200">
      
      {/* 1. Header Section with protections banner */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-b border-indigo-150/40 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-extrabold font-serif-literata text-slate-800 dark:text-white tracking-tight">
              {lang === "en" ? "Dictation Practice" : "શ્રુતલેખન અભ્યાસ"}
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold tracking-wider bg-indigo-50 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 rounded-md uppercase border border-indigo-100 dark:border-slate-705">
              PRO COACH
            </span>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl font-sans leading-relaxed">
            {lang === "en"
              ? "Premium shorthand speed outlines, words symbols & audio-visual dictation drills designed to pass competitive steno-exams in Gujarat."
              : "ગુજરાત હાઇકોર્ટ અને ગૌણ સેવા પસંદગી મંડળની સ્ટેનોગ્રાફી કસોટીઓ માટેનું અધ્યતન પ્રશિક્ષણ સેન્ટર."}
          </p>
        </div>

        {/* Security protection banner */}
        <div className="flex items-center gap-3 px-4 py-3 bg-rose-500/10 border-2 border-rose-500/20 text-rose-700 dark:text-rose-300 rounded-2xl text-xs md:text-sm max-w-md shadow-xs">
          <ShieldAlert className="w-5 h-5 shrink-0 text-rose-500 animate-pulse" />
          <span className="font-semibold leading-relaxed">
            {lang === "en"
              ? "Content is strictly protected. Copying, downloading, printing, or screenshotting is prohibited."
              : "સામગ્રી સુરક્ષિત છે. સ્થાનિક કૉપિ કરવા, ડાઉનલોડ કે પ્રિન્ટ કરવા પર સખત પ્રતિબંધ છે."}
          </span>
        </div>
      </div>

      {/* 2. Primary Tab Selector (Words vs Paragraphs) & English/Gujarati Outlines Language switch */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-100/40 dark:bg-slate-900/30 p-2.5 rounded-2xl border border-indigo-100/30 dark:border-slate-800/60 shadow-sm">
        
        {/* Left tabs: Segmented Switcher */}
        <div className="flex self-start md:self-auto gap-1 bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800 p-1 rounded-xl shadow-xs">
          <button
            onClick={() => setActiveTab("paragraphs")}
            className={`px-5 py-2 rounded-lg text-sm font-bold tracking-wide transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === "paragraphs"
                ? "bg-indigo-600 text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-white"
            }`}
          >
            <span>{lang === "en" ? "Shorthand Paragraphs" : "શ્રુતલેખન ફકરા"}</span>
          </button>
        </div>

        {/* Right sub-tabs: Language filter for outlines display (Gujarati / English) */}
        <div className="flex items-center gap-3">
          <div className="flex bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800 p-1 rounded-xl shadow-xs">
            <button
              onClick={() => setSelectedLang("gu")}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                selectedLang === "gu"
                  ? "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-200/50"
                  : "text-slate-500 dark:text-slate-400 hover:text-slate-800"
              }`}
            >
              ગુજરાતી / Gujarati
            </button>
            <button
              onClick={() => setSelectedLang("en")}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                selectedLang === "en"
                  ? "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-200/50"
                  : "text-slate-500 dark:text-slate-400 hover:text-slate-800"
              }`}
            >
              English / અંગ્રેજી
            </button>
          </div>
        </div>
      </div>

      {/* ADMIN CONTROLS BANNER */}
      {isAdmin && (
        <div className="bg-indigo-600/10 border-2 border-dashed border-indigo-600/30 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-inner">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping"></span>
            <span className="text-xs font-bold font-mono text-indigo-700 dark:text-indigo-300">
              [ADMIN SESSION ACTIVE] Directly Add, Edit, or Delete items inside this view!
            </span>
          </div>
          <div className="flex gap-2">
            {activeTab === "words" ? (
              <button
                onClick={() => {
                  resetWordForm();
                  setIsWordModalOpen(true);
                }}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-indigo-750 transition flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Word / Outline</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  resetParaForm();
                  setIsParaModalOpen(true);
                }}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-indigo-750 transition flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Shorthand Paragraph</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* 3. TAB AREA A: WORDS & PHRASES */}
      {activeTab === "words" && (
        <div className="space-y-6">
          
          {/* Category Filter buttons & Search controls */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
            
            {/* 4 Custom categories from specifications */}
            <div className="flex flex-wrap gap-1.5 bg-slate-100/50 dark:bg-slate-900/50 p-1.5 rounded-2xl border border-slate-200/30 dark:border-slate-800/50 w-full lg:w-auto">
              {([
                { id: "words", valEn: "Words", valGu: "રાષ્ટ્રીય શબ્દો" },
                { id: "symbol", valEn: "Words Symbol", valGu: "શબ્દ ચિહ્નો" },
                { id: "phrases", valEn: "Words Phrases", valGu: "સમૂહરેખાઓ" },
                { id: "dual", valEn: "Dual Words", valGu: "જોડકા શબ્દો" },
              ] as const).map((categoryItem) => (
                <button
                  key={categoryItem.id}
                  onClick={() => setSelectedCategory(categoryItem.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold tracking-wide transition uppercase cursor-pointer ${
                    selectedCategory === categoryItem.id
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-600 dark:text-slate-400 hover:bg-slate-200/40 dark:hover:bg-slate-800/40"
                  }`}
                >
                  {lang === "en" ? categoryItem.valEn : categoryItem.valGu}
                </button>
              ))}
            </div>

            {/* Quick search block */}
            <div className="flex items-center gap-2 max-w-md rounded-xl bg-white dark:bg-slate-900 px-3.5 py-2.5 border-2 border-indigo-50 dark:border-slate-800 shadow-sm focus-within:border-indigo-500 w-full lg:w-96">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                placeholder={lang === "en" ? "Search current outlines list..." : "ચિહ્નો અને લખાણ માં શોધો..."}
                value={searchWord}
                onChange={(e) => setSearchWord(e.target.value)}
                className="bg-transparent text-xs w-full outline-none text-slate-700 dark:text-white"
              />
              {searchWord && (
                <button onClick={() => setSearchWord("")} className="text-slate-400 hover:text-slate-600">
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* Words Executive Data Table Redesign */}
          <div className="bg-white dark:bg-slate-955 rounded-2xl border border-indigo-100/40 dark:border-slate-800 shadow-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/70 dark:bg-slate-900/50 border-b border-indigo-50 dark:border-slate-800">
                    <th className="p-4 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      {lang === "en" ? "English Term" : "અંગ્રેજી શબ્દ"}
                    </th>
                    <th className="p-4 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      {lang === "en" ? "Gujarati Word" : "ગુજરાતી અર્થ"}
                    </th>
                    <th className="p-4 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      {lang === "en" ? "Professional usage & Phrase" : "વાક્ય પ્રયોગ અને શબ્દચિત્ર"}
                    </th>
                    <th className="p-4 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 text-center">
                      {lang === "en" ? "Audio Outline" : "ધ્વનિ પ્રકાશન"}
                    </th>
                    {isAdmin && (
                      <th className="p-4 text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 text-right">
                        Admin Options
                      </th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-indigo-50/40 dark:divide-slate-800/40">
                  {displayedWordRows.map((word) => (
                    <tr
                      key={word.id}
                      className="hover:bg-indigo-500/5 dark:hover:bg-slate-900/40 transition group"
                    >
                      {/* English term column */}
                      <td className="p-4 font-serif-literata font-bold text-slate-800 dark:text-white text-sm">
                        {word.wordEn}
                      </td>

                      {/* Gujarati corresponding column */}
                      <td className="p-4 text-slate-700 dark:text-slate-300 font-medium text-xs">
                        <span className="px-2 py-1 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-md border border-amber-500/20">
                          {word.wordGu}
                        </span>
                      </td>

                      {/* Custom context usage text */}
                      <td className="p-4 space-y-1">
                        <p className="text-xs text-slate-600 dark:text-slate-300 italic">
                          "{word.phraseEn}"
                        </p>
                        <p className="text-[11px] text-slate-400 dark:text-slate-500">
                          {word.phraseGu}
                        </p>
                      </td>

                      {/* Media playback controller trigger */}
                      <td className="p-4 text-center">
                        <button
                          onClick={() => handleWordPlay(word)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                            wordPlaying === word.id
                              ? "bg-amber-500 text-slate-900 border border-amber-500 animate-pulse"
                              : "bg-indigo-50 hover:bg-indigo-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-indigo-600 dark:text-indigo-400 border border-indigo-100/20"
                          }`}
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>{wordPlaying === word.id ? "Playing" : "Listen"}</span>
                        </button>
                      </td>

                      {/* Explicit inline Admin customization triggers */}
                      {isAdmin && (
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setWordForm({
                                  ...word,
                                  category: getWordCategory(word),
                                });
                                setIsWordModalOpen(true);
                              }}
                              className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-500/10 rounded-lg transition"
                              title="Edit"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteWordFlow(word)}
                              className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-500/10 rounded-lg transition"
                              title="Delete"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}

                  {displayedWordRows.length === 0 && (
                    <tr>
                      <td colSpan={isAdmin ? 5 : 4} className="p-10 text-center text-slate-400 text-xs">
                        {lang === "en"
                          ? "No outlines matches found under this category."
                          : "આ કેટેગરીમાં કોઈ શબ્દો અથવા સંકેતો ઉપલબ્ધ નથી."}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. TAB AREA B: SHORTHAND PRACTICE PARAGRAPHS */}
      {activeTab === "paragraphs" && (
        <div className="space-y-6">
          
          {/* Paragraph filters: WPM Speeds and Select dropdowns */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 bg-slate-100/40 dark:bg-slate-900/30 p-4 rounded-2xl border border-indigo-100/30 dark:border-slate-800/60 shadow-xs">
            
            {/* Speed Pill switches (60 to 140 WPM) */}
            <div className="xl:col-span-12 flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider w-full md:w-auto md:mr-2">
                {lang === "en" ? "Speed WPM:" : "ડિક્ટેશન ઝડપ WPM:"}
              </span>
              {(["All", 60, 75, 90, 100, 120, 140] as const).map((spd) => (
                <button
                  key={spd}
                  onClick={() => setSpeedFilter(spd)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                    speedFilter === spd
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-50 border border-slate-200/50 dark:border-slate-800"
                  }`}
                >
                  {spd === "All" ? (lang === "en" ? "All" : "બધી સ્પીડ") : `${spd} WPM`}
                </button>
              ))}
            </div>

            {/* Quick Select subject dropdown list */}
            <div className="xl:col-span-8 flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0">
                {lang === "en" ? "Subject:" : "વિષય:"}
              </span>
              <select
                value={selectedParaId}
                onChange={(e) => setSelectedParaId(e.target.value)}
                className="w-full text-xs p-2.5 bg-white dark:bg-slate-900 border-2 border-indigo-50 dark:border-slate-800 rounded-xl outline-none focus:border-indigo-500 text-slate-700 dark:text-white"
              >
                <option value="">-- {lang === "en" ? "Select Paragraph Subject" : "ફકરા શિર્ષક પસંદ કરો"} --</option>
                {currentFilteredParas.map((p) => (
                  <option key={p.id} value={p.id}>
                    ({p.speed} WPM) {lang === "en" ? p.titleEn : p.titleGu}
                  </option>
                ))}
              </select>
            </div>

            {/* Random Picker action button */}
            <div className="xl:col-span-4 flex justify-end">
              <button
                onClick={() => {
                  if (currentFilteredParas.length > 0) {
                    const idx = Math.floor(Math.random() * currentFilteredParas.length);
                    setSelectedParaId(currentFilteredParas[idx].id);
                  }
                }}
                disabled={currentFilteredParas.length === 0}
                className="w-full px-4 py-2.5 bg-amber-500 text-slate-900 font-bold rounded-xl text-xs shadow-md shadow-amber-500/10 hover:bg-amber-600 transition disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{lang === "en" ? "Random Subject" : "અવ્યવસ્થિત પસંદગી"}</span>
              </button>
            </div>
          </div>

          {/* Immersive Main Dictation Viewer Card */}
          {activeSelectedPara ? (
            <div className="bg-white dark:bg-slate-950 rounded-2xl border border-indigo-100/40 dark:border-slate-800 shadow-xl p-6 md:p-8 space-y-6 relative overflow-hidden">
              
              {/* Background elegant watermarks */}
              <div className="absolute top-0 right-0 p-10 font-serif-literata text-9xl text-slate-500/5 select-none pointer-events-none uppercase font-extrabold tracking-widest leading-none">
                Steno
              </div>

              {/* Title & Subheadings header line with operational direct CRUD */}
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-indigo-50/70 dark:border-slate-800 pb-5">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-xl md:text-2xl font-extrabold font-serif-literata text-slate-800 dark:text-white tracking-tight">
                      {lang === "en" ? activeSelectedPara.titleEn : activeSelectedPara.titleGu}
                    </h2>
                    <span className="px-2.5 py-0.5 text-xs font-extrabold bg-amber-500/10 text-amber-600 border border-amber-500/20 rounded-md">
                      {activeSelectedPara.speed} WPM DRILL
                    </span>
                  </div>
                  
                  {/* Metadata labels */}
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400 dark:text-slate-500 font-sans">
                    <span>Topic: <strong className="text-slate-600 dark:text-slate-300">{lang === "en" ? activeSelectedPara.topicEn : activeSelectedPara.topicGu}</strong></span>
                    <span>•</span>
                    <span>Narrator: <strong className="text-slate-600 dark:text-slate-300">{activeSelectedPara.narrator}</strong></span>
                  </div>
                </div>

                {/* Control options for admins */}
                <div className="flex items-center gap-2">
                  {isAdmin && (
                    <div className="flex bg-slate-100 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 p-1 rounded-xl">
                      <button
                        onClick={() => {
                          setParaForm(activeSelectedPara);
                          setIsParaModalOpen(true);
                        }}
                        className="px-3 py-1.5 text-xs font-bold text-indigo-600 hover:bg-white rounded-lg transition flex items-center gap-1"
                        title="Edit para"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => deleteParaFlow(activeSelectedPara)}
                        className="px-3 py-1.5 text-xs font-bold text-rose-600 hover:bg-white rounded-lg transition flex items-center gap-1"
                        title="Delete para"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  )}

                  {/* Play media trigger */}
                  <button
                    onClick={() => handleParaPlay(activeSelectedPara)}
                    className={`px-5 py-3 rounded-xl flex items-center gap-2 text-sm font-bold shadow-md tracking-wider transition cursor-pointer ${
                      paraPlaying === activeSelectedPara.id
                        ? "bg-rose-500 text-white animate-pulse"
                        : "bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-200/60 dark:shadow-none"
                    }`}
                  >
                    {paraPlaying === activeSelectedPara.id ? (
                      <>
                        <Pause className="w-4 h-4" />
                        <span>{lang === "en" ? "Pause" : "અટકાવો"}</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 fill-white" />
                        <span>{lang === "en" ? "Play Audio Drill" : "શ્રુતલેખન શરૂ કરો"}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* CUSTOM MEDIA PLAYER TRACK BAR DESIGN */}
              <div className="bg-slate-50/70 dark:bg-slate-900/40 rounded-2xl p-4 border border-indigo-50/50 dark:border-slate-800/80 flex flex-col md:flex-row items-center justify-between gap-4">
                
                {/* Audio asset feedback */}
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-inner ${
                    paraPlaying === activeSelectedPara.id ? "bg-indigo-500 text-white" : "bg-indigo-50/50 dark:bg-slate-800 text-slate-400"
                  }`}>
                    <Volume2 className={`w-5 h-5 ${paraPlaying === activeSelectedPara.id ? "animate-bounce" : ""}`} />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-300 font-mono">
                      {activeSelectedPara.audioUrl ? "Audio track attached" : "No pre-recorded audio files loaded."}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {activeSelectedPara.audioUrl 
                        ? "Secure Live Hosting streaming active." 
                        : "Admin can upload custom speech outlines recording."}
                    </p>
                  </div>
                </div>

                {/* Speed MULTIPLIER selector */}
                <div className="flex items-center gap-2.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    {lang === "en" ? "Speed rate:" : "પ્લેબેક રેટ:"}
                  </span>
                  <div className="flex bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800 p-0.5 rounded-xl shadow-xs">
                    {([0.75, 1.0, 1.25, 1.5] as const).map((r) => (
                      <button
                        key={r}
                        onClick={() => setPlaybackSpeed(r)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono transition cursor-pointer ${
                          playbackSpeed === r
                            ? "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-200/50"
                            : "text-slate-500 dark:text-slate-400 hover:text-slate-800"
                        }`}
                      >
                        {r}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* TRANSCRIPT REVEALER BLOCK */}
              <div className="space-y-3">
                <button
                  onClick={() => toggleTranscript(activeSelectedPara.id)}
                  className="px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold tracking-wide text-slate-600 dark:text-slate-400 hover:text-indigo-600 transition flex items-center gap-2 cursor-pointer shadow-xs"
                >
                  {showTranscripts[activeSelectedPara.id] ? (
                    <>
                      <EyeOff className="w-4 h-4" />
                      <span>{lang === "en" ? "Hide Outline Transcript" : "ટ્રાંસ્ક્રિપ્ટ છુપાવો"}</span>
                    </>
                  ) : (
                    <>
                      <Eye className="w-4 h-4 text-indigo-500" />
                      <span>{lang === "en" ? "Reveal Correct Transcript" : "ચોક્કસ ટ્રાંસ્ક્રિપ્ટ જુઓ"}</span>
                    </>
                  )}
                </button>

                {showTranscripts[activeSelectedPara.id] && (
                  <div className="p-5 bg-amber-500/5 dark:bg-slate-900/60 border-2 border-dashed border-amber-500/20 text-sm leading-relaxed text-slate-600 dark:text-slate-350 tracking-wide rounded-2xl select-none font-sans whitespace-pre-line ring-1 ring-amber-500/5">
                    {activeSelectedPara.transcript}
                  </div>
                )}
              </div>


            </div>
          ) : (
            <p className="text-xs text-slate-400 text-center py-10 bg-white dark:bg-slate-900 border border-indigo-100/40 rounded-2xl shadow-xs">
              {lang === "en" ? "No paragraph is currently available under the selected filter." : "પસંદ કરેલા લિપિ શીર્ષક હેઠળ કોઈ વિષય ઉપલબ્ધ નથી."}
            </p>
          )}
        </div>
      )}

      {/* =============================================================== */}
      {/* 5. MODAL FORM: ADD / EDIT WORD OUTLINE */}
      {isWordModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-55 overflow-y-auto">
          <div className="bg-white dark:bg-slate-950 border-2 border-indigo-150 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 relative">
            <button
              onClick={() => setIsWordModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
              {wordForm.id ? "Edit Word Outline" : "Add New Word Outline"}
            </h3>

            <form onSubmit={saveWordFlow} className="space-y-4">
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">English Word</label>
                  <input
                    type="text"
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={wordForm.wordEn}
                    onChange={(e) => setWordForm({ ...wordForm, wordEn: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Gujarati Word</label>
                  <input
                    type="text"
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={wordForm.wordGu}
                    onChange={(e) => setWordForm({ ...wordForm, wordGu: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">English Phrase Context</label>
                <input
                  type="text"
                  required
                  className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                  value={wordForm.phraseEn}
                  onChange={(e) => setWordForm({ ...wordForm, phraseEn: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Gujarati Phrase Match</label>
                <input
                  type="text"
                  required
                  className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                  value={wordForm.phraseGu}
                  onChange={(e) => setWordForm({ ...wordForm, phraseGu: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Shorthand Category</label>
                  <select
                    value={wordForm.category}
                    onChange={(e) =>
                      setWordForm({
                        ...wordForm,
                        category: e.target.value as any,
                      })
                    }
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                  >
                    <option value="words">Words (રાષ્ટ્રીય શબ્દો)</option>
                    <option value="symbol">Words Symbol (શબ્દ ચિહ્નો)</option>
                    <option value="phrases">Words Phrases (સમૂહરેખાઓ)</option>
                    <option value="dual">Dual Words (જોડકા શબ્દો)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Custom Audio MP3</label>
                  <input
                    type="text"
                    placeholder="URL or Upload audio file"
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none text-slate-500 font-mono"
                    value={wordForm.audioUrl}
                    onChange={(e) => setWordForm({ ...wordForm, audioUrl: e.target.value })}
                  />
                </div>
              </div>

              {/* Directly upload tracks inside the modal forms */}
              <div className="bg-indigo-50/40 dark:bg-slate-900 border border-indigo-100/30 p-3 rounded-xl">
                <label className="block text-[10px] font-black uppercase text-indigo-700 dark:text-indigo-400 mb-1">
                  Upload audio directly (Auto attaches URL)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={(e) => handleUploadFile(e, "word")}
                    className="text-xs text-slate-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700"
                  />
                  {uploadProgress && (
                    <span className="text-[10px] font-mono text-indigo-600 dark:text-indigo-300 animate-pulse">
                      {uploadProgress}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800 pt-4 mt-6">
                <button
                  type="button"
                  onClick={() => setIsWordModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-805 text-slate-600 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-650 hover:bg-indigo-750 text-white rounded-xl text-xs font-bold cursor-pointer"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =============================================================== */}
      {/* 6. MODAL FORM: ADD / EDIT DICTATION PARAGRAPH */}
      {isParaModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-55 overflow-y-auto">
          <div className="bg-white dark:bg-slate-950 border-2 border-indigo-150 dark:border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl p-6 relative my-8">
            <button
              onClick={() => setIsParaModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
              {paraForm.id ? "Edit Dictation Paragraph" : "Add New Dictation Paragraph"}
            </h3>

            <form onSubmit={saveParaFlow} className="space-y-4">
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Title (English)</label>
                  <input
                    type="text"
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={paraForm.titleEn}
                    onChange={(e) => setParaForm({ ...paraForm, titleEn: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Title (Gujarati)</label>
                  <input
                    type="text"
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={paraForm.titleGu}
                    onChange={(e) => setParaForm({ ...paraForm, titleGu: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Topic (English)</label>
                  <input
                    type="text"
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={paraForm.topicEn}
                    onChange={(e) => setParaForm({ ...paraForm, topicEn: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Topic (Gujarati)</label>
                  <input
                    type="text"
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={paraForm.topicGu}
                    onChange={(e) => setParaForm({ ...paraForm, topicGu: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Shorthand Speed (WPM)</label>
                  <select
                    value={paraForm.speed}
                    onChange={(e) =>
                      setParaForm({
                        ...paraForm,
                        speed: parseInt(e.target.value) || 80,
                      })
                    }
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none shadow-xs"
                  >
                    {[60, 75, 80, 90, 100, 120, 140].map((s) => (
                      <option key={s} value={s}>
                        {s} WPM
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Narrator Name</label>
                  <input
                    type="text"
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={paraForm.narrator}
                    onChange={(e) => setParaForm({ ...paraForm, narrator: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Audio URL path</label>
                  <input
                    type="text"
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none text-slate-500 font-mono"
                    placeholder="/public/... or cloud MP3 path"
                    value={paraForm.audioUrl}
                    onChange={(e) => setParaForm({ ...paraForm, audioUrl: e.target.value })}
                  />
                </div>
              </div>

              {/* Directly Upload Sound drill */}
              <div className="bg-indigo-50/40 dark:bg-slate-900 border border-indigo-100/30 p-3 rounded-xl">
                <label className="block text-[10px] font-black uppercase text-indigo-700 dark:text-indigo-400 mb-1">
                  Upload audio Drill track directly (Auto attaches URL)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={(e) => handleUploadFile(e, "para")}
                    className="text-xs text-slate-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700"
                  />
                  {uploadProgress && (
                    <span className="text-[10px] font-mono text-indigo-600 dark:text-indigo-300 animate-pulse">
                      {uploadProgress}
                    </span>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Correct Practice Transcript (Text Content)</label>
                <textarea
                  rows={4}
                  required
                  className="w-full text-xs p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none leading-relaxed font-sans"
                  value={paraForm.transcript}
                  onChange={(e) => setParaForm({ ...paraForm, transcript: e.target.value })}
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800 pt-4 mt-6">
                <button
                  type="button"
                  onClick={() => setIsParaModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-805 text-slate-600 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-650 hover:bg-indigo-750 text-white rounded-xl text-xs font-bold cursor-pointer"
                >
                  Save Paragraph Metrics
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
