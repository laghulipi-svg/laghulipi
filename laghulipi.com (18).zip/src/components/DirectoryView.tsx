import React, { useState } from "react";
import { DatabaseState, DirectoryItem } from "../types";
import { Search, Grid, List, MapPin, Phone, MessageSquare, ChevronUp, ChevronDown, Award, Briefcase, Landmark } from "lucide-react";

interface DirectoryViewProps {
  lang: "en" | "gu";
  db: DatabaseState;
}

type DirectoryTabs = "secretaries" | "stenographers" | "collectors" | "ddos";

export default function DirectoryView({ lang, db }: DirectoryViewProps) {
  const [activeTab, setActiveTab] = useState<DirectoryTabs>("secretaries");
  const [viewMode, setViewMode] = useState<"list" | "grid">("list");

  // Search parameters
  const [searchName, setSearchName] = useState("");
  const [searchDistrict, setSearchDistrict] = useState("");

  // Sorting state
  const [sortField, setSortField] = useState<string | null>("name");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  const handleSort = (field: string) => {
    // Disable sorting for phone/landline
    if (field === "landline" || field === "mobile") return;

    if (sortField === field) {
      setSortDirection((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const getSortIcon = (field: string) => {
    if (field === "landline" || field === "mobile") return null;
    if (sortField !== field) {
      return (
        <span className="flex flex-col text-[8px] text-slate-400 dark:text-slate-500 opacity-60 ml-1 shrink-0">
          <ChevronUp className="w-2 h-2 -mb-0.5" />
          <ChevronDown className="w-2 h-2" />
        </span>
      );
    }
    return sortDirection === "asc" ? (
      <ChevronUp className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 ml-1 shrink-0" />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 ml-1 shrink-0" />
    );
  };

  // Get active directory lists
  const getRawItems = (): DirectoryItem[] => {
    return db.directories?.[activeTab] || [];
  };

  // Filter items
  const getFilteredItems = (): DirectoryItem[] => {
    const raw = getRawItems();
    return raw.filter((item) => {
      // Search by Name, Designation, and Department
      const textMatch =
        item.name.toLowerCase().includes(searchName.toLowerCase()) ||
        item.designation.toLowerCase().includes(searchName.toLowerCase()) ||
        item.department.toLowerCase().includes(searchName.toLowerCase());

      // Search by District (Only for collectors and ddos)
      const isDistrictTab = activeTab === "collectors" || activeTab === "ddos";
      let distMatch = true;
      if (isDistrictTab && searchDistrict.trim().length > 0) {
        distMatch = (item.district || "").toLowerCase().includes(searchDistrict.toLowerCase());
      }

      return textMatch && distMatch;
    });
  };

  // Sort items
  const getSortedItems = (): DirectoryItem[] => {
    const filtered = getFilteredItems();
    if (!sortField) return filtered;

    return [...filtered].sort((a: any, b: any) => {
      const valA = String(a[sortField] || "").trim().toLowerCase();
      const valB = String(b[sortField] || "").trim().toLowerCase();

      // Numerical or year comparisons
      if (sortField === "batchYear") {
        const numA = parseInt(valA) || 0;
        const numB = parseInt(valB) || 0;
        return sortDirection === "asc" ? numA - numB : numB - numA;
      }

      // Alphabetical comparisons
      if (valA < valB) return sortDirection === "asc" ? -1 : 1;
      if (valA > valB) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
  };

  const sortedItems = getSortedItems();

  const labels = {
    secretaries: lang === "en" ? "Secretaries" : "સચિવો",
    stenographers: lang === "en" ? "Stenographers" : "સ્ટેનોગ્રાફરો",
    collectors: lang === "en" ? "Collectors" : "કલેક્ટરો",
    ddos: lang === "en" ? "DDOs" : "ડીડીઓ (DDOs)",
  };

  return (
    <div className="space-y-6 animate-fade-in font-gujarati">
      <div className="border-b border-slate-100 dark:border-slate-800 pb-5">
        <h1 className="text-3xl font-bold font-serif-literata text-slate-800 dark:text-white">
          {lang === "en" ? "Professional Directory" : "સરકારી અધિકારી ડિરેક્ટરી"}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {lang === "en"
            ? "Comprehensive search matrix for Gujarat Secretaries, Collectors, DDOs and Shorthand Stenographers."
            : "સચિવો, કલેકટરો અને વરિષ્ઠ સ્ટેનોગ્રાફરોની વિગતવાર વિગતો, સ્થાપિત અને સંપર્ક યાદી."}
        </p>
      </div>

      {/* Grid Directory Tab buttons */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 bg-slate-100/80 dark:bg-slate-900/80 p-1.5 rounded-xl">
        {(["secretaries", "stenographers", "collectors", "ddos"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => {
              setActiveTab(tab);
              // reset filters
              setSearchName("");
              setSearchDistrict("");
              setSortField("name");
              setSortDirection("asc");
            }}
            className={`py-3.5 rounded-lg text-xs md:text-sm font-bold transition flex flex-col items-center justify-center gap-1 cursor-pointer ${
              activeTab === tab
                ? "bg-white dark:bg-slate-850 text-indigo-600 dark:text-indigo-400 shadow-sm border border-slate-150 dark:border-slate-800"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            }`}
          >
            <span className="text-sm">
              {tab === "secretaries" && <Landmark className="w-4 h-4" />}
              {tab === "stenographers" && <Briefcase className="w-4 h-4" />}
              {tab === "collectors" && <MapPin className="w-4 h-4" />}
              {tab === "ddos" && <Award className="w-4 h-4" />}
            </span>
            <span>{labels[tab]} ({db.directories?.[tab]?.length || 0})</span>
          </button>
        ))}
      </div>

      {/* Filters and View Toggles */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 w-full max-w-2xl">
          {/* Main search */}
          <div className="flex items-center gap-2 rounded-xl bg-white dark:bg-slate-800 px-3 py-2 border border-slate-200 dark:border-slate-700 shadow-sm flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              placeholder={
                lang === "en"
                  ? `Search by name, designation, department...`
                  : `અધિકારીનું નામ અથવા કચેરી શોધો...`
              }
              value={searchName}
              onChange={(e) => setSearchName(e.target.value)}
              className="bg-transparent text-xs md:text-sm w-full outline-none text-slate-700 dark:text-white"
            />
          </div>

          {/* District search input (only shown in Collectors & DDOs tabs) */}
          {(activeTab === "collectors" || activeTab === "ddos") && (
            <div className="flex items-center gap-2 rounded-xl bg-white dark:bg-slate-800 px-3 py-2 border border-slate-200 dark:border-slate-700 shadow-sm min-w-[150px]">
              <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                placeholder={lang === "en" ? "Filter by District..." : "જિલ્લો શોધો..."}
                value={searchDistrict}
                onChange={(e) => setSearchDistrict(e.target.value)}
                className="bg-transparent text-xs md:text-sm w-full outline-none text-slate-700 dark:text-white"
              />
            </div>
          )}
        </div>

        {/* View Mode Switcher buttons */}
        <div className="flex border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden bg-white dark:bg-slate-800 self-end md:self-auto shrink-0 shadow-sm">
          <button
            onClick={() => setViewMode("list")}
            className={`p-2.5 cursor-pointer ${
              viewMode === "list"
                ? "bg-indigo-600 text-white"
                : "text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-700"
            }`}
          >
            <List className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode("grid")}
            className={`p-2.5 cursor-pointer ${
              viewMode === "grid"
                ? "bg-indigo-600 text-white"
                : "text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-700"
            }`}
          >
            <Grid className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Detailed listing / Grid cards */}
      {sortedItems.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
          <p className="text-sm text-slate-400">
            {lang === "en" ? "No records match search parameters." : "કોઈ માહિતી ઉપલબ્ધ નથી."}
          </p>
        </div>
      ) : viewMode === "list" ? (
        /* LIST/TABLE MODE */
        <div className="overflow-x-auto bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm">
          <table className="w-full text-left border-collapse text-xs md:text-sm">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-850 border-b border-slate-150 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold font-sans tracking-wider uppercase">
                <th className="py-4 px-4 w-12 text-center text-[10px]">#</th>
                <th
                  onClick={() => handleSort("name")}
                  className="py-4 px-4 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <span className="flex items-center text-[10px]">
                    {lang === "en" ? "Name" : "અધિકારીનું નામ"}
                    {getSortIcon("name")}
                  </span>
                </th>
                <th
                  onClick={() => handleSort("designation")}
                  className="py-4 px-4 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <span className="flex items-center text-[10px]">
                    {lang === "en" ? "Designation" : "હોદ્દો"}
                    {getSortIcon("designation")}
                  </span>
                </th>
                <th
                  onClick={() => handleSort("department")}
                  className="py-4 px-4 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <span className="flex items-center text-[10px]">
                    {lang === "en" ? "Department" : "વિભાગ / કચેરી"}
                    {getSortIcon("department")}
                  </span>
                </th>

                {/* Optional Batch Year column (Only Secretaries) */}
                {activeTab === "secretaries" && (
                  <th
                    onClick={() => handleSort("batchYear")}
                    className="py-4 px-4 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <span className="flex items-center text-[10px]">
                      {lang === "en" ? "Batch Year" : "બેચ વર્ષ"}
                      {getSortIcon("batchYear")}
                    </span>
                  </th>
                )}

                {/* Optional District column (Collectors & DDOs) */}
                {(activeTab === "collectors" || activeTab === "ddos") && (
                  <th
                    onClick={() => handleSort("district")}
                    className="py-4 px-4 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <span className="flex items-center text-[10px]">
                      {lang === "en" ? "District" : "જિલ્લો"}
                      {getSortIcon("district")}
                    </span>
                  </th>
                )}

                <th className="py-4 px-4 text-[10px]">
                  {lang === "en" ? "Landline" : "લેન્ડલાઇન"}
                </th>
                <th className="py-4 px-4 text-[10px]">
                  {lang === "en" ? "Mobile" : "મોબાઇલ"}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-sans text-slate-700 dark:text-slate-300">
              {sortedItems.map((item, index) => (
                <tr
                  key={item.id}
                  className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors"
                >
                  <td className="py-4 px-4 text-center font-mono opacity-60">{index + 1}</td>
                  <td className="py-4 px-4 font-semibold text-slate-800 dark:text-white">
                    {item.name}
                  </td>
                  <td className="py-4 px-4 text-slate-600 dark:text-slate-300">
                    <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-md">
                      {item.designation}
                    </span>
                  </td>
                  <td className="py-4 px-4 leading-relaxed text-slate-500 dark:text-slate-400 max-w-xs md:max-w-sm truncate">
                    {item.department}
                  </td>

                  {/* Batch Year cell */}
                  {activeTab === "secretaries" && (
                    <td className="py-4 px-4">
                      <span className="font-mono text-indigo-600 dark:text-indigo-400 font-semibold bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded">
                        {item.batchYear || "N/A"}
                      </span>
                    </td>
                  )}

                  {/* District cell */}
                  {(activeTab === "collectors" || activeTab === "ddos") && (
                    <td className="py-4 px-4 text-slate-600 dark:text-slate-300 font-medium">
                      {item.district || "N/A"}
                    </td>
                  )}

                  <td className="py-4 px-4 text-slate-500 dark:text-slate-400 font-mono">
                    {item.landline || "-"}
                  </td>
                  <td className="py-4 px-4 text-indigo-600 dark:text-indigo-400 font-semibold font-mono">
                    {item.mobile || "-"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        /* GRID CARDS MODE */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedItems.map((item) => (
            <div
              key={item.id}
              className="rounded-xl glass-card border border-white/20 dark:border-slate-800 p-5 space-y-4 hover:shadow-xl hover:translate-y-[-2px] transition-all"
            >
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <h3 className="font-bold text-slate-800 dark:text-white leading-snug">
                    {item.name}
                  </h3>
                  <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                    {item.designation}
                  </p>
                </div>

                {activeTab === "secretaries" && (
                  <span className="font-mono text-[10px] font-bold bg-indigo-50 dark:bg-indigo-900/30 text-indigo-500 px-2 py-0.5 rounded">
                    Batch: {item.batchYear}
                  </span>
                )}

                {(activeTab === "collectors" || activeTab === "ddos") && (
                  <span className="text-[10px] bg-sky-50 dark:bg-sky-900/30 text-sky-600 px-2 py-0.5 rounded font-bold">
                    {item.district}
                  </span>
                )}
              </div>

              <div className="space-y-2 text-xs text-slate-500 dark:text-slate-400 pb-3 border-b border-light dark:border-slate-800">
                <p className="leading-snug">
                  <strong>{lang === "en" ? "Department:" : "કચેરી:"}</strong> {item.department}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg space-y-0.5">
                  <span className="text-[9px] text-slate-400 uppercase font-sans">
                    {lang === "en" ? "Landline" : "લેન્ડલાઇન"}
                  </span>
                  <p className="text-slate-700 dark:text-slate-300 font-semibold">{item.landline || "-"}</p>
                </div>
                <div className="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg space-y-0.5">
                  <span className="text-[9px] text-slate-400 uppercase font-sans">
                    {lang === "en" ? "Mobile" : "મોબાઇલ"}
                  </span>
                  <p className="text-indigo-600 dark:text-indigo-400 font-bold">{item.mobile || "-"}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
