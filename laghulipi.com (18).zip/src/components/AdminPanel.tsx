import React, { useState } from "react";
import { DatabaseState, UpdateItem, WordItem, ParagraphItem, BookItem, DownloadItem, DirectoryItem, PillarItem, TeamMember, SocialLink, QuickLink } from "../types";
import { Save, LogIn, Plus, Trash2, Edit3, Upload, FileDown, BookOpen, ShieldCheck, Landmark, Users, Clock, History, FileText, Settings, Key, AlertCircle, Sparkles, HelpCircle, UserPlus, Check, X } from "lucide-react";

interface AdminPanelProps {
  lang: "en" | "gu";
  db: DatabaseState;
  currentUser: any;
  onLogin: (u: any) => void;
  onLogout: () => void;
  onSaveDB: (newState: DatabaseState, action: string) => Promise<any>;
  onRefreshDB?: () => Promise<DatabaseState | undefined>;
}

type AdminTabs = "home" | "updates" | "dictation" | "library" | "downloads" | "directory" | "utilities" | "about" | "footer" | "quicklinks" | "auditlogs" | "adminusers" | "feedbacks";

export default function AdminPanel({ lang, db, currentUser, onLogin, onLogout, onSaveDB, onRefreshDB }: AdminPanelProps) {
  // Login State
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // Admin Signup Form States
  const [isSigningUp, setIsSigningUp] = useState(false);
  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupSuccess, setSignupSuccess] = useState(false);
  const [signupError, setSignupError] = useState("");
  const [isSubmittingSignup, setIsSubmittingSignup] = useState(false);

  // Control tabs
  const [activeTab, setActiveTab] = useState<AdminTabs>("home");

  // Local state editors
  const [localDb, setLocalDb] = useState<DatabaseState>(db);

  // File uploading states
  const [uploadingTarget, setUploadingTarget] = useState<string | null>(null);

  // Excel spreadsheet importing
  const [importingType, setImportingType] = useState<string | null>(null);
  const [importFeedback, setImportFeedback] = useState<string | null>(null);

  // Direct editing states
  const [editingWord, setEditingWord] = useState<WordItem | null>(null);
  const [editingPara, setEditingPara] = useState<ParagraphItem | null>(null);
  const [editingBook, setEditingBook] = useState<BookItem | null>(null);
  const [editingDownload, setEditingDownload] = useState<DownloadItem | null>(null);
  const [editingDirTab, setEditingDirTab] = useState<"secretaries" | "stenographers" | "collectors" | "ddos">("secretaries");
  const [editingDir, setEditingDir] = useState<DirectoryItem | null>(null);

  // Sync state if prop changes, but avoid wiping logged-in admin edits
  React.useEffect(() => {
    if (!currentUser && db) {
      setLocalDb(db);
    }
  }, [db, currentUser]);

  // Parse headerBg value to extract gradient colors/angle dynamically
  const parseGradient = (cssVal: string) => {
    if (cssVal && cssVal.startsWith("linear-gradient")) {
      const matchColors = cssVal.match(/#[a-fA-F0-9]{6}/g);
      const matchAngle = cssVal.match(/(\d+)deg/);
      return {
        enabled: true,
        start: matchColors?.[0] || "#162e69",
        end: matchColors?.[1] || "#1e40af",
        angle: matchAngle?.[1] || "90"
      };
    }
    return {
      enabled: false,
      start: cssVal && cssVal.startsWith("#") ? cssVal : "#162e69",
      end: "#1e40af",
      angle: "90"
    };
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        throw new Error(lang === "en" ? "Invalid email or password." : "ખોટો ઈમેલ અથવા પાસવર્ડ.");
      }

      const raw = await response.json();
      onLogin(raw.user);
    } catch (err: any) {
      setLoginError(err.message);
    }
  };

  // Handle generic state updates & write immediately
  const handleSaveState = async (updatedDb: DatabaseState, actionName: string) => {
    setLocalDb(updatedDb);
    try {
      const freshDb = await onSaveDB(updatedDb, actionName);
      if (freshDb) {
        setLocalDb(freshDb);
      }
      alert(lang === "en" ? "Successfully saved to Live Platform!" : "સફળતાપૂર્વક સાચવવામાં આવ્યું છે!");
    } catch (err) {
      console.error("Failed saving", err);
    }
  };

  // Direct file uploader proxying
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, targetPath: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingTarget(targetPath);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) throw new Error("Upload failed.");

      const result = await res.json();
      const fileUrl = result.fileUrl;

      // Assign the uploaded file path to state
      let updated = { ...localDb };
      if (targetPath === "header.logoUrl") {
        updated.header = { ...updated.header, logoUrl: fileUrl };
      } else if (targetPath.startsWith("team_")) {
        const teamId = targetPath.split("_")[1];
        updated.aboutUs = {
          ...updated.aboutUs,
          team: updated.aboutUs.team.map(m => m.id === teamId ? { ...m, photoUrl: fileUrl } : m)
        };
      } else if (targetPath.startsWith("word_")) {
        const id = targetPath.split("_")[1];
        updated.words = updated.words.map(w => w.id === id ? { ...w, audioUrl: fileUrl } : w);
        if (editingWord && editingWord.id === id) setEditingWord(prev => prev ? { ...prev, audioUrl: fileUrl } : null);
      } else if (targetPath.startsWith("para_")) {
        const id = targetPath.split("_")[1];
        updated.paragraphs = updated.paragraphs.map(p => p.id === id ? { ...p, audioUrl: fileUrl } : p);
        if (editingPara && editingPara.id === id) setEditingPara(prev => prev ? { ...prev, audioUrl: fileUrl } : null);
      } else if (targetPath.startsWith("bookCover_")) {
        const id = targetPath.split("_")[1];
        updated.books = updated.books.map(b => b.id === id ? { ...b, coverUrl: fileUrl } : b);
        if (editingBook && editingBook.id === id) setEditingBook(prev => prev ? { ...prev, coverUrl: fileUrl } : null);
      } else if (targetPath.startsWith("bookFile_")) {
        const id = targetPath.split("_")[1];
        updated.books = updated.books.map(b => b.id === id ? { ...b, fileUrl: fileUrl } : b);
        if (editingBook && editingBook.id === id) setEditingBook(prev => prev ? { ...prev, fileUrl: fileUrl } : null);
      } else if (targetPath.startsWith("update_")) {
        const id = targetPath.split("_")[1];
        updated.updates = updated.updates.map(u => u.id === id ? { ...u, pdfUrl: fileUrl } : u);
      } else if (targetPath.startsWith("downloadFile_")) {
        const id = targetPath.split("_")[1];
        if (!updated.downloads) updated.downloads = [];
        updated.downloads = updated.downloads.map(d => d.id === id ? { ...d, fileUrl: fileUrl } : d);
        if (editingDownload && editingDownload.id === id) setEditingDownload(prev => prev ? { ...prev, fileUrl: fileUrl } : null);
      }

      await handleSaveState(updated, `Uploaded asset for ${targetPath}`);
    } catch (err) {
      alert("Uh oh! Asset upload failed: " + err);
    } finally {
      setUploadingTarget(null);
    }
  };

  // Handle direct excel file directory import
  const handleSpreadsheetImport = async (e: React.ChangeEvent<HTMLInputElement>, dirType: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportingType(dirType);
    setImportFeedback(null);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch(`/api/directory/import/${dirType}`, {
        method: "POST",
        headers: {
          "x-operator-email": currentUser?.email || "Admin"
        },
        body: formData
      });

      const body = await response.json();
      if (!response.ok) throw new Error(body.error || "Failed importing");

      setImportFeedback(lang === "en" ? `Successfully imported records!` : `રેકોર્ડ્સ સફળતાપૂર્વક આયાત કરવામાં આવ્યા!`);

      // Refresh database records
      if (onRefreshDB) {
        const freshDb = await onRefreshDB();
        if (freshDb) {
          setLocalDb(freshDb);
        }
      } else {
        const fullDbQueryObj = await fetch(`/api/db?t=${Date.now()}`);
        const cleanDbJson = await fullDbQueryObj.json();
        setLocalDb(cleanDbJson);
      }
    } catch (err: any) {
      setImportFeedback(`Error: ${err.message}`);
    } finally {
      setImportingType(null);
    }
  };

  // Layout Signup Screen if requesting access and not logged in
  if (!currentUser && isSigningUp) {
    return (
      <div className="max-w-md mx-auto py-12 px-4 font-sans animate-fade-in no-copy-protect">
        <div className="rounded-2xl glass-card p-8 border border-white/30 dark:border-slate-800 space-y-6">
          <div className="text-center space-y-2">
            <div className="p-3 bg-indigo-55 dark:bg-slate-900 rounded-full w-fit mx-auto text-indigo-600">
              <UserPlus className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold font-serif-literata text-slate-800 dark:text-white">
              {lang === "en" ? "Request Admin Control" : "એડમિન કંટ્રોલ વિનંતી"}
            </h1>
            <p className="text-xs text-slate-400">
              {lang === "en" ? "Fill candidate profile below for senior approval" : "એડમિન મંજૂરી માટે તમારી વિગતો ભરો"}
            </p>
          </div>

          {signupSuccess ? (
            <div className="space-y-4 text-center">
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/40 rounded-xl space-y-2">
                <p className="font-bold text-sm">
                  {lang === "en" ? "Request Submitted Successfully!" : "વિનંતી સફળતાપૂર્વક સબમિટ થઈ!"}
                </p>
                <p className="text-xs">
                  {lang === "en" 
                    ? "Your candidate information is registered. Please ask a master administrator to approve your account from their user panel." 
                    : "તારીખ અને વિગતો નોંધી લેવામાં આવી છે. કૃપા કરીને વરિષ્ઠ એડમિનિસ્ટ્રેટર દ્વારા મંજૂરી મેળવો."}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsSigningUp(false)}
                className="w-full py-2.5 bg-indigo-600 text-white font-bold text-xs rounded-xl"
              >
                {lang === "en" ? "Back to Login Portal" : "પ્રવેશ પોર્ટલ પર પાછા જાઓ"}
              </button>
            </div>
          ) : (
            <form onSubmit={async (e) => {
              e.preventDefault();
              setSignupError("");
              setIsSubmittingSignup(true);
              try {
                const response = await fetch("/api/auth/admin-signup", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ name: signupName, email: signupEmail, password: signupPassword }),
                });
                const data = await response.json();
                if (!response.ok) {
                  throw new Error(data.error || "Signup failed");
                }
                setSignupSuccess(true);
                setSignupName("");
                setSignupEmail("");
                setSignupPassword("");
              } catch (err: any) {
                setSignupError(err.message);
              } finally {
                setIsSubmittingSignup(false);
              }
            }} className="space-y-4 text-xs md:text-sm">
              {signupError && (
                <div className="p-3 bg-red-50 text-rose-600 border border-red-100 rounded-lg flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{signupError}</span>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="block font-semibold text-slate-500 uppercase tracking-wide">
                  {lang === "en" ? "Full Name:" : "પૂરું નામ:"}
                </label>
                <input
                  type="text"
                  value={signupName}
                  onChange={(e) => setSignupName(e.target.value)}
                  required
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-700 dark:text-white"
                  placeholder={lang === "en" ? "e.g. Harish Kumar" : "તમારું આખું નામ"}
                />
              </div>

              <div className="space-y-1.5">
                <label className="block font-semibold text-slate-500 uppercase tracking-wide">
                  {lang === "en" ? "Email Address:" : "ઇમેઇલ એડ્રેસ:"}
                </label>
                <input
                  type="email"
                  value={signupEmail}
                  onChange={(e) => setSignupEmail(e.target.value)}
                  required
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-700 dark:text-white"
                  placeholder="e.g. harish@example.com"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block font-semibold text-slate-500 uppercase tracking-wide">
                  {lang === "en" ? "Choose Password:" : "ગુપ્ત પાસવર્ડ:"}
                </label>
                <input
                  type="password"
                  value={signupPassword}
                  onChange={(e) => setSignupPassword(e.target.value)}
                  required
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-700 dark:text-white"
                  placeholder="••••••••"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmittingSignup}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-semibold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow"
              >
                <UserPlus className="w-4 h-4" />
                <span>{isSubmittingSignup ? "Requesting..." : (lang === "en" ? "Submit Registration Request" : "નોંધણી વિનંતી સબમિટ કરો")}</span>
              </button>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => setIsSigningUp(false)}
                  className="text-xs text-slate-400 hover:text-indigo-600 hover:underline"
                >
                  {lang === "en" ? "Already have access? Log In here →" : "પહેલાથી એડમિન છો? લોગઇન કરો →"}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  // Layout Login Screen if not authenticated
  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto py-12 px-4 font-sans animate-fade-in no-copy-protect">
        <div className="rounded-2xl glass-card p-8 border border-white/30 dark:border-slate-800 space-y-6">
          <div className="text-center space-y-2">
            <div className="p-3 bg-indigo-50 dark:bg-slate-900 rounded-full w-fit mx-auto text-indigo-600">
              <Key className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold font-serif-literata text-slate-800 dark:text-white">
              {lang === "en" ? "CMS Admin Control Portal" : "નિયંત્રણ પેનલ પ્રવેશ"}
            </h1>
            <p className="text-xs text-slate-400">
              {lang === "en" ? "Authorized personnel log in below" : "સત્તાધિકારીઓ માટે સુરક્ષિત લોગઇન પદ્ધતિ"}
            </p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs md:text-sm">
            {loginError && (
              <div className="p-3 bg-red-50 text-rose-600 border border-red-100 rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="block font-semibold text-slate-500 uppercase tracking-wide">
                {lang === "en" ? "Email Address:" : "ઇમેઇલ એડ્રેસ:"}
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-700 dark:text-white"
                placeholder={lang === "en" ? "Admin email address" : "વહીવટકર્તા ઇમેઇલ"}
              />
            </div>

            <div className="space-y-1.5">
              <label className="block font-semibold text-slate-500 uppercase tracking-wide">
                {lang === "en" ? "Secret Password:" : "ગુપ્ત પાસવર્ડ:"}
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-slate-700 dark:text-white"
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <LogIn className="w-4 h-4" />
              <span>{lang === "en" ? "Verify Security" : "પ્રવેશ ચકાસણી કરો"}</span>
            </button>
          </form>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-center">
            <button
              type="button"
              onClick={() => {
                setIsSigningUp(true);
                setLoginError("");
                setSignupSuccess(false);
                setSignupError("");
              }}
              className="text-xs text-indigo-600 font-bold hover:underline"
            >
              {lang === "en" ? "New Administrator? Request CMS Access Here →" : "નવા એડમિન છો? પ્રવેશ વિનંતી કરો →"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 font-sans animate-fade-in no-copy-protect">
      {/* Title & Stats */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-light pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-bold font-serif-literata text-slate-800 dark:text-white">
              {lang === "en" ? "CMS Control Dashboard" : "નિયંત્રણ ડેશબોર્ડ (CMS)"}
            </h1>
            <span className="text-xs bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded font-bold font-sans">
              Admin Mode
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {lang === "en"
              ? "Instantly edit, update, upload files, manage professional directories, and read system logs."
              : "પ્લેટફોર્મની બધી માહિતી, સંસાધનો અને પીડીએફ વિગતો અહીંથી અપડેટ કરો."}
          </p>
        </div>

        <button
          onClick={onLogout}
          className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-bold rounded-xl transition cursor-pointer self-start md:self-auto"
        >
          {lang === "en" ? "Logout Control Panel" : "પેનલમાંથી બહાર નીકળો (Logout)"}
        </button>
      </div>

      {/* Control Tabs Rails layout */}
      <div className="flex flex-wrap gap-1.5 bg-slate-100/80 dark:bg-slate-900/80 p-1.5 rounded-xl">
        {(["home", "updates", "dictation", "library", "downloads", "directory", "utilities", "about", "footer", "quicklinks", "auditlogs", "adminusers", "feedbacks"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold capitalize transition cursor-pointer ${
              activeTab === tab
                ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"
            }`}
          >
            {tab === "downloads" ? (lang === "en" ? "Downloads" : "ડાઉનલોડ્સ") : 
             tab === "adminusers" ? (lang === "en" ? "Admin Controls" : "એડમિન યુઝર્સ") :
             tab === "feedbacks" ? (lang === "en" ? "User Feedbacks" : "ફીડબેક પત્રકો") :
             tab === "auditlogs" ? "Audit Logs" :
             tab === "quicklinks" ? "Quick Links" :
             tab === "utilities" ? (lang === "en" ? "Utility Pages" : "ઉપયોગિતાઓ (Pages)") :
             tab}
          </button>
        ))}
      </div>

      {/* Primary Tab content loaders */}
      <div className="rounded-2xl glass-card p-6 border border-white/20 dark:border-slate-800/80 space-y-6">

        {/* TAB 1: HOME PAGE TEXT CONTENT EDITORS */}
        {activeTab === "home" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex justify-between items-center border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "Home Text Blocks & Navigation Theme Editor" : "હોમ પેજ અને હેડર થીમ સુધારક"}
              </h2>
              <button
                onClick={() => handleSaveState(localDb, "Updated Home Text and Design Themes")}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{lang === "en" ? "Save Changes" : "માહિતી સાચવો"}</span>
              </button>
            </div>

            {/* Header & Logo Customization Console */}
            <div className="bg-slate-50 dark:bg-slate-900/60 p-4 rounded-xl border border-slate-200/50 dark:border-slate-800 space-y-4">
              <h3 className="font-bold text-xs uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                🎨 Header Logo, Sizing & Custom Color Themes (Admin Configurable)
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Logo Control */}
                <div className="space-y-1.5">
                  <span className="block font-semibold text-slate-400 uppercase text-[10px]">Header Logo Image:</span>
                  <div className="flex gap-3 items-center">
                    <div className="w-12 h-12 rounded border bg-slate-150 dark:bg-slate-900 overflow-hidden shrink-0 flex items-center justify-center p-0.5">
                      <img src={localDb.header.logoUrl || "https://laghulipi.com/logo.png"} className="w-full h-full object-contain col-auto" />
                    </div>
                    <input
                      type="file"
                      onChange={(e) => handleFileUpload(e, "header.logoUrl")}
                      className="text-[11px] file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-[11px] file:font-bold file:bg-indigo-50 file:text-indigo-600 dark:file:bg-indigo-950/40 dark:file:text-indigo-400 hover:file:bg-indigo-100"
                    />
                  </div>
                </div>

                {/* Logo Size Control */}
                <div className="space-y-1.5">
                  <span className="block font-semibold text-slate-400 uppercase text-[10px]">
                    Logo Length Size ({localDb.header.logoSize || 80}px):
                  </span>
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="range"
                      min="40"
                      max="250"
                      step="5"
                      value={localDb.header.logoSize || 80}
                      onChange={(e) => {
                        const u = { ...localDb };
                        u.header.logoSize = parseInt(e.target.value);
                        setLocalDb(u);
                      }}
                      className="w-full accent-indigo-600 bg-slate-200 dark:bg-slate-805 h-1 rounded"
                    />
                    <span className="text-xs font-mono font-bold text-indigo-600 dark:text-indigo-400">{localDb.header.logoSize || 80}px</span>
                  </div>
                </div>

                {/* Tagline Edit (Gujarati) */}
                <div className="space-y-1.5">
                  <span className="block font-semibold text-slate-400 uppercase text-[10px]">Site Tagline (Gujarati):</span>
                  <input
                    type="text"
                    value={localDb.header.taglineGu || ""}
                    onChange={(e) => {
                      const u = { ...localDb };
                      u.header.taglineGu = e.target.value;
                      setLocalDb(u);
                    }}
                    className="w-full text-xs p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    placeholder="Tagline Gujarati"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Title En & Gu */}
                <div className="space-y-1.5">
                  <span className="block font-semibold text-slate-400 uppercase text-[10px]">Title Banner (English):</span>
                  <input
                    type="text"
                    value={localDb.header.titleEn || ""}
                    onChange={(e) => {
                      const u = { ...localDb };
                      u.header.titleEn = e.target.value;
                      setLocalDb(u);
                    }}
                    className="w-full text-xs p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded outline-none font-bold"
                    placeholder="E.g. LaghuLipi.com"
                  />
                </div>

                <div className="space-y-1.5">
                  <span className="block font-semibold text-slate-400 uppercase text-[10px]">Title Banner (Gujarati):</span>
                  <input
                    type="text"
                    value={localDb.header.titleGu || ""}
                    onChange={(e) => {
                      const u = { ...localDb };
                      u.header.titleGu = e.target.value;
                      setLocalDb(u);
                    }}
                    className="w-full text-xs p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded outline-none font-bold"
                    placeholder="E.g. લઘુલિપિ.com"
                  />
                </div>
              </div>

              {/* Advanced Colors Panel Area */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-1">
                {/* Header Bg */}
                <div className="space-y-1.5">
                  <span className="block font-semibold text-slate-400 uppercase text-[10px]">Header Background (Solid & Gradient Controls):</span>
                  {(() => {
                    const grad = parseGradient(localDb.header.headerBg || "");
                    return (
                      <div className="space-y-3.5 pt-1.5 pb-2.5">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="checkbox"
                            id="header-gradient-checkbox"
                            checked={grad.enabled}
                            onChange={(e) => {
                              const u = { ...localDb };
                              if (e.target.checked) {
                                  u.header.headerBg = `linear-gradient(${grad.angle}deg, ${grad.start} 0%, ${grad.end} 100%)`;
                              } else {
                                  u.header.headerBg = grad.start;
                              }
                              setLocalDb(u);
                            }}
                            className="w-3.5 h-3.5 accent-indigo-600 rounded cursor-pointer"
                          />
                          <label htmlFor="header-gradient-checkbox" className="text-xs font-semibold text-slate-600 dark:text-slate-300 cursor-pointer select-none">
                            Enable Background Gradient Effect
                          </label>
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-1">
                            <span className="block text-[9px] text-slate-400 font-bold uppercase">Color 1 (Solid / Start):</span>
                            <div className="flex gap-1.5">
                              <input
                                type="color"
                                value={grad.start}
                                onChange={(e) => {
                                  const u = { ...localDb };
                                  if (grad.enabled) {
                                    u.header.headerBg = `linear-gradient(${grad.angle}deg, ${e.target.value} 0%, ${grad.end} 100%)`;
                                  } else {
                                    u.header.headerBg = e.target.value;
                                  }
                                  setLocalDb(u);
                                }}
                                className="w-8 h-8 rounded shrink-0 cursor-pointer border border-slate-300"
                              />
                              <input
                                type="text"
                                value={grad.start}
                                onChange={(e) => {
                                  const u = { ...localDb };
                                  if (grad.enabled) {
                                    u.header.headerBg = `linear-gradient(${grad.angle}deg, ${e.target.value} 0%, ${grad.end} 100%)`;
                                  } else {
                                    u.header.headerBg = e.target.value;
                                  }
                                  setLocalDb(u);
                                }}
                                className="w-full text-[11px] px-1.5 py-0.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded font-mono"
                              />
                            </div>
                          </div>

                          {grad.enabled && (
                            <div className="space-y-1 animate-fade-in">
                              <span className="block text-[9px] text-slate-400 font-bold uppercase">Color 2 (End):</span>
                              <div className="flex gap-1.5">
                                <input
                                  type="color"
                                  value={grad.end}
                                  onChange={(e) => {
                                    const u = { ...localDb };
                                    u.header.headerBg = `linear-gradient(${grad.angle}deg, ${grad.start} 0%, ${e.target.value} 100%)`;
                                    setLocalDb(u);
                                  }}
                                  className="w-8 h-8 rounded shrink-0 cursor-pointer border border-slate-300"
                                />
                                <input
                                  type="text"
                                  value={grad.end}
                                  onChange={(e) => {
                                    const u = { ...localDb };
                                    u.header.headerBg = `linear-gradient(${grad.angle}deg, ${grad.start} 0%, ${e.target.value} 100%)`;
                                    setLocalDb(u);
                                  }}
                                  className="w-full text-[11px] px-1.5 py-0.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded font-mono"
                                />
                              </div>
                            </div>
                          )}
                        </div>

                        {grad.enabled && (
                          <div className="space-y-1 pt-0.5 animate-fade-in">
                            <span className="block text-[9px] text-slate-400 font-bold uppercase">Angle Degree ({grad.angle}°):</span>
                            <div className="flex items-center gap-3">
                              <input
                                type="range"
                                min="0"
                                max="360"
                                value={grad.angle}
                                onChange={(e) => {
                                  const u = { ...localDb };
                                  u.header.headerBg = `linear-gradient(${e.target.value}deg, ${grad.start} 0%, ${grad.end} 100%)`;
                                  setLocalDb(u);
                                }}
                                className="w-full accent-indigo-600 bg-slate-200 dark:bg-slate-800 h-1 rounded cursor-pointer"
                              />
                              <span className="text-xs font-mono font-bold text-slate-500">{grad.angle}°</span>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                  <div className="hidden">
                    <input
                      type="color"
                      value={localDb.header.headerBg && localDb.header.headerBg.startsWith("#") ? localDb.header.headerBg : "#ffffff"}
                      onChange={(e) => {
                        const u = { ...localDb };
                        u.header.headerBg = e.target.value;
                        setLocalDb(u);
                      }}
                      className="w-8 h-8 rounded cursor-pointer border border-slate-300"
                    />
                    <input
                      type="text"
                      value={localDb.header.headerBg || ""}
                      onChange={(e) => {
                        const u = { ...localDb };
                        u.header.headerBg = e.target.value;
                        setLocalDb(u);
                      }}
                      className="w-full text-xs px-2 py-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded font-mono"
                      placeholder="e.g. #ffffff"
                    />
                  </div>
                </div>

                {/* Header Text */}
                <div className="space-y-1.5">
                  <span className="block font-semibold text-slate-400 uppercase text-[10px]">Header & Footer Text Color:</span>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={localDb.header.headerTextColor && localDb.header.headerTextColor.startsWith("#") ? localDb.header.headerTextColor : "#1e293b"}
                      onChange={(e) => {
                        const u = { ...localDb };
                        u.header.headerTextColor = e.target.value;
                        setLocalDb(u);
                      }}
                      className="w-8 h-8 rounded cursor-pointer border border-slate-300"
                    />
                    <input
                      type="text"
                      value={localDb.header.headerTextColor || ""}
                      onChange={(e) => {
                        const u = { ...localDb };
                        u.header.headerTextColor = e.target.value;
                        setLocalDb(u);
                      }}
                      className="w-full text-xs px-2 py-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded font-mono"
                      placeholder="e.g. #1e293b"
                    />
                  </div>
                </div>

                {/* Menu Bg */}
                <div className="space-y-1.5">
                  <span className="block font-semibold text-slate-400 uppercase text-[10px]">MenuBar Background:</span>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={localDb.header.menuBg && localDb.header.menuBg.startsWith("#") ? localDb.header.menuBg : "#EAEFF5"}
                      onChange={(e) => {
                        const u = { ...localDb };
                        u.header.menuBg = e.target.value;
                        setLocalDb(u);
                      }}
                      className="w-8 h-8 rounded cursor-pointer border border-slate-300"
                    />
                    <input
                      type="text"
                      value={localDb.header.menuBg || ""}
                      onChange={(e) => {
                        const u = { ...localDb };
                        u.header.menuBg = e.target.value;
                        setLocalDb(u);
                      }}
                      className="w-full text-xs px-2 py-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded font-mono"
                      placeholder="e.g. #EAEFF5"
                    />
                  </div>
                </div>

                {/* Menu Text */}
                <div className="space-y-1.5">
                  <span className="block font-semibold text-slate-400 uppercase text-[10px]">MenuBar Text Color:</span>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={localDb.header.menuTextColor && localDb.header.menuTextColor.startsWith("#") ? localDb.header.menuTextColor : "#475569"}
                      onChange={(e) => {
                        const u = { ...localDb };
                        u.header.menuTextColor = e.target.value;
                        setLocalDb(u);
                      }}
                      className="w-8 h-8 rounded cursor-pointer border border-slate-300"
                    />
                    <input
                      type="text"
                      value={localDb.header.menuTextColor || ""}
                      onChange={(e) => {
                        const u = { ...localDb };
                        u.header.menuTextColor = e.target.value;
                        setLocalDb(u);
                      }}
                      className="w-full text-xs px-2 py-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded font-mono"
                      placeholder="e.g. #475569"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <span className="block font-semibold text-slate-400 uppercase text-[10px]">Site Tagline (English):</span>
                <input
                  type="text"
                  value={localDb.header.taglineEn || ""}
                  onChange={(e) => {
                    const u = { ...localDb };
                    u.header.taglineEn = e.target.value;
                    setLocalDb(u);
                  }}
                  className="w-full text-xs p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                  placeholder="Tagline English"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* English */}
              <div className="space-y-4 p-4 border border-indigo-100/50 rounded-xl bg-indigo-50/5">
                <h3 className="font-bold text-indigo-600 uppercase tracking-wide text-xs">English Fields</h3>
                <div className="space-y-2">
                  <label>Welcome Title:</label>
                  <input
                    type="text"
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={localDb.homeContent.welcomeTitleEn}
                    onChange={(e) => {
                      const u = { ...localDb };
                      u.homeContent.welcomeTitleEn = e.target.value;
                      setLocalDb(u);
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <label>Welcome Text Description:</label>
                  <textarea
                    rows={4}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={localDb.homeContent.welcomeTextEn}
                    onChange={(e) => {
                      const u = { ...localDb };
                      u.homeContent.welcomeTextEn = e.target.value;
                      setLocalDb(u);
                    }}
                  />
                </div>
              </div>

              {/* Gujarati */}
              <div className="space-y-4 p-4 border border-amber-100/50 rounded-xl bg-amber-50/5">
                <h3 className="font-bold text-amber-600 uppercase tracking-wide text-xs">Gujarati Fields</h3>
                <div className="space-y-2">
                  <label>Welcome Title:</label>
                  <input
                    type="text"
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={localDb.homeContent.welcomeTitleGu}
                    onChange={(e) => {
                      const u = { ...localDb };
                      u.homeContent.welcomeTitleGu = e.target.value;
                      setLocalDb(u);
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <label>Welcome Text Description:</label>
                  <textarea
                    rows={4}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={localDb.homeContent.welcomeTextGu}
                    onChange={(e) => {
                      const u = { ...localDb };
                      u.homeContent.welcomeTextGu = e.target.value;
                      setLocalDb(u);
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Platform Overview Edit */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="font-bold">Overview Text (English):</label>
                <textarea
                  rows={3}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                  value={localDb.homeContent.overviewContentEn}
                  onChange={(e) => {
                    const u = { ...localDb };
                    u.homeContent.overviewContentEn = e.target.value;
                    setLocalDb(u);
                  }}
                />
              </div>

              <div className="space-y-2">
                <label className="font-bold">Overview Text (Gujarati):</label>
                <textarea
                  rows={3}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                  value={localDb.homeContent.overviewContentGu}
                  onChange={(e) => {
                    const u = { ...localDb };
                    u.homeContent.overviewContentGu = e.target.value;
                    setLocalDb(u);
                  }}
                />
              </div>
            </div>

            {/* Bento Cards Customization Console */}
            <div className="bg-slate-50 dark:bg-slate-900/40 p-4 rounded-xl border border-slate-200/50 dark:border-slate-800 space-y-4">
              <h3 className="font-bold text-xs uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-500" />
                🚀 Home Screen Bento Cards Config (Interactive Modules)
              </h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {(localDb.homeContent.bentoCards || []).map((card, idx) => (
                  <div key={card.id || idx} className="p-4 border border-slate-200 dark:border-slate-800/80 rounded-xl bg-white dark:bg-slate-950/40 space-y-3 shadow-sm">
                    <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-1.5">
                      <span className="font-bold text-slate-700 dark:text-slate-300 text-[11px] uppercase">
                        Bento Module {idx + 1}: {card.id === "bc1" ? "Practice Dictation" : card.id === "bc2" ? "Library" : card.id === "bc3" ? "Directory" : "Utilities Portal"}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[10px] text-slate-400 block font-semibold uppercase">Title (En):</label>
                        <input
                          type="text"
                          className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none text-xs"
                          value={card.titleEn}
                          onChange={(e) => {
                            const u = { ...localDb };
                            u.homeContent.bentoCards[idx].titleEn = e.target.value;
                            setLocalDb(u);
                          }}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] text-slate-400 block font-semibold uppercase">Title (Gu):</label>
                        <input
                          type="text"
                          className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none text-xs"
                          value={card.titleGu}
                          onChange={(e) => {
                            const u = { ...localDb };
                            u.homeContent.bentoCards[idx].titleGu = e.target.value;
                            setLocalDb(u);
                          }}
                        />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 block font-semibold uppercase">Description (En):</label>
                      <textarea
                        rows={2}
                        className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none text-xs"
                        value={card.descEn}
                        onChange={(e) => {
                          const u = { ...localDb };
                          u.homeContent.bentoCards[idx].descEn = e.target.value;
                          setLocalDb(u);
                        }}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 block font-semibold uppercase">Description (Gu):</label>
                      <textarea
                        rows={2}
                        className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none text-xs"
                        value={card.descGu}
                        onChange={(e) => {
                          const u = { ...localDb };
                          u.homeContent.bentoCards[idx].descGu = e.target.value;
                          setLocalDb(u);
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Platform Objectives Customization Console */}
            <div className="bg-slate-50 dark:bg-slate-900/40 p-4 rounded-xl border border-slate-200/50 dark:border-slate-800 space-y-4">
              <h3 className="font-bold text-xs uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                🎯 Platform Objectives & Key Features List
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="font-semibold block text-xs">Objectives Category Heading (En):</label>
                  <input
                    type="text"
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none text-xs"
                    value={localDb.homeContent.objectivesHeadingEn || ""}
                    onChange={(e) => {
                      const u = { ...localDb };
                      u.homeContent.objectivesHeadingEn = e.target.value;
                      setLocalDb(u);
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <label className="font-semibold block text-xs">Objectives Category Heading (Gu):</label>
                  <input
                    type="text"
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none text-xs"
                    value={localDb.homeContent.objectivesHeadingGu || ""}
                    onChange={(e) => {
                      const u = { ...localDb };
                      u.homeContent.objectivesHeadingGu = e.target.value;
                      setLocalDb(u);
                    }}
                  />
                </div>
              </div>

              {/* Objectives List Editors (English and Gujarati alongside list item index syncing) */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
                {/* English Objectives */}
                <div className="space-y-3 p-4 border border-indigo-50/50 dark:border-indigo-950/50 bg-indigo-50/5 dark:bg-slate-950/20 rounded-xl">
                  <div className="flex justify-between items-center pb-1 border-b border-indigo-100/40">
                    <span className="font-bold text-indigo-600 text-[11px] uppercase">Goal Bullet Points (English)</span>
                    <button
                      onClick={() => {
                        const u = { ...localDb };
                        if (!u.homeContent.objectivesEn) u.homeContent.objectivesEn = [];
                        u.homeContent.objectivesEn.push("New English objective bullet point text");
                        setLocalDb(u);
                      }}
                      className="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[10px] font-bold cursor-pointer"
                    >
                      + Add Item
                    </button>
                  </div>
                  <div className="space-y-2">
                    {(localDb.homeContent.objectivesEn || []).map((obj, i) => (
                      <div key={i} className="flex gap-2">
                        <span className="w-5 text-center shrink-0 text-xs font-mono font-bold text-slate-400 self-center">{i + 1}.</span>
                        <input
                          type="text"
                          className="flex-1 p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none text-xs"
                          value={obj}
                          onChange={(e) => {
                            const u = { ...localDb };
                            u.homeContent.objectivesEn[i] = e.target.value;
                            setLocalDb(u);
                          }}
                        />
                        <button
                          onClick={() => {
                            const u = { ...localDb };
                            u.homeContent.objectivesEn.splice(i, 1);
                            setLocalDb(u);
                          }}
                          className="p-1 px-2.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded text-xs border border-rose-100 dark:border-rose-950/40 cursor-pointer"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Gujarati Objectives */}
                <div className="space-y-3 p-4 border border-amber-50/50 dark:border-amber-950/50 bg-amber-50/5 dark:bg-slate-950/20 rounded-xl">
                  <div className="flex justify-between items-center pb-1 border-b border-amber-100/40">
                    <span className="font-bold text-amber-600 text-[11px] uppercase">Goal Bullet Points (Gujarati)</span>
                    <button
                      onClick={() => {
                        const u = { ...localDb };
                        if (!u.homeContent.objectivesGu) u.homeContent.objectivesGu = [];
                        u.homeContent.objectivesGu.push("નવું ગુજરાતી ઉદ્દેશ બુલેટ પોઇન્ટ લખાણ");
                        setLocalDb(u);
                      }}
                      className="px-2 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded text-[10px] font-bold cursor-pointer"
                    >
                      + Add Item
                    </button>
                  </div>
                  <div className="space-y-2">
                    {(localDb.homeContent.objectivesGu || []).map((obj, i) => (
                      <div key={i} className="flex gap-2">
                        <span className="w-5 text-center shrink-0 text-xs font-mono font-bold text-slate-400 self-center">{i + 1}.</span>
                        <input
                          type="text"
                          className="flex-1 p-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded outline-none text-xs"
                          value={obj}
                          onChange={(e) => {
                            const u = { ...localDb };
                            u.homeContent.objectivesGu[i] = e.target.value;
                            setLocalDb(u);
                          }}
                        />
                        <button
                          onClick={() => {
                            const u = { ...localDb };
                            u.homeContent.objectivesGu.splice(i, 1);
                            setLocalDb(u);
                          }}
                          className="p-1 px-2.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded text-xs border border-rose-100 dark:border-rose-950/40 cursor-pointer"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: UPDATES LIST & PDF CIRCULARS */}
        {activeTab === "updates" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex justify-between items-center border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "System Bulletin Board & Circulars" : "નવીનતમ અપડેટ્સ અને પરિપપત્રો"}
              </h2>
              <button
                onClick={() => {
                  const items = [...localDb.updates];
                  const id = "up_" + Date.now();
                  items.unshift({
                    id,
                    textEn: "New notification declared",
                    textGu: "નવી સત્તાવાર જાહેરાત જાહેર",
                    date: new Date().toISOString().split("T")[0]
                  });
                  const updated = { ...localDb, updates: items };
                  handleSaveState(updated, "Added new update placeholder");
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{lang === "en" ? "Add Bulletin Update" : "નવું નોટિફિકેશન ઉમેરો"}</span>
              </button>
            </div>

            <div className="space-y-4">
              {localDb.updates.map((item) => (
                <div
                  key={item.id}
                  className="p-4 rounded-xl border border-slate-150 dark:border-slate-800 bg-white/40 space-y-3 relative"
                >
                  <button
                    onClick={() => {
                      const filtered = localDb.updates.filter(u => u.id !== item.id);
                      handleSaveState({ ...localDb, updates: filtered }, "Deleted updates bulletin info");
                    }}
                    className="absolute top-4 right-4 p-1.5 text-rose-500 hover:bg-rose-50 rounded cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <label>English Outline:</label>
                      <input
                        type="text"
                        className="w-full text-xs p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                        value={item.textEn}
                        onChange={(e) => {
                          const items = localDb.updates.map(u => u.id === item.id ? { ...u, textEn: e.target.value } : u);
                          setLocalDb({ ...localDb, updates: items });
                        }}
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Gujarati Outline:</label>
                      <input
                        type="text"
                        className="w-full text-xs p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                        value={item.textGu}
                        onChange={(e) => {
                          const items = localDb.updates.map(u => u.id === item.id ? { ...u, textGu: e.target.value } : u);
                          setLocalDb({ ...localDb, updates: items });
                        }}
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Date:</label>
                      <input
                        type="date"
                        className="w-full text-xs p-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                        value={item.date}
                        onChange={(e) => {
                          const items = localDb.updates.map(u => u.id === item.id ? { ...u, date: e.target.value } : u);
                          setLocalDb({ ...localDb, updates: items });
                        }}
                      />
                    </div>
                  </div>

                  {/* Attachment PDF circular upload */}
                  <div className="flex flex-wrap items-center gap-4 bg-slate-50 dark:bg-slate-900/60 p-3 rounded-lg">
                    <span className="font-semibold text-slate-400 text-[10px] uppercase">PDF Circular Attachment:</span>
                    {item.pdfUrl ? (
                      <span className="text-xs text-indigo-600 font-mono underline truncate max-w-xs">{item.pdfUrl}</span>
                    ) : (
                      <span className="text-xs text-slate-400">No Document Attached</span>
                    )}
                    <input
                      type="file"
                      id={`file_input_${item.id}`}
                      className="hidden"
                      accept=".pdf"
                      onChange={(e) => handleFileUpload(e, `update_${item.id}`)}
                    />
                    <button
                      onClick={() => document.getElementById(`file_input_${item.id}`)?.click()}
                      className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded text-xs font-semibold cursor-pointer"
                    >
                      <Upload className="w-3 h-3 inline mr-1" />
                      Upload PDF
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => handleSaveState(localDb, "Saved Updates modifications")}
              className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold float-right cursor-pointer"
            >
              Save Bulletins
            </button>
          </div>
        )}

        {/* TAB 3: DICTATION WORDS-PHRASES & PARAGRAPHS EDITORS */}
        {activeTab === "dictation" && (
          <div className="space-y-8 text-xs md:text-sm">
            {/* WORDS PHRASES COMPONENT EDITOR */}
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b border-light pb-2">
                <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                  {lang === "en" ? "Manage Words & Phrases" : "શબ્દો અને રૂઢિપ્રયોગો સુધારક"}
                </h2>
                <button
                  onClick={() => {
                    const id = "wd_" + Date.now();
                    const newW: WordItem = {
                      id,
                      wordEn: "New word",
                      wordGu: "નવો શબ્દ",
                      phraseEn: "New phrase outlined here",
                      phraseGu: "નવી સંઘાત",
                    };
                    setEditingWord(newW);
                  }}
                  className="px-3.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-xl text-xs font-bold cursor-pointer"
                >
                  + Add Word Outline
                </button>
              </div>

              {editingWord && (
                <div className="p-4 rounded-xl border border-indigo-100 bg-indigo-50/15 space-y-4 animate-fade-in relative">
                  <h3 className="font-bold font-serif-literata">Editing Word Details</h3>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <input
                      type="text"
                      className="p-2 border border-slate-200 rounded text-xs bg-white dark:bg-slate-900 text-slate-800 dark:text-white"
                      value={editingWord.wordEn}
                      onChange={(e) => setEditingWord({ ...editingWord, wordEn: e.target.value })}
                      placeholder="Word (EN)"
                    />
                    <input
                      type="text"
                      className="p-2 border border-slate-200 rounded text-xs bg-white dark:bg-slate-900 text-slate-800 dark:text-white"
                      value={editingWord.wordGu}
                      onChange={(e) => setEditingWord({ ...editingWord, wordGu: e.target.value })}
                      placeholder="Word (GU)"
                    />
                    <input
                      type="text"
                      className="p-2 border border-slate-200 rounded text-xs bg-white dark:bg-slate-900 text-slate-800 dark:text-white"
                      value={editingWord.phraseEn}
                      onChange={(e) => setEditingWord({ ...editingWord, phraseEn: e.target.value })}
                      placeholder="Phrase (EN)"
                    />
                    <input
                      type="text"
                      className="p-2 border border-slate-200 rounded text-xs bg-white dark:bg-slate-900 text-slate-800 dark:text-white"
                      value={editingWord.phraseGu}
                      onChange={(e) => setEditingWord({ ...editingWord, phraseGu: e.target.value })}
                      placeholder="Phrase (GU)"
                    />
                  </div>

                  {/* Word voice attachment picker */}
                  <div className="flex items-center gap-4 text-xs">
                    <span className="font-bold">Audio File (Optional):</span>
                    <input
                      type="file"
                      accept="audio/*"
                      onChange={(e) => handleFileUpload(e, `word_${editingWord.id}`)}
                    />
                    {editingWord.audioUrl && (
                      <span className="text-[10px] font-mono text-indigo-500">{editingWord.audioUrl}</span>
                    )}
                  </div>

                  <div className="flex gap-2 justify-end text-xs">
                    <button
                      onClick={() => setEditingWord(null)}
                      className="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-800 rounded font-bold cursor-pointer"
                    >
                      Discard
                    </button>
                    <button
                      onClick={async () => {
                        const wordExists = localDb.words.some(w => w.id === editingWord.id);
                        let upWords = [];
                        if (wordExists) {
                          upWords = localDb.words.map(w => w.id === editingWord.id ? editingWord : w);
                        } else {
                          upWords = [...localDb.words, editingWord];
                        }
                        const u = { ...localDb, words: upWords };
                        await handleSaveState(u, "Added/Edited Single Word Outline entry");
                        setEditingWord(null);
                      }}
                      className="px-4 py-2 bg-indigo-600 text-white rounded font-bold cursor-pointer"
                    >
                      Save Word
                    </button>
                  </div>
                </div>
              )}

              {/* Word List Table */}
              <div className="max-h-60 overflow-y-auto border border-slate-100 rounded-lg">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 dark:bg-slate-900 font-bold text-[10px] uppercase">
                    <tr>
                      <th className="p-3">Word (EN/GU)</th>
                      <th className="p-3">Phrase (EN/GU)</th>
                      <th className="p-3">Audio attached</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {localDb.words.map(w => (
                      <tr key={w.id} className="border-t border-slate-100 dark:border-slate-800">
                        <td className="p-3 font-semibold">{w.wordEn} ({w.wordGu})</td>
                        <td className="p-3">{w.phraseEn} <span className="text-slate-400">({w.phraseGu})</span></td>
                        <td className="p-3">{w.audioUrl ? "✅ Yes" : "❌ No Fallback Speech"}</td>
                        <td className="p-3 text-right flex gap-1 justify-end">
                          <button
                            onClick={() => setEditingWord(w)}
                            className="p-1 hover:bg-slate-50 rounded text-indigo-600 cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              const filtered = localDb.words.filter(item => item.id !== w.id);
                              handleSaveState({ ...localDb, words: filtered }, `Deleted word outline ${w.wordEn}`);
                            }}
                            className="p-1 hover:bg-slate-50 rounded text-rose-500 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* PARAGRAPHS SPEED MANAGE COMPONENT */}
            <div className="space-y-4 border-t border-slate-100 dark:border-slate-800 pt-6">
              <div className="flex justify-between items-center border-b border-light pb-2">
                <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                  {lang === "en" ? "Manage ShortHand Paragraphs" : "શ્રુતલેખન ફકરો સંચાલક"}
                </h2>
                <button
                  onClick={() => {
                    const id = "para_" + Date.now();
                    const newP: ParagraphItem = {
                      id,
                      titleEn: "New Paragraph",
                      titleGu: "નવો ફકરો",
                      topicEn: "General",
                      topicGu: "સામાન્ય",
                      speed: 60,
                      narrator: "Jitendra Soni",
                      transcript: "Type shorthand transcription words here..."
                    };
                    setEditingPara(newP);
                  }}
                  className="px-3.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-xl text-xs font-bold cursor-pointer"
                >
                  + Add Paragraph Speeds Item
                </button>
              </div>

              {editingPara && (
                <div className="p-5 rounded-xl border border-indigo-100 bg-indigo-50/15 space-y-4 animate-fade-in">
                  <h3 className="font-bold font-serif-literata">Editing Dictation Paragraph</h3>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <label>Title (EN):</label>
                      <input
                        type="text"
                        className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                        value={editingPara.titleEn}
                        onChange={(e) => setEditingPara({ ...editingPara, titleEn: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Title (GU):</label>
                      <input
                        type="text"
                        className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                        value={editingPara.titleGu}
                        onChange={(e) => setEditingPara({ ...editingPara, titleGu: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Topic (EN):</label>
                      <input
                        type="text"
                        className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                        value={editingPara.topicEn}
                        onChange={(e) => setEditingPara({ ...editingPara, topicEn: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Topic (GU):</label>
                      <input
                        type="text"
                        className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                        value={editingPara.topicGu}
                        onChange={(e) => setEditingPara({ ...editingPara, topicGu: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label>Speed (WPM):</label>
                      <select
                        className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full text-slate-700 dark:text-white"
                        value={editingPara.speed}
                        onChange={(e) => setEditingPara({ ...editingPara, speed: parseInt(e.target.value) || 60 })}
                      >
                        <option value={60}>60 WPM</option>
                        <option value={75}>75 WPM</option>
                        <option value={90}>90 WPM</option>
                        <option value={100}>100 WPM</option>
                        <option value={120}>120 WPM</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label>Narrator:</label>
                      <input
                        type="text"
                        className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                        value={editingPara.narrator}
                        onChange={(e) => setEditingPara({ ...editingPara, narrator: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label>Dictation Audio File:</label>
                      <input
                        type="file"
                        accept="audio/*"
                        onChange={(e) => handleFileUpload(e, `para_${editingPara.id}`)}
                      />
                      {editingPara.audioUrl && (
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5 max-w-xs overflow-hidden text-ellipsis">{editingPara.audioUrl}</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label>Paragraph Transcript:</label>
                    <textarea
                      rows={5}
                      className="w-full p-2.5 border rounded text-xs bg-white dark:bg-slate-900 text-slate-800 dark:text-white font-sans"
                      value={editingPara.transcript}
                      onChange={(e) => setEditingPara({ ...editingPara, transcript: e.target.value })}
                    />
                  </div>

                  <div className="flex gap-2 justify-end text-xs">
                    <button
                      onClick={() => setEditingPara(null)}
                      className="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-800 rounded font-bold cursor-pointer"
                    >
                      Discard
                    </button>
                    <button
                      onClick={async () => {
                        const exist = localDb.paragraphs.some(p => p.id === editingPara.id);
                        let upParas = [];
                        if (exist) {
                          upParas = localDb.paragraphs.map(p => p.id === editingPara.id ? editingPara : p);
                        } else {
                          upParas = [...localDb.paragraphs, editingPara];
                        }
                        const u = { ...localDb, paragraphs: upParas };
                        await handleSaveState(u, `Added/Edited dictation paragraph: ${editingPara.titleEn}`);
                        setEditingPara(null);
                      }}
                      className="px-4 py-2 bg-indigo-600 text-white rounded font-bold cursor-pointer"
                    >
                      Save Paragraph
                    </button>
                  </div>
                </div>
              )}

              {/* Paras Table */}
              <div className="max-h-60 overflow-y-auto border border-slate-100 rounded-lg">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 dark:bg-slate-900 font-bold text-[10px] uppercase">
                    <tr>
                      <th className="p-3">Title (EN/GU)</th>
                      <th className="p-3">Speed</th>
                      <th className="p-3">Narrator</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {localDb.paragraphs.map(p => (
                      <tr key={p.id} className="border-t border-slate-100 dark:border-slate-800">
                        <td className="p-3 font-semibold">{p.titleEn} ({p.titleGu})</td>
                        <td className="p-3"><span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded text-xs font-bold">{p.speed} WPM</span></td>
                        <td className="p-3">{p.narrator}</td>
                        <td className="p-3 text-right flex gap-1 justify-end">
                          <button
                            onClick={() => setEditingPara(p)}
                            className="p-1 hover:bg-slate-50 rounded text-indigo-600 cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              const filtered = localDb.paragraphs.filter(item => item.id !== p.id);
                              handleSaveState({ ...localDb, paragraphs: filtered }, `Deleted dictation item: ${p.titleEn}`);
                            }}
                            className="p-1 hover:bg-slate-50 rounded text-rose-500 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: LIBRARY PDFS AND BOOK STORES MANAGEMENTS */}
        {activeTab === "library" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex justify-between items-center border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "Manage Library Catalog & E-Books" : "પુસ્તકાલય કેટલોગ સુધારક"}
              </h2>
              <button
                onClick={() => {
                  const id = "b_" + Date.now();
                  const newB: BookItem = {
                    id,
                    titleEn: "New book Title",
                    titleGu: "નવું પુસ્તક",
                    authorEn: "Author",
                    authorGu: "લેખક",
                    descriptionEn: "Long descriptive summaries",
                    descriptionGu: "સંપૂર્ણ ટૂંકી માહિતી",
                    price: 0,
                  };
                  setEditingBook(newB);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{lang === "en" ? "Add Shorthand Book" : "નવું પુસ્તક ઉમેરો"}</span>
              </button>
            </div>

            {editingBook && (
              <div className="p-5 rounded-xl border border-indigo-100 bg-indigo-50/15 space-y-4 animate-fade-in">
                <h3 className="font-bold font-serif-literata">Book Specifications</h3>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <label>Title (EN):</label>
                    <input
                      type="text"
                      className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                      value={editingBook.titleEn}
                      onChange={(e) => setEditingBook({ ...editingBook, titleEn: e.target.value })}
                    />
                  </div>
                  <div className="space-y-1">
                    <label>Title (GU):</label>
                    <input
                      type="text"
                      className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                      value={editingBook.titleGu}
                      onChange={(e) => setEditingBook({ ...editingBook, titleGu: e.target.value })}
                    />
                  </div>
                  <div className="space-y-1">
                    <label>Author (EN):</label>
                    <input
                      type="text"
                      className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                      value={editingBook.authorEn}
                      onChange={(e) => setEditingBook({ ...editingBook, authorEn: e.target.value })}
                    />
                  </div>
                  <div className="space-y-1">
                    <label>Author (GU):</label>
                    <input
                      type="text"
                      className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                      value={editingBook.authorGu}
                      onChange={(e) => setEditingBook({ ...editingBook, authorGu: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label>Price in INR (₹) / 0 representing FREE:</label>
                    <input
                      type="number"
                      className="p-2 border rounded text-xs bg-white dark:bg-slate-900 w-full"
                      value={editingBook.price}
                      onChange={(e) => setEditingBook({ ...editingBook, price: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-1">
                    <label>Cover Photo (PNG/JPG):</label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, `bookCover_${editingBook.id}`)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label>PDF/EBook Document:</label>
                    <input
                      type="file"
                      accept=".pdf,.epub"
                      onChange={(e) => handleFileUpload(e, `bookFile_${editingBook.id}`)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label>Description (EN):</label>
                    <textarea
                      rows={3}
                      className="p-2.5 border rounded text-xs bg-white dark:bg-slate-900 w-full text-slate-800 dark:text-white"
                      value={editingBook.descriptionEn}
                      onChange={(e) => setEditingBook({ ...editingBook, descriptionEn: e.target.value })}
                    />
                  </div>
                  <div className="space-y-1">
                    <label>Description (GU):</label>
                    <textarea
                      rows={3}
                      className="p-2.5 border rounded text-xs bg-white dark:bg-slate-900 w-full text-slate-800 dark:text-white"
                      value={editingBook.descriptionGu}
                      onChange={(e) => setEditingBook({ ...editingBook, descriptionGu: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex gap-2 justify-end text-xs">
                  <button
                    onClick={() => setEditingBook(null)}
                    className="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-800 rounded font-bold cursor-pointer"
                  >
                    Discard
                  </button>
                  <button
                    onClick={async () => {
                      const exist = localDb.books.some(b => b.id === editingBook.id);
                      let upBooks = [];
                      if (exist) {
                        upBooks = localDb.books.map(b => b.id === editingBook.id ? editingBook : b);
                      } else {
                        upBooks = [...localDb.books, editingBook];
                      }
                      const u = { ...localDb, books: upBooks };
                      await handleSaveState(u, `Saved book item specifications: ${editingBook.titleEn}`);
                      setEditingBook(null);
                    }}
                    className="px-4 py-2 bg-indigo-600 text-white rounded font-bold cursor-pointer"
                  >
                    Save Specifications
                  </button>
                </div>
              </div>
            )}

            {/* List Table of books */}
            <div className="max-h-60 overflow-y-auto border border-slate-100 rounded-lg">
              <table className="w-full text-left">
                <thead className="bg-slate-50 dark:bg-slate-900 font-bold text-[10px] uppercase">
                  <tr>
                    <th className="p-3">Title</th>
                    <th className="p-3">Price</th>
                    <th className="p-3">Asset Path</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {localDb.books.map(b => (
                    <tr key={b.id} className="border-t border-slate-100 dark:border-slate-800">
                      <td className="p-3 font-semibold">{b.titleEn}</td>
                      <td className="p-3">
                        {b.price === 0 ? (
                          <span className="text-emerald-600 font-bold">FREE</span>
                        ) : (
                          <span className="text-amber-600 font-semibold">₹ {b.price}</span>
                        )}
                      </td>
                      <td className="p-3 font-mono text-[10px] text-slate-400 max-w-xs truncate">{b.fileUrl || "Missing file"}</td>
                      <td className="p-3 text-right flex gap-1 justify-end">
                        <button
                          onClick={() => setEditingBook(b)}
                          className="p-1 hover:bg-slate-50 rounded text-indigo-600 cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            const filtered = localDb.books.filter(item => item.id !== b.id);
                            handleSaveState({ ...localDb, books: filtered }, `Deleted library book catalog ${b.titleEn}`);
                          }}
                          className="p-1 hover:bg-slate-50 rounded text-rose-500 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4.5: DOWNLOADS MATERIAL STORAGE ENGINE */}
        {activeTab === "downloads" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex flex-wrap justify-between items-center gap-3 border-b border-light pb-3">
              <div>
                <h2 className="text-lg font-bold font-serif-literata text-slate-850 dark:text-white">
                  {lang === "en" ? "Manage Material Downloads Vault" : "ડાઉનલોડ લાયબ્રેરી સંચાલન"}
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  {lang === "en" ? "Upload, edit, and organize study resources category-wise." : "તમામ સાધનો અને ફાઇલો વર્ગ અનુસાર નિયંત્રિત કરો."}
                </p>
              </div>
              <button
                onClick={() => {
                  const id = "dl_" + Date.now();
                  const newD: DownloadItem = {
                    id,
                    titleEn: "New Material Title",
                    titleGu: "નવા સાહિત્યનું નામ",
                    category: "pdf",
                    fileUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
                    fileSize: "1.0 MB",
                    dateAdded: new Date().toISOString().split("T")[0],
                    descriptionEn: "Enter resource desc",
                    descriptionGu: "ટૂંકી વિગતો ઉમેરો"
                  };
                  setEditingDownload(newD);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>{lang === "en" ? "Add Resource File" : "નવી પીડીએફ / ઓડિયો ઉમેરો"}</span>
              </button>
            </div>

            {/* Direct download editor frame */}
            {editingDownload && (
              <div className="p-5 rounded-2xl border border-indigo-150 bg-indigo-50/15 dark:bg-slate-900/40 dark:border-indigo-950/60 space-y-4 animate-fade-in relative">
                <button
                  onClick={() => setEditingDownload(null)}
                  className="absolute top-4 right-4 text-slate-400 hover:text-slate-650 cursor-pointer font-bold"
                >
                  ✕
                </button>
                <h3 className="font-bold text-sm font-serif-literata text-indigo-700 dark:text-indigo-400">
                  {lang === "en" ? "Resource Specifications Editor" : "સંસાધન વિગતવાર માહિતી સંપાદક"}
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Left block information */}
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="font-bold block text-[11px] text-slate-600 dark:text-slate-400">Title (EN):</label>
                        <input
                          type="text"
                          className="p-2 border border-slate-200 dark:border-slate-800 rounded text-xs bg-white dark:bg-slate-950 w-full"
                          value={editingDownload.titleEn}
                          onChange={(e) => setEditingDownload({ ...editingDownload, titleEn: e.target.value })}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="font-bold block text-[11px] text-slate-600 dark:text-slate-400">Title (GU):</label>
                        <input
                          type="text"
                          className="p-2 border border-slate-200 dark:border-slate-800 rounded text-xs bg-white dark:bg-slate-950 w-full font-gujarati"
                          value={editingDownload.titleGu}
                          onChange={(e) => setEditingDownload({ ...editingDownload, titleGu: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="font-bold block text-[11px] text-slate-600 dark:text-slate-400">Category Tag:</label>
                        <select
                          className="p-2 border border-slate-200 dark:border-slate-800 rounded text-xs bg-white dark:bg-slate-950 w-full cursor-pointer font-semibold"
                          value={editingDownload.category}
                          onChange={(e) => setEditingDownload({ ...editingDownload, category: e.target.value as any })}
                        >
                          <option value="pdf">PDF Document / પીડીએફ</option>
                          <option value="audio">Audio Dictation / ઓડિયો</option>
                          <option value="video">Steno Video Lecture / વિડિયો</option>
                          <option value="photo">Photo & Gallery / છબીઓ</option>
                          <option value="other">Other Asset / અન્ય</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="font-bold block text-[11px] text-slate-600 dark:text-slate-400">File Size (e.g. 1.2 MB):</label>
                        <input
                          type="text"
                          className="p-2 border border-slate-200 dark:border-slate-800 rounded text-xs bg-white dark:bg-slate-950 w-full"
                          value={editingDownload.fileSize}
                          onChange={(e) => setEditingDownload({ ...editingDownload, fileSize: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="font-bold block text-[11px] text-slate-600 dark:text-slate-400">Release Date:</label>
                        <input
                          type="date"
                          className="p-2 border border-slate-200 dark:border-slate-800 rounded text-xs bg-white dark:bg-slate-950 w-full"
                          value={editingDownload.dateAdded}
                          onChange={(e) => setEditingDownload({ ...editingDownload, dateAdded: e.target.value })}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Right block descriptions & Direct upload system */}
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <label className="font-bold block text-[11px] text-slate-600 dark:text-slate-400 font-sans">Description (EN):</label>
                      <textarea
                        rows={2}
                        className="p-2 border border-slate-200 dark:border-slate-800 rounded text-xs bg-white dark:bg-slate-950 w-full"
                        value={editingDownload.descriptionEn}
                        onChange={(e) => setEditingDownload({ ...editingDownload, descriptionEn: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="font-bold block text-[11px] text-slate-600 dark:text-slate-400">Description (GU):</label>
                      <textarea
                        rows={2}
                        className="p-2 border border-slate-200 dark:border-slate-800 rounded text-xs bg-white dark:bg-slate-950 w-full font-gujarati"
                        value={editingDownload.descriptionGu}
                        onChange={(e) => setEditingDownload({ ...editingDownload, descriptionGu: e.target.value })}
                      />
                    </div>

                    {/* Uplink helper block */}
                    <div className="p-3.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850/80 space-y-2">
                      <label className="font-bold block text-[11px] text-slate-700 dark:text-slate-300">File Attachment (URL or upload):</label>
                      <input
                        type="text"
                        placeholder="https://example.com/file.pdf"
                        className="p-2 border border-slate-200 dark:border-slate-800 rounded text-xs bg-white dark:bg-slate-950 w-full font-mono text-[11px]"
                        value={editingDownload.fileUrl}
                        onChange={(e) => setEditingDownload({ ...editingDownload, fileUrl: e.target.value })}
                      />
                      <div className="flex items-center gap-2 pt-1">
                        <span className="text-[10px] text-slate-400 font-semibold uppercase">{lang === "en" ? "Or Instant Upload:" : "અથવા નવી ફાઇલ મોકલો:"}</span>
                        {uploadingTarget === `downloadFile_${editingDownload.id}` ? (
                          <span className="text-[10px] text-indigo-500 font-bold animate-pulse flex items-center gap-1">
                            <Upload className="w-3 animate-spin" /> Uploading, please wait...
                          </span>
                        ) : (
                          <input
                            type="file"
                            accept=".pdf,.mp3,.mp4,.wav,.png,.jpg,.jpeg,.zip"
                            className="text-[10px] text-slate-600 dark:text-slate-350 cursor-pointer"
                            onChange={(e) => handleFileUpload(e, `downloadFile_${editingDownload.id}`)}
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t border-indigo-100/50 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setEditingDownload(null)}
                    className="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-900 text-slate-650 dark:text-slate-300 dark:hover:bg-slate-800 text-xs rounded-xl cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      let list = localDb.downloads ? [...localDb.downloads] : [];
                      const exists = list.some(i => i.id === editingDownload.id);
                      if (exists) {
                        list = list.map(i => i.id === editingDownload.id ? editingDownload : i);
                      } else {
                        list.push(editingDownload);
                      }
                      handleSaveState({ ...localDb, downloads: list }, `Added/Updated resource download index ${editingDownload.titleEn}`);
                      setEditingDownload(null);
                    }}
                    className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                  >
                    Save Specifications
                  </button>
                </div>
              </div>
            )}

            {/* Existing downloads indexes table list */}
            <div className="border border-slate-200 dark:border-slate-800/80 rounded-2xl overflow-hidden bg-white dark:bg-slate-950 shadow-sm">
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-50 dark:bg-slate-900 border-b border-slate-200/50 dark:border-slate-800">
                  <tr>
                    <th className="p-3 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Type</th>
                    <th className="p-3 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Title / Description</th>
                    <th className="p-3 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Details</th>
                    <th className="p-3 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                  {(!localDb.downloads || localDb.downloads.length === 0) ? (
                    <tr>
                      <td colSpan={4} className="p-8 text-center text-xs text-slate-400 italic">
                        No download files uploaded to database yet. Click "Add Resource File" to seed information.
                      </td>
                    </tr>
                  ) : (
                    localDb.downloads.map((d) => (
                      <tr key={d.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-900/30 transition">
                        <td className="p-3 whitespace-nowrap">
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-650 dark:bg-slate-900 dark:text-slate-300 font-mono text-[9px] uppercase rounded font-bold border dark:border-slate-800">
                            {d.category}
                          </span>
                        </td>
                        <td className="p-3">
                          <p className="font-bold text-slate-800 dark:text-white text-xs">{d.titleEn}</p>
                          <p className="font-semibold text-slate-400 dark:text-slate-500 text-[10px] leading-tight mt-0.5">{d.descriptionEn || "No English description provided."}</p>
                          <p className="font-bold text-indigo-600 dark:text-indigo-400 text-[11px] leading-tight font-gujarati mt-1">{d.titleGu}</p>
                        </td>
                        <td className="p-3 whitespace-nowrap space-y-1 font-mono text-[10px] text-slate-500 dark:text-slate-400">
                          <p>Size: {d.fileSize || "N/A"}</p>
                          <p>Added: {d.dateAdded || "Recent"}</p>
                          <a href={d.fileUrl} target="_blank" rel="noopener noreferrer" className="text-indigo-500 hover:underline flex items-center gap-1">
                            <FileDown className="w-3 h-3" /> View Source File
                          </a>
                        </td>
                        <td className="p-3 whitespace-nowrap text-right text-xs">
                          <div className="flex justify-end gap-1.5">
                            <button
                              onClick={() => setEditingDownload(d)}
                              className="p-1 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 text-indigo-650 dark:text-indigo-400 rounded cursor-pointer"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(lang === "en" ? "Delete this resource eternally?" : "આ સાહિત્ય ફાઈલ હંમેશ માટે કાઢી નાખવી છે?")) {
                                  const filtered = localDb.downloads.filter(item => item.id !== d.id);
                                  handleSaveState({ ...localDb, downloads: filtered }, `Deleted resource download item ${d.titleEn}`);
                                }
                              }}
                              className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/20 text-rose-500 rounded cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 5: DIRECTORY EDITORS & EXCEL FILE SPREADSHEET IMPORTS */}
        {activeTab === "directory" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "Manage Directory Databases & Excel Imports" : "અધિકારી યાદી સંચાલક અને એક્સેલ આયાત"}
              </h2>
            </div>

            {/* Dir subtype control tabs */}
            <div className="flex flex-wrap gap-2 p-1 bg-slate-100/60 dark:bg-slate-900 rounded-lg w-fit">
              {(["secretaries", "stenographers", "collectors", "ddos"] as const).map((subtab) => (
                <button
                  key={subtab}
                  onClick={() => {
                    setEditingDirTab(subtab);
                    setEditingDir(null);
                    setImportFeedback(null);
                  }}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold capitalize cursor-pointer transition ${
                    editingDirTab === subtab
                      ? "bg-white dark:bg-slate-800 text-indigo-600 shadow-sm"
                      : "text-slate-500"
                  }`}
                >
                  {subtab}
                </button>
              ))}
            </div>

            {/* Excel Upload Area in the Dashboard Layout matches visual nicely */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50/60 to-sky-50/60 dark:bg-slate-900/65 dark:bg-none border border-indigo-100 dark:border-slate-800 space-y-4">
              <div className="flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-wide text-xs">
                <Upload className="w-4 h-4 animate-bounce" />
                <span>{lang === "en" ? `Update ${editingDirTab} directory by uploading spreadsheet` : `એક્સેલ શીટ અપલોડ દ્વારા ${editingDirTab} માહિતી બદલો`}</span>
              </div>

              <p className="text-xs text-slate-500 max-w-xl font-sans leading-relaxed">
                {lang === "en"
                  ? `Select a .xlsx, .xls or .csv file. The spreadsheet row headings should preferably include columns like: Name, Designation, Department, Landline, Mobile ${
                      editingDirTab === "secretaries"
                        ? ", Batch Year"
                        : (editingDirTab === "collectors" || editingDirTab === "ddos")
                        ? ", District"
                        : ""
                    }. Any layout will be parsed automatically.`
                  : `સચિવો, કલેકટરો અથવા સ્ટેનોગ્રાફરની વિગતો ધરાવતી એક્સેલ (.XLS / .XLSX) ફાઈલ અપલોડ કરો.`}
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-4">
                <input
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  disabled={importingType !== null}
                  onChange={(e) => handleSpreadsheetImport(e, editingDirTab)}
                  className="text-xs file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 cursor-pointer"
                />

                {importingType === editingDirTab && (
                  <span className="text-xs text-slate-400 font-mono animate-pulse">Reading and updating Excel data table...</span>
                )}
              </div>

              {importFeedback && (
                <div className={`p-2.5 rounded text-xs font-semibold ${
                  importFeedback.startsWith("Error")
                    ? "bg-rose-50 text-rose-600"
                    : "bg-emerald-50 text-emerald-600"
                }`}>
                  {importFeedback}
                </div>
              )}
            </div>

            {/* Inline Directory Row Adding */}
            <div className="flex justify-between items-center bg-white dark:bg-transparent pt-2">
              <h3 className="font-bold font-serif-literata capitalize text-slate-800 dark:text-white">
                Inline records in table: {editingDirTab} ({localDb.directories?.[editingDirTab]?.length || 0})
              </h3>
              <button
                onClick={() => {
                  const id = "dir_" + Date.now();
                  const newDir: DirectoryItem = {
                    id,
                    name: "Full Name",
                    designation: "Officer Designation",
                    department: "Cochon Dept Office",
                    landline: "079-",
                    mobile: "+91 "
                  };
                  setEditingDir(newDir);
                }}
                className="px-3.5 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                + Add row manual
              </button>
            </div>

            {editingDir && (
              <div className="p-4 rounded-xl border border-light bg-slate-50 dark:bg-slate-900/60 space-y-4 animate-fade-in">
                <h4 className="font-bold text-xs uppercase text-slate-400">Specifying Manual Directory Row</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                  <input
                    type="text"
                    className="p-2 border rounded bg-white dark:bg-slate-900"
                    value={editingDir.name}
                    onChange={(e) => setEditingDir({ ...editingDir, name: e.target.value })}
                    placeholder="Name"
                  />
                  <input
                    type="text"
                    className="p-2 border rounded bg-white dark:bg-slate-900"
                    value={editingDir.designation}
                    onChange={(e) => setEditingDir({ ...editingDir, designation: e.target.value })}
                    placeholder="Designation"
                  />
                  <input
                    type="text"
                    className="p-2 border rounded bg-white dark:bg-slate-900"
                    value={editingDir.department}
                    onChange={(e) => setEditingDir({ ...editingDir, department: e.target.value })}
                    placeholder="Department"
                  />
                  {editingDirTab === "secretaries" && (
                    <input
                      type="text"
                      className="p-2 border rounded bg-white dark:bg-slate-900"
                      value={editingDir.batchYear || ""}
                      onChange={(e) => setEditingDir({ ...editingDir, batchYear: e.target.value })}
                      placeholder="Batch Year"
                    />
                  )}
                  {(editingDirTab === "collectors" || editingDirTab === "ddos") && (
                    <input
                      type="text"
                      className="p-2 border rounded bg-white dark:bg-slate-900"
                      value={editingDir.district || ""}
                      onChange={(e) => setEditingDir({ ...editingDir, district: e.target.value })}
                      placeholder="District"
                    />
                  )}
                  <input
                    type="text"
                    className="p-2 border rounded bg-white dark:bg-slate-900"
                    value={editingDir.landline}
                    onChange={(e) => setEditingDir({ ...editingDir, landline: e.target.value })}
                    placeholder="Landline number"
                  />
                  <input
                    type="text"
                    className="p-2 border rounded bg-white dark:bg-slate-900"
                    value={editingDir.mobile}
                    onChange={(e) => setEditingDir({ ...editingDir, mobile: e.target.value })}
                    placeholder="Mobile number"
                  />
                </div>

                <div className="flex gap-2 justify-end text-xs">
                  <button
                    onClick={() => setEditingDir(null)}
                    className="px-3.5 py-1.5 bg-slate-100 rounded font-bold cursor-pointer"
                  >
                    Discard
                  </button>
                  <button
                    onClick={async () => {
                      const list = localDb.directories[editingDirTab] || [];
                      const exists = list.some(item => item.id === editingDir.id);
                      let updatedList = [];
                      if (exists) {
                        updatedList = list.map(item => item.id === editingDir.id ? editingDir : item);
                      } else {
                        updatedList = [...list, editingDir];
                      }
                      const updated = {
                        ...localDb,
                        directories: {
                          ...localDb.directories,
                          [editingDirTab]: updatedList
                        }
                      };
                      await handleSaveState(updated, `Saved manual directory row to list ${editingDirTab}`);
                      setEditingDir(null);
                    }}
                    className="px-4 py-2 bg-indigo-600 text-white rounded font-bold cursor-pointer"
                  >
                    Save Row
                  </button>
                </div>
              </div>
            )}

            {/* Direct rows view */}
            <div className="max-h-60 overflow-y-auto border border-slate-100 rounded-lg">
              <table className="w-full text-left">
                <thead className="bg-slate-50 dark:bg-slate-900 font-bold text-[10px] uppercase">
                  <tr>
                    <th className="p-3">Name</th>
                    <th className="p-3">Designation</th>
                    <th className="p-3">Department</th>
                    <th className="p-3 font-mono">Mobile</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(localDb.directories?.[editingDirTab] || []).map(row => (
                    <tr key={row.id} className="border-t border-slate-100 dark:border-slate-800">
                      <td className="p-3 font-semibold">{row.name}</td>
                      <td className="p-3"><span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded">{row.designation}</span></td>
                      <td className="p-3 truncate max-w-xs">{row.department}</td>
                      <td className="p-3 font-mono">{row.mobile}</td>
                      <td className="p-3 text-right flex gap-1 justify-end">
                        <button
                          onClick={() => setEditingDir(row)}
                          className="p-1 hover:bg-slate-50 rounded text-indigo-600 cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            const list = localDb.directories[editingDirTab] || [];
                            const filtered = list.filter(item => item.id !== row.id);
                            const updated = {
                              ...localDb,
                              directories: {
                                ...localDb.directories,
                                [editingDirTab]: filtered
                              }
                            };
                            handleSaveState(updated, `Deleted directory row manual`);
                          }}
                          className="p-1 hover:bg-slate-50 rounded text-rose-500 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 5.5: UTILITIES PAGES EMBED CODE EDITOR */}
        {activeTab === "utilities" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex justify-between items-center border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "Manage Custom Utility Pages & HTML Embed Codes" : "ઉપયોગિતાઓ અને HTML એમ્બેડ કોડ સુધારક"}
              </h2>
              <button
                onClick={() => {
                  const id = "util_" + Date.now();
                  const fallbackPages = localDb.utilities || [];
                  const updatedPages = [...fallbackPages, { id, titleEn: "New Utility Page", titleGu: "નવી ઉપયોગિતા પેજ", embedCode: "<div style='padding:20px; background:rgba(255,255,255,0.05); border-radius:12px;'><h3>New Content</h3><p>Inject custom static/widget resources</p></div>" }];
                  setLocalDb({ ...localDb, utilities: updatedPages });
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{lang === "en" ? "Add Page" : "ઉપયોગિતા ઉમેરો"}</span>
              </button>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400">
              {lang === "en"
                ? "The shorthand portal renders multiple custom dynamic tabs. Admins can customize titles (in Gujarati and English) and inject secure inline calculators, Google Docs directories, state guidelines, or standard iframe embeds here."
                : "તમે આ ઉપયોગિતા વિભાગમાં અલગ અલગ પેજ બનાવી શકો છો, જેમાં અંગ્રેજી/ગુજરાતી નામ અથવા ગૂગલ શીટ/કેલ્ક્યુલેટર માટેનો કસ્ટમ HTML એમ્બેડ કોડ લખી શકો છો."}
            </p>

            <div className="space-y-6">
              {(localDb.utilities || []).map((page, index) => (
                <div key={page.id} className="bg-slate-50 dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800 p-5 rounded-2xl space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 px-2.5 py-1 rounded-md text-xs">
                      {lang === "en" ? `Page Widget #${index + 1}` : `ઉપયોગિતા પેજ #${index + 1}`} (ID: {page.id})
                    </span>
                    <button
                      onClick={() => {
                        const fallbackPages = localDb.utilities || [];
                        const updatedPages = fallbackPages.filter(p => p.id !== page.id);
                        setLocalDb({ ...localDb, utilities: updatedPages });
                      }}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-slate-800 rounded-lg cursor-pointer flex items-center gap-1 text-xs"
                      title={lang === "en" ? "Delete Page" : "પેજ કાઢી નાખો"}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-600 dark:text-slate-350">
                        {lang === "en" ? "Page Title (English)" : "પેજ શીર્ષક (English)"}
                      </label>
                      <input
                        type="text"
                        className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-white outline-none"
                        value={page.titleEn}
                        onChange={(e) => {
                          const fallbackPages = localDb.utilities || [];
                          const updatedPages = fallbackPages.map(p => p.id === page.id ? { ...p, titleEn: e.target.value } : p);
                          setLocalDb({ ...localDb, utilities: updatedPages });
                        }}
                        placeholder="e.g. Shorthand Speed Calculator"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-600 dark:text-slate-350">
                        {lang === "en" ? "Page Title (Gujarati)" : "પેજ શીર્ષક (ગુજરાતી)"}
                      </label>
                      <input
                        type="text"
                        className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-white outline-none"
                        value={page.titleGu}
                        onChange={(e) => {
                          const fallbackPages = localDb.utilities || [];
                          const updatedPages = fallbackPages.map(p => p.id === page.id ? { ...p, titleGu: e.target.value } : p);
                          setLocalDb({ ...localDb, utilities: updatedPages });
                        }}
                        placeholder="માર્ગદર્શિકા"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-600 dark:text-slate-350 flex items-center gap-1">
                      <span>{lang === "en" ? "Page Custom HTML Embed Code / Text Markup" : "કસ્ટમ HTML એમ્બેડ અથવા નિયમો (Text/HTML markup)"}</span>
                      <span className="text-[10px] text-slate-400 font-normal">({lang === "en" ? "Supports tags like <div>, <p>, style, or iframe widgets" : "HTML, CSS અથવા કોડ ટૅગ્સ સપોર્ટ કરે છે"})</span>
                    </label>
                    <textarea
                      rows={6}
                      className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-white font-mono text-xs outline-none"
                      value={page.embedCode}
                      onChange={(e) => {
                        const fallbackPages = localDb.utilities || [];
                        const updatedPages = fallbackPages.map(p => p.id === page.id ? { ...p, embedCode: e.target.value } : p);
                        setLocalDb({ ...localDb, utilities: updatedPages });
                      }}
                      placeholder="e.g. <div style='padding:10px;'><h3>Guidelines</h3>...</div>"
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-3">
              <button
                onClick={() => handleSaveState(localDb, "Saved Utility Pages changes")}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold cursor-pointer"
              >
                {lang === "en" ? "Save Utility Pages" : "પેજીસ સેવ કરો"}
              </button>
            </div>
          </div>
        )}

        {/* TAB 6: ABOUT US EDITORS */}
        {activeTab === "about" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex justify-between items-center border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "Manage About Us details & Team Photos" : "અમારા વિશે અને ફોટો સુધારક"}
              </h2>
              <button
                onClick={() => handleSaveState(localDb, "Saved About specifications modifications")}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{lang === "en" ? "Save Changes" : "માહિતી સાચવો"}</span>
              </button>
            </div>

            <div className="space-y-4">
              {/* Mission EN/GU */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <span className="font-bold uppercase text-[10px] text-slate-400">Our Mission (English):</span>
                  <textarea
                    rows={4}
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={localDb.aboutUs.missionEn}
                    onChange={(e) => {
                      setLocalDb({
                        ...localDb,
                        aboutUs: { ...localDb.aboutUs, missionEn: e.target.value }
                      });
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <span className="font-bold uppercase text-[10px] text-slate-400">Our Mission (Gujarati):</span>
                  <textarea
                    rows={4}
                    className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded outline-none"
                    value={localDb.aboutUs.missionGu}
                    onChange={(e) => {
                      setLocalDb({
                        ...localDb,
                        aboutUs: { ...localDb.aboutUs, missionGu: e.target.value }
                      });
                    }}
                  />
                </div>
              </div>

              {/* Leadership team members photo upload and management list */}
              <div className="space-y-4 border-t border-slate-100 dark:border-slate-800 pt-4">
                <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-200/50 dark:border-slate-800">
                  <span className="font-bold uppercase text-xs text-indigo-600 block">Leadership Team Members (Roster)</span>
                  <button
                    onClick={() => {
                      const id = "team_" + Date.now();
                      const newMember = {
                        id,
                        nameEn: "New Team Member",
                        nameGu: "નવા સભ્ય",
                        roleEn: "Co-Founder",
                        roleGu: "સહ-સ્થાપક",
                        orgEn: "LaghuLipi.com",
                        orgGu: "લઘુલિપિ.com",
                        photoUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150"
                      };
                      setLocalDb({
                        ...localDb,
                        aboutUs: {
                          ...localDb.aboutUs,
                          team: [...(localDb.aboutUs.team || []), newMember]
                        }
                      });
                    }}
                    className="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[10px] font-bold cursor-pointer"
                  >
                    + Add Member
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {(localDb.aboutUs.team || []).map((member) => (
                    <div key={member.id} className="p-4 rounded-xl border border-slate-150 dark:border-slate-800 space-y-3 bg-white/40 dark:bg-slate-950/20 relative">
                      <button
                        onClick={() => {
                          const updatedTeam = localDb.aboutUs.team.filter(m => m.id !== member.id);
                          setLocalDb({
                            ...localDb,
                            aboutUs: { ...localDb.aboutUs, team: updatedTeam }
                          });
                        }}
                        className="absolute top-2 right-2 p-1 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded text-xs border border-rose-100 dark:border-rose-950/40 cursor-pointer"
                        title="Delete Member"
                      >
                        ✕
                      </button>
                      <h4 className="font-bold font-serif-literata text-slate-800 dark:text-white uppercase pr-6">{member.nameEn || "Unnamed"}</h4>

                      <div className="grid grid-cols-2 gap-2 text-[10px]">
                        <div>
                          <label className="text-slate-400 font-bold block mb-0.5">NAME (EN):</label>
                          <input
                            type="text"
                            className="w-full p-1.5 border rounded bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-150 border-slate-200 dark:border-slate-800 outline-none"
                            value={member.nameEn || ""}
                            onChange={(e) => {
                              const updatedTeam = localDb.aboutUs.team.map(m => m.id === member.id ? { ...m, nameEn: e.target.value } : m);
                              setLocalDb({ ...localDb, aboutUs: { ...localDb.aboutUs, team: updatedTeam } });
                            }}
                            placeholder="Name (EN)"
                          />
                        </div>
                        <div>
                          <label className="text-slate-400 font-bold block mb-0.5">NAME (GU):</label>
                          <input
                            type="text"
                            className="w-full p-1.5 border rounded bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-150 border-slate-200 dark:border-slate-800 outline-none"
                            value={member.nameGu || ""}
                            onChange={(e) => {
                              const updatedTeam = localDb.aboutUs.team.map(m => m.id === member.id ? { ...m, nameGu: e.target.value } : m);
                              setLocalDb({ ...localDb, aboutUs: { ...localDb.aboutUs, team: updatedTeam } });
                            }}
                            placeholder="Name (GU)"
                          />
                        </div>

                        <div>
                          <label className="text-slate-400 font-bold block mb-0.5">ROLE (EN):</label>
                          <input
                            type="text"
                            className="w-full p-1.5 border rounded bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-150 border-slate-200 dark:border-slate-800 outline-none"
                            value={member.roleEn || ""}
                            onChange={(e) => {
                              const updatedTeam = localDb.aboutUs.team.map(m => m.id === member.id ? { ...m, roleEn: e.target.value } : m);
                              setLocalDb({ ...localDb, aboutUs: { ...localDb.aboutUs, team: updatedTeam } });
                            }}
                            placeholder="Role (EN)"
                          />
                        </div>
                        <div>
                          <label className="text-slate-400 font-bold block mb-0.5">ROLE (GU):</label>
                          <input
                            type="text"
                            className="w-full p-1.5 border rounded bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-150 border-slate-200 dark:border-slate-800 outline-none"
                            value={member.roleGu || ""}
                            onChange={(e) => {
                              const updatedTeam = localDb.aboutUs.team.map(m => m.id === member.id ? { ...m, roleGu: e.target.value } : m);
                              setLocalDb({ ...localDb, aboutUs: { ...localDb.aboutUs, team: updatedTeam } });
                            }}
                            placeholder="Role (GU)"
                          />
                        </div>

                        <div>
                          <label className="text-slate-400 font-bold block mb-0.5">ORGANIZATION (EN):</label>
                          <input
                            type="text"
                            className="w-full p-1.5 border rounded bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-150 border-slate-200 dark:border-slate-800 outline-none"
                            value={member.orgEn || ""}
                            onChange={(e) => {
                              const updatedTeam = localDb.aboutUs.team.map(m => m.id === member.id ? { ...m, orgEn: e.target.value } : m);
                              setLocalDb({ ...localDb, aboutUs: { ...localDb.aboutUs, team: updatedTeam } });
                            }}
                            placeholder="Organization (EN)"
                          />
                        </div>
                        <div>
                          <label className="text-slate-400 font-bold block mb-0.5">ORGANIZATION (GU):</label>
                          <input
                            type="text"
                            className="w-full p-1.5 border rounded bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-150 border-slate-200 dark:border-slate-800 outline-none"
                            value={member.orgGu || ""}
                            onChange={(e) => {
                              const updatedTeam = localDb.aboutUs.team.map(m => m.id === member.id ? { ...m, orgGu: e.target.value } : m);
                              setLocalDb({ ...localDb, aboutUs: { ...localDb.aboutUs, team: updatedTeam } });
                            }}
                            placeholder="Organization (GU)"
                          />
                        </div>

                        <div className="col-span-2">
                          <label className="text-slate-400 font-bold block mb-0.5">PHOTO IMAGE URL:</label>
                          <input
                            type="text"
                            className="w-full p-1.5 border rounded bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-150 border-slate-200 dark:border-slate-800 outline-none"
                            value={member.photoUrl || ""}
                            onChange={(e) => {
                              const updatedTeam = localDb.aboutUs.team.map(m => m.id === member.id ? { ...m, photoUrl: e.target.value } : m);
                              setLocalDb({ ...localDb, aboutUs: { ...localDb.aboutUs, team: updatedTeam } });
                            }}
                            placeholder="/uploads/team_member.jpg"
                          />
                        </div>
                      </div>

                      <div className="flex gap-4 items-center border-t border-slate-100 dark:border-slate-800 pt-2">
                        <div className="w-10 h-10 rounded-full border bg-slate-100 overflow-hidden shrink-0">
                          <img src={member.photoUrl} className="w-full h-full object-cover" />
                        </div>
                        <input
                          type="file"
                          onChange={(e) => handleFileUpload(e, `team_${member.id}`)}
                          className="text-[10px] file:mr-2 file:py-1 file:px-2 file:border-0 file:rounded-xl file:text-[10px] file:font-semibold file:bg-indigo-50"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: FOOTER & SOCIAL LINKS EDITORS */}
        {activeTab === "footer" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex justify-between items-center border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "Manage Footer Configurations & Social Icons" : "ફૂટર માહિતી અને સોશિયલ કનેક્ટર્સ સંચાલક"}
              </h2>
              <button
                onClick={() => handleSaveState(localDb, "Saved Footer Specifications modifications")}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{lang === "en" ? "Save Changes" : "માહિતી સાચવો"}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label>Footer Address (English):</label>
                <input
                  type="text"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 dark:bg-slate-900 rounded outline-none text-slate-800 dark:text-white"
                  value={localDb.footer.addressEn}
                  onChange={(e) => {
                    const u = { ...localDb };
                    u.footer.addressEn = e.target.value;
                    setLocalDb(u);
                  }}
                />
              </div>
              <div className="space-y-2">
                <label>Footer Address (Gujarati):</label>
                <input
                  type="text"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 dark:bg-slate-900 rounded outline-none text-slate-800 dark:text-white"
                  value={localDb.footer.addressGu}
                  onChange={(e) => {
                    const u = { ...localDb };
                    u.footer.addressGu = e.target.value;
                    setLocalDb(u);
                  }}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label>Mobile Number:</label>
                <input
                  type="text"
                  className="w-full p-2 bg-slate-50 border border-slate-200 dark:bg-slate-900 rounded outline-none"
                  value={localDb.footer.mobile}
                  onChange={(e) => {
                    const u = { ...localDb };
                    u.footer.mobile = e.target.value;
                    setLocalDb(u);
                  }}
                />
              </div>
              <div className="space-y-1.5">
                <label>Email Address:</label>
                <input
                  type="email"
                  className="w-full p-2 bg-slate-50 border border-slate-200 dark:bg-slate-900 rounded outline-none"
                  value={localDb.footer.email}
                  onChange={(e) => {
                    const u = { ...localDb };
                    u.footer.email = e.target.value;
                    setLocalDb(u);
                  }}
                />
              </div>
              <div className="space-y-1.5">
                <label>Mock Site Visitors Audit:</label>
                <input
                  type="number"
                  className="w-full p-2 bg-slate-50 border border-slate-200 dark:bg-slate-900 rounded outline-none"
                  value={localDb.siteVisitors}
                  onChange={(e) => {
                    const u = { ...localDb };
                    u.siteVisitors = parseInt(e.target.value) || 12897;
                    setLocalDb(u);
                  }}
                />
              </div>
            </div>

            {/* Social media connections: add, edit, delete by admin */}
            <div className="space-y-4 border-t border-slate-100 dark:border-slate-800 pt-4">
              <div className="flex justify-between items-center">
                <span className="font-bold text-xs text-indigo-600 uppercase">Social Media Handles</span>
                <button
                  onClick={() => {
                    const id = "sc_" + Date.now();
                    const lnks = [...localDb.socialLinks, { id, platform: "facebook" as const, url: "https://facebook.com" }];
                    setLocalDb({ ...localDb, socialLinks: lnks });
                  }}
                  className="px-2.5 py-1 bg-indigo-50 hover:bg-slate-100 rounded text-xs font-bold text-indigo-600 cursor-pointer"
                >
                  + Add Handle
                </button>
              </div>

              <div className="space-y-2">
                {localDb.socialLinks.map((item) => (
                  <div key={item.id} className="flex gap-4 items-center bg-slate-50 dark:bg-slate-900 p-2 rounded-lg">
                    <select
                      className="p-1.5 border rounded text-xs bg-white text-slate-700 dark:bg-slate-800 dark:text-white"
                      value={item.platform}
                      onChange={(e) => {
                        const lnks = localDb.socialLinks.map(l => l.id === item.id ? { ...l, platform: e.target.value as any } : l);
                        setLocalDb({ ...localDb, socialLinks: lnks });
                      }}
                    >
                      <option value="facebook">Facebook</option>
                      <option value="twitter">Twitter / X</option>
                      <option value="youtube">YouTube</option>
                      <option value="instagram">Instagram</option>
                      <option value="linkedin">LinkedIn</option>
                    </select>

                    <input
                      type="text"
                      className="p-1.5 border rounded text-xs flex-1 bg-white dark:bg-slate-800 text-slate-700 dark:text-white"
                      value={item.url}
                      onChange={(e) => {
                        const lnks = localDb.socialLinks.map(l => l.id === item.id ? { ...l, url: e.target.value } : l);
                        setLocalDb({ ...localDb, socialLinks: lnks });
                      }}
                      placeholder="https://..."
                    />

                    <button
                      onClick={() => {
                        const filtered = localDb.socialLinks.filter(l => l.id !== item.id);
                        setLocalDb({ ...localDb, socialLinks: filtered });
                      }}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 rounded cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: QUICK LINKS EDITORS */}
        {activeTab === "quicklinks" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex justify-between items-center border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "Manage Portal Navigation & Quick Links" : "ઝડપી લિંક્સ (Quick Links) સુધારક"}
              </h2>
              <button
                onClick={() => {
                  const id = "ql_" + Date.now();
                  const links = [...localDb.quickLinks, { id, nameEn: "New Link", nameGu: "નવી લિંક", url: "https://" }];
                  setLocalDb({ ...localDb, quickLinks: links });
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{lang === "en" ? "Add Link" : "લિંક ઉમેરો"}</span>
              </button>
            </div>

            <div className="space-y-3">
              {localDb.quickLinks.map((link) => (
                <div key={link.id} className="flex gap-4 items-center bg-slate-50 dark:bg-slate-900 p-3 rounded-lg text-xs">
                  <input
                    type="text"
                    className="p-1.5 border rounded flex-1 bg-white dark:bg-slate-800 text-slate-700 dark:text-white"
                    placeholder="Label (EN)"
                    value={link.nameEn}
                    onChange={(e) => {
                      const list = localDb.quickLinks.map(l => l.id === link.id ? { ...l, nameEn: e.target.value } : l);
                      setLocalDb({ ...localDb, quickLinks: list });
                    }}
                  />
                  <input
                    type="text"
                    className="p-1.5 border rounded flex-1 bg-white dark:bg-slate-800 text-slate-700 dark:text-white"
                    placeholder="Label (GU)"
                    value={link.nameGu}
                    onChange={(e) => {
                      const list = localDb.quickLinks.map(l => l.id === link.id ? { ...l, nameGu: e.target.value } : l);
                      setLocalDb({ ...localDb, quickLinks: list });
                    }}
                  />
                  <input
                    type="text"
                    className="p-1.5 border rounded flex-[2] bg-white dark:bg-slate-800 text-slate-700 dark:text-white"
                    placeholder="https://"
                    value={link.url}
                    onChange={(e) => {
                      const list = localDb.quickLinks.map(l => l.id === link.id ? { ...l, url: e.target.value } : l);
                      setLocalDb({ ...localDb, quickLinks: list });
                    }}
                  />

                  <button
                    onClick={() => {
                      const list = localDb.quickLinks.filter(l => l.id !== link.id);
                      setLocalDb({ ...localDb, quickLinks: list });
                    }}
                    className="p-1.5 text-rose-500 hover:bg-rose-50 rounded cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            <button
              onClick={() => handleSaveState(localDb, "Saved Quick Links modification")}
              className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold float-right cursor-pointer"
            >
              Save Links
            </button>
          </div>
        )}

        {/* TAB 9: SECURITY AUDIT LOGS VIEW & CSV DOWNLOADS */}
        {activeTab === "auditlogs" && (
          <div className="space-y-6 text-xs md:text-sm font-mono">
            <div className="flex flex-wrap justify-between items-center border-b border-light pb-2 gap-4">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "Administrative Security & Compliance Audit Logs" : "વહીવટી લૉગ્સ અને ઓડિટ અહેવાલ"}
              </h2>

              <a
                href="/api/audit-logs/export"
                download="audit_logs.csv"
                className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <FileDown className="w-4 h-4" />
                <span>{lang === "en" ? "Export Logs (CSV)" : "ક્રોનિકલ ફાઇલ ડાઉનલોડ (CSV)"}</span>
              </a>
            </div>

            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              {lang === "en"
                ? "Every administrative action (updates, excel parses, uploads, database changes) is automatically verified on the server-side with precise operator timestamps, role tags, and compliance details."
                : "તમામ સંપાદન, અપલોડ અને એક્સેલ પ્રક્રિયાઓનું ઓડિટ લૉગ આપમેળે સર્વર પર નોંધવામાં આવે છે."}
            </p>

            <div className="max-h-96 overflow-y-auto border border-slate-100 rounded-xl">
              <table className="w-full text-left font-mono text-[11px] text-slate-600 dark:text-slate-300">
                <thead className="bg-slate-50 dark:bg-slate-900 font-bold text-slate-400 uppercase">
                  <tr>
                    <th className="p-3">Timestamp</th>
                    <th className="p-3">User</th>
                    <th className="p-3">Role</th>
                    <th className="p-3">Action Completed</th>
                    <th className="p-3">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
                  {(localDb.auditLogs || []).map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                      <td className="p-3 text-slate-400 shrink-0 whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</td>
                      <td className="p-3 font-semibold">{log.user}</td>
                      <td className="p-3 whitespace-nowrap">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] uppercase font-bold ${
                          log.role === "admin"
                            ? "bg-rose-100 text-rose-700"
                            : log.role === "system"
                            ? "bg-slate-100 text-slate-600"
                            : "bg-indigo-100 text-indigo-700"
                        }`}>
                          {log.role}
                        </span>
                      </td>
                      <td className="p-3 font-semibold text-slate-800 dark:text-white uppercase tracking-wider text-[10px] whitespace-nowrap">{log.action}</td>
                      <td className="p-3 font-sans leading-relaxed text-slate-500 dark:text-slate-400">{log.details}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 10: ADMIN ACCESS CONTROL REQUESTS (APPROVE / REJECT) */}
        {activeTab === "adminusers" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex justify-between items-center border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "Manage Portal Administrators" : "વહીવટીકર્તા એડમિન યુઝર્સ સંચાલન"}
              </h2>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              {lang === "en"
                ? "Approve or reject admin candidates requesting Access Control. Approved administrators will be able to log in to this CMS control panel and save content modifications. Demoted administrators will instantly lose all write permissions."
                : "એડમિન કંટ્રોલ પેનલમાં પ્રવેશ મેળવવા માટે વિનંતી કરનારા નવા સભ્યોની અહીંથી ચકાસણી કરો અને તેમને મંજૂર અથવા નામંજૂર કરો."}
            </p>

            <div className="overflow-x-auto border border-slate-100 dark:border-slate-850 rounded-xl bg-white dark:bg-slate-900">
              <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                <thead className="bg-slate-50 dark:bg-slate-900/60 font-bold text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Candidate Name</th>
                    <th className="p-3">Email Address</th>
                    <th className="p-3">Status/Role</th>
                    <th className="p-3">Registration Date</th>
                    <th className="p-3 text-right">Verification Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                  {((localDb.users || []).length === 0) ? (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-400 italic">
                        {lang === "en" ? "No users registered or requesting access yet." : "કોઈ રજીસ્ટર્ડ યુઝર અથવા વિનંતીઓ ઉપલબ્ધ નથી."}
                      </td>
                    </tr>
                  ) : (
                    (localDb.users || []).map((u: any) => (
                      <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                        <td className="p-3 font-semibold text-slate-800 dark:text-slate-200">{u.name}</td>
                        <td className="p-3 font-mono">{u.email}</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] uppercase font-bold shrink-0 ${
                            u.role === "admin"
                              ? "bg-emerald-100 text-emerald-800"
                              : u.role === "pending_admin"
                              ? "bg-amber-100 text-amber-850 animate-pulse"
                              : u.role === "rejected"
                              ? "bg-rose-100 text-rose-850"
                              : "bg-slate-100 text-slate-600"
                          }`}>
                            {u.role === "pending_admin" ? (lang === "en" ? "Pending" : "મંજૂરી બાકી") : u.role}
                          </span>
                        </td>
                        <td className="p-3 text-slate-400 text-[10px]">
                          {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "-"}
                        </td>
                        <td className="p-3 text-right">
                          <div className="flex justify-end gap-1.5">
                            {u.role === "pending_admin" && (
                              <>
                                <button
                                  onClick={async () => {
                                    const uCopy = { ...localDb };
                                    uCopy.users = uCopy.users.map((x: any) => x.id === u.id ? { ...x, role: "admin" } : x);
                                    setLocalDb(uCopy);
                                    await onSaveDB(uCopy, `Approved Admin application for ${u.name} (${u.email})`);
                                  }}
                                  className="p-1 px-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                                  title="Approve Administrator"
                                >
                                  <Check className="w-3 h-3 text-emerald-700" />
                                  <span>{lang === "en" ? "Approve" : "મંજૂર કરો"}</span>
                                </button>
                                <button
                                  onClick={async () => {
                                    const uCopy = { ...localDb };
                                    uCopy.users = uCopy.users.map((x: any) => x.id === u.id ? { ...x, role: "rejected" } : x);
                                    setLocalDb(uCopy);
                                    await onSaveDB(uCopy, `Rejected Admin application for ${u.name} (${u.email})`);
                                  }}
                                  className="p-1 px-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                                  title="Reject Access"
                                >
                                  <X className="w-3 h-3 text-rose-700" />
                                  <span>{lang === "en" ? "Reject" : "નામંજૂર કરો"}</span>
                                </button>
                              </>
                            )}

                            {u.role === "admin" && (
                              <button
                                onClick={async () => {
                                  const uCopy = { ...localDb };
                                  uCopy.users = uCopy.users.map((x: any) => x.id === u.id ? { ...x, role: "user" } : x);
                                  setLocalDb(uCopy);
                                  await onSaveDB(uCopy, `Revoked Admin role from ${u.name} (${u.email})`);
                                }}
                                className="p-1 px-2 bg-yellow-50 hover:bg-yellow-100 text-yellow-700 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <span>{lang === "en" ? "Demote" : "પદ રદ કરો"}</span>
                              </button>
                            )}

                            {(u.role === "user" || u.role === "rejected") && (
                              <button
                                onClick={async () => {
                                  const uCopy = { ...localDb };
                                  uCopy.users = uCopy.users.map((x: any) => x.id === u.id ? { ...x, role: "admin" } : x);
                                  setLocalDb(uCopy);
                                  await onSaveDB(uCopy, `Promoted user ${u.name} to Administrator`);
                                }}
                                className="p-1 px-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-lg text-[11px] font-bold cursor-pointer"
                              >
                                <span>{lang === "en" ? "Approve Admin" : "એડમિન બનાવો"}</span>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 11: USER FEEDBACK & SUGGESTIONS LOGS VIEW */}
        {activeTab === "feedbacks" && (
          <div className="space-y-6 text-xs md:text-sm">
            <div className="flex justify-between items-center border-b border-light pb-2">
              <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white">
                {lang === "en" ? "User Feedbacks & Suggestions" : "યુઝર્સ ફીડબેક અને ઉત્તમ સૂચનો"}
              </h2>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              {lang === "en"
                ? "Read messages, suggestions, and scores submitted by student stenographers and visitors from the public feedback forms."
                : "મુલાકાતીઓ અને લઘુલિપિ આકાંક્ષીઓ દ્વારા સબમિટ કરાયેલા અભિપ્રાયો અને રેટિંગ્સ અહીંથી જોઈ શકાશે."}
            </p>

            <div className="space-y-4">
              {(!localDb.feedbacks || localDb.feedbacks.length === 0) ? (
                <div className="p-8 text-center text-slate-400 border border-dashed rounded-xl bg-slate-50/50">
                  {lang === "en" ? "No suggestions submitted yet." : "હજુ સુધી કોઈ ફીડબેક સબમિટ થયા નથી."}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {localDb.feedbacks.map((f: any) => (
                    <div key={f.id} className="p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 space-y-2.5 shadow-sm text-xs relative overflow-hidden group">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-bold text-[13px] text-slate-850 dark:text-slate-105">{f.name}</p>
                          <p className="text-[10px] text-slate-400 font-mono mt-0.5">{f.email} • {f.mobile || "No Mobile"}</p>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {f.submittedAt ? new Date(f.submittedAt).toLocaleDateString() : "-"}
                        </span>
                      </div>

                      <div className="flex items-center gap-1 bg-amber-50 dark:bg-amber-950/20 px-2 py-0.5 rounded w-fit text-amber-600 font-bold text-[11px]">
                        <span className="tracking-tighter">★</span>
                        <span>{f.rating} / 5 Stars</span>
                      </div>

                      <div className="p-2.5 bg-slate-50 dark:bg-slate-950/60 rounded-lg text-slate-600 dark:text-slate-350 italic font-medium leading-relaxed">
                        "{f.message || f.suggestion || "-"}"
                      </div>

                      <button
                        onClick={async () => {
                          if (window.confirm("Are you sure you want to delete this feedback log?")) {
                            const uCopy = { ...localDb };
                            uCopy.feedbacks = uCopy.feedbacks.filter((x: any) => x.id !== f.id);
                            setLocalDb(uCopy);
                            await onSaveDB(uCopy, `Deleted feedback record from user ${f.name}`);
                          }
                        }}
                        className="absolute bottom-2.5 right-2.5 opacity-0 group-hover:opacity-100 p-1.5 hover:bg-rose-50 text-rose-500 rounded transition cursor-pointer"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
