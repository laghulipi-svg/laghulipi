import React, { useState } from "react";
import { Download, FileText, Image, Video, Music, Search, Calendar, HardDrive, Play, Pause, ExternalLink, Eye } from "lucide-react";
import { DatabaseState } from "../types";

export interface DownloadItem {
  id: string;
  titleEn: string;
  titleGu: string;
  category: "photo" | "audio" | "video" | "pdf" | "other";
  fileUrl: string;
  fileSize?: string;
  dateAdded?: string;
  descriptionEn?: string;
  descriptionGu?: string;
}

interface DownloadViewProps {
  lang: "en" | "gu";
  db: DatabaseState;
}

export default function DownloadView({ lang, db }: DownloadViewProps) {
  // Safe extraction of downloads array or fallback to sample items
  const downloadsList: DownloadItem[] = (db as any).downloads || [
    {
      id: "dl_1",
      titleEn: "Standard 80 WPM Shorthand Outline Chart",
      titleGu: "શોર્ટહેન્ડ પ્રારંભિક આઉટલાઇન ચાર્ટ (૮૦ WPM)",
      category: "pdf",
      fileUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
      fileSize: "1.2 MB",
      dateAdded: "2026-06-10",
      descriptionEn: "Complete primary outlines and vowels system chart for stenography exams preparation.",
      descriptionGu: "સ્ટેનોગ્રાફી પરીક્ષાની તૈયારી માટે સંપૂર્ણ પ્રાથમિક આઉટલાઇન્સ અને સ્વર પદ્ધતિ ચાર્ટ."
    },
    {
      id: "dl_2",
      titleEn: "Gujarat Secretariat Assembly Dictation Audio Room",
      titleGu: "ગુજરાત સચિવાલય વિધાનસભા ડિક્ટેશન ઓડિયો લેક્ચર",
      category: "audio",
      fileUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
      fileSize: "4.8 MB",
      dateAdded: "2026-06-08",
      descriptionEn: "Clean official voice recording at strictly calibrated speed for assembly exam outlines.",
      descriptionGu: "વિધાનસભા પરીક્ષા માટે નિર્ધારિત સ્પીડ પર રેકોર્ડ કરેલ ઓડિયો ફાઈલ."
    },
    {
      id: "dl_3",
      titleEn: "Administrative Stenographer Batch Photo (GIDC)",
      titleGu: "વહીવટી સ્ટેનોગ્રાફર બેચ સન્માનિત છબી (GIDC)",
      category: "photo",
      fileUrl: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=800",
      fileSize: "850 KB",
      dateAdded: "2026-06-05",
      descriptionEn: "Historical honorary ceremony photograph of class-II and class-III stenography officers.",
      descriptionGu: "વર્ગ-ર અને વર્ગ-૩ લઘુલેખક સન્માન સમારોહની યાદગાર ગેલરી છબી."
    },
    {
      id: "dl_4",
      titleEn: "Smart Shorthand Writing Techniques Masterclass Tutorial",
      titleGu: "ઝડપી શોર્ટહેન્ડ લેખન પદ્ધતિ માસ્ટરક્લાસ વીડિયો ટ્યુટોરીયલ",
      category: "video",
      fileUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
      fileSize: "12.4 MB",
      dateAdded: "2026-06-02",
      descriptionEn: "Insightful video overview covering optimal pencil holds, layout guidelines, and stroke speed.",
      descriptionGu: "પેન્સિલ પકડવાની સાચી રીત અને સેકન્ડ સ્પીડ વધારવાના નિયમો સમજાવતો વિશેષ વિડિઓ."
    }
  ];

  const [activeCategory, setActiveCategory] = useState<"all" | "photo" | "audio" | "video" | "pdf" | "other">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);
  const [previewVideoUrl, setPreviewVideoUrl] = useState<string | null>(null);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  // Filter functionality
  const filteredItems = downloadsList.filter((item) => {
    const categoryMatches = activeCategory === "all" || item.category === activeCategory;
    const searchString = searchQuery.toLowerCase();
    const matchesSearch =
      item.titleEn.toLowerCase().includes(searchString) ||
      item.titleGu.toLowerCase().includes(searchString) ||
      (item.descriptionEn && item.descriptionEn.toLowerCase().includes(searchString)) ||
      (item.descriptionGu && item.descriptionGu.toLowerCase().includes(searchString));
    return categoryMatches && matchesSearch;
  });

  const handleAudioPlay = (id: string, url: string) => {
    if (playingAudioId === id) {
      if (audioElement) {
        audioElement.pause();
      }
      setPlayingAudioId(null);
    } else {
      if (audioElement) {
        audioElement.pause();
      }
      const audio = new Audio(url);
      audio.play();
      audio.onended = () => setPlayingAudioId(null);
      setAudioElement(audio);
      setPlayingAudioId(id);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "photo": return <Image className="w-4 h-4 text-emerald-500" />;
      case "audio": return <Music className="w-4 h-4 text-indigo-500" />;
      case "video": return <Video className="w-4 h-4 text-rose-500" />;
      case "pdf": return <FileText className="w-4 h-4 text-amber-500" />;
      default: return <Download className="w-4 h-4 text-slate-500" />;
    }
  };

  const getCategoryThemeColor = (category: string) => {
    switch (category) {
      case "photo": return "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-100 dark:border-emerald-900";
      case "audio": return "bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300 border-indigo-100 dark:border-indigo-900";
      case "video": return "bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-100 dark:border-rose-900";
      case "pdf": return "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-100 dark:border-amber-900";
      default: return "bg-slate-50 text-slate-700 dark:bg-slate-900/40 dark:text-slate-300 border-slate-100 dark:border-slate-800";
    }
  };

  return (
    <div className="space-y-6 animate-fade-in font-gujarati">
      {/* View Header with NIC Style Badge */}
      <div className="border-b border-slate-100 dark:border-slate-800 pb-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold font-serif-literata text-slate-800 dark:text-white">
              {lang === "en" ? "Study Material & Downloads" : "શિક્ષણ સાહિત્ય અને ડાઉનલોડ"}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 uppercase tracking-wider font-semibold">
              {lang === "en"
                ? "Resource repository for high-speed steno practice"
                : " હાઇ-સ્પીડ સ્ટેનો પ્રેક્ટિસ માટે સંસાધન ભંડાર "}
            </p>
          </div>
          {/* NIC-iOS hybrid info badge */}
          <div className="bg-slate-100 dark:bg-slate-900 px-3.5 py-1.5 rounded-xl border border-slate-200/50 dark:border-slate-800 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-[10px] font-mono tracking-tight font-bold text-slate-600 dark:text-slate-300">
              {downloadsList.length} ITEMS AVAILABLE
            </span>
          </div>
        </div>
      </div>

      {/* Control Panel: Category selector and Search Filter */}
      <div className="bg-white/50 dark:bg-slate-900/40 p-4 rounded-2xl border border-slate-200/40 dark:border-slate-800/60 shadow-sm space-y-4">
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl outline-none text-xs text-slate-800 dark:text-white placeholder-slate-400 focus:border-indigo-500 font-sans"
            placeholder={lang === "en" ? "Search materials, files, audio name..." : "પીડીએફ, છબી, ઓડિયો અથવા સાહિત્યના નામ શોધો..."}
          />
        </div>

        {/* Categories Tab Selector with numbers badge */}
        <div className="flex flex-wrap gap-2 pt-1 border-t border-slate-100 dark:border-slate-800/60 pt-3">
          {(["all", "photo", "audio", "video", "pdf", "other"] as const).map((cat) => {
            const isActive = activeCategory === cat;
            const count = cat === "all" ? downloadsList.length : downloadsList.filter((i) => i.category === cat).length;
            const label = {
              all: lang === "en" ? "All Resources" : "તમામ સાહિત્ય",
              photo: lang === "en" ? "Photos & Gallery" : "ચિત્રો અને છબીઓ",
              audio: lang === "en" ? "Dictations & Audio" : "શ્રુતલેખન ઓડિયો",
              video: lang === "en" ? "Lectures & Video" : "વિડિઓ લેક્ચર્સ",
              pdf: lang === "en" ? "PDF Documents" : "પીડીએફ ફાઇલો",
              other: lang === "en" ? "Other Assets" : "અન્ય સંસાધનો",
            }[cat];

            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 md:px-4 md:py-2 rounded-xl text-xs font-bold flex items-center gap-2 border transition shrink-0 cursor-pointer ${
                  isActive
                    ? "bg-indigo-600 border-indigo-600 text-white shadow-sm shadow-indigo-100 dark:shadow-none"
                    : "bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-900"
                }`}
              >
                {cat !== "all" && getCategoryIcon(cat)}
                <span>{label}</span>
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-mono ${isActive ? "bg-white/20 text-white" : "bg-slate-100 text-slate-500 dark:bg-slate-900 dark:text-slate-400"}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Downloads Grid Card Output */}
      {filteredItems.length === 0 ? (
        <div className="bg-white/30 dark:bg-slate-900/10 rounded-2xl p-12 border border-dashed border-slate-200 dark:border-slate-800 text-center space-y-3">
          <HardDrive className="w-10 h-10 text-slate-350 dark:text-slate-600 mx-auto animate-bounce" />
          <p className="text-sm font-bold text-slate-600 dark:text-slate-400">
            {lang === "en" ? "No downloads found matching filters" : "પસંદ કરેલ કેટેગરીમાં કોઈ સંસાધનો ઉપલબ્ધ નથી."}
          </p>
          <p className="text-xs text-slate-400">
            {lang === "en" ? "Try adjusting the parameters or type another query" : "તમારી શોધ વધારે સરળ બનાવો અથવા એડમિન દ્વારા નવી અપડેટની રાહ જુઓ."}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white dark:bg-[#0e1424] p-5 rounded-2xl border border-slate-200/50 dark:border-slate-800/80 shadow-sm hover:shadow-md transition flex flex-col justify-between space-y-4 group relative"
            >
              <div className="space-y-2">
                {/* Category tag & Date badge */}
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-0.5 rounded-lg text-[9px] font-bold uppercase border ${getCategoryThemeColor(item.category)}`}>
                    {item.category}
                  </span>
                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                    <Calendar className="w-3 h-3" />
                    <span>{item.dateAdded || "Recent"}</span>
                  </div>
                </div>

                {/* Title */}
                <h3 className="font-bold text-sm text-slate-800 dark:text-white leading-normal">
                  {lang === "en" ? item.titleEn : item.titleGu}
                </h3>

                {/* Description */}
                {(item.descriptionEn || item.descriptionGu) && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-sans line-clamp-2">
                    {lang === "en" ? item.descriptionEn : item.descriptionGu}
                  </p>
                )}
              </div>

              {/* Action buttons & Details panel */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between gap-3">
                
                {/* File size info */}
                <div className="text-[10px] text-slate-400 dark:text-slate-500 flex items-center gap-1 font-mono">
                  <HardDrive className="w-3.5 h-3.5 opacity-60" />
                  <span>{item.fileSize || "1.0 MB"}</span>
                </div>

                {/* Inline media active functions */}
                <div className="flex items-center gap-2">
                  {/* Photo Lightbox trigger button */}
                  {item.category === "photo" && (
                    <button
                      onClick={() => setPreviewPhotoUrl(item.fileUrl)}
                      className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 dark:bg-emerald-950/30 dark:text-emerald-400 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition border border-emerald-100 dark:border-emerald-900"
                    >
                      <Eye className="w-3 h-3" />
                      <span>{lang === "en" ? "Zoom" : "મોટું ચિત્ર"}</span>
                    </button>
                  )}

                  {/* Video lightbox embed video player trigger */}
                  {item.category === "video" && (
                    <button
                      onClick={() => setPreviewVideoUrl(item.fileUrl)}
                      className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/30 dark:text-rose-400 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition border border-rose-100 dark:border-rose-900"
                    >
                      <Play className="w-3 h-3" />
                      <span>{lang === "en" ? "Play Video" : "વિડિઓ ચલાવો"}</span>
                    </button>
                  )}

                  {/* Audio Player playback inline controller */}
                  {item.category === "audio" && (
                    <button
                      onClick={() => handleAudioPlay(item.id, item.fileUrl)}
                      className={`px-2.5 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition border ${
                        playingAudioId === item.id
                          ? "bg-amber-500 text-white border-amber-500 animate-pulse"
                          : "bg-indigo-50 hover:bg-indigo-100 text-indigo-600 dark:bg-indigo-950/30 dark:text-indigo-400 border-indigo-100 dark:border-indigo-900"
                      }`}
                    >
                      {playingAudioId === item.id ? <Pause className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />}
                      <span>{playingAudioId === item.id ? (lang === "en" ? "Playing" : "ચાલે છે") : (lang === "en" ? "Listen" : "સાંભળો")}</span>
                    </button>
                  )}

                  {/* Standard file download anchor */}
                  <a
                    href={item.fileUrl}
                    download
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white dark:bg-indigo-600 dark:hover:bg-indigo-700 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition"
                  >
                    <Download className="w-3 h-3" />
                    <span>{lang === "en" ? "Download" : "ડાઉનલોડ"}</span>
                  </a>
                </div>

              </div>
            </div>
          ))}
        </div>
      )}

      {/* 1. Zoom Photograph Lightbox Modal Overlay */}
      {previewPhotoUrl && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#0e1424] max-w-2xl w-full rounded-2xl overflow-hidden border border-slate-800 shadow-2xl relative">
            <button
              onClick={() => setPreviewPhotoUrl(null)}
              className="absolute top-4 right-4 bg-black/50 hover:bg-black/80 text-white rounded-full p-2 cursor-pointer z-10"
            >
              ✕
            </button>
            <div className="p-2 aspect-video bg-black flex items-center justify-center">
              <img src={previewPhotoUrl} className="max-w-full max-h-[80vh] object-contain" alt="Preview Photo Material" referrerPolicy="no-referrer" />
            </div>
            <div className="p-4 bg-slate-900 text-white text-center text-xs font-semibold">
              {lang === "en" ? "Aesthetic Shorthand Resource" : "લઘુલિપિ છબી ગેલેરી"}
            </div>
          </div>
        </div>
      )}

      {/* 2. Embedded Video Masterclass Player Overlay */}
      {previewVideoUrl && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#0e1424] max-w-2xl w-full rounded-2xl overflow-hidden border border-slate-800 shadow-2xl relative">
            <button
              onClick={() => setPreviewVideoUrl(null)}
              className="absolute top-4 right-4 bg-black/50 hover:bg-black/80 text-white rounded-full p-2 cursor-pointer z-10"
            >
              ✕
            </button>
            <div className="p-1 aspect-video bg-black">
              <video src={previewVideoUrl} className="w-full h-full" controls autoPlay></video>
            </div>
            <div className="p-4 bg-slate-900 text-white text-center text-xs font-semibold">
              {lang === "en" ? "Video Lecture" : "વિડિયો પ્રદર્શન ડાઉનલોડ"}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
