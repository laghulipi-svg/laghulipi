import React, { useState } from "react";
import { DatabaseState } from "../types";
import {
  Calculator,
  Clock,
  Calendar,
  FileSpreadsheet,
  Landmark,
  Activity,
  FileText,
  Percent,
  RefreshCw,
  Keyboard
} from "lucide-react";

interface UtilityViewProps {
  lang: "en" | "gu";
  db: DatabaseState;
}

export default function UtilityView({ lang, db }: UtilityViewProps) {
  const [activeTabId, setActiveTabId] = useState<string>("steno");

  const fallbackPages = [
    { id: "steno", titleEn: "Steno Speed Calculator", titleGu: "સ્ટેનો સ્પીડ કેલ્ક્યુલેટર" },
    { id: "typing", titleEn: "Typing Practice", titleGu: "ટાઇપિંગ પ્રેક્ટિસ" },
    { id: "age", titleEn: "Age Calculator", titleGu: "ઉંમર કેલ્ક્યુલેટર" },
    { id: "tax", titleEn: "Income Tax Calculator (New v/s Old)", titleGu: "ઇન્કમ ટેક્સ કેલ્ક્યુલેટર (નવું VS જૂનું)" },
    { id: "loan", titleEn: "Loan EMI Calculator", titleGu: "લોન EMI કેલ્ક્યુલેટર" },
    { id: "bmi", titleEn: "BMI Calculator", titleGu: "BMI કેલ્ક્યુલેટર" },
    { id: "words", titleEn: "Words Calculator", titleGu: "શબ્દો કેલ્ક્યુલેટર" }
  ];

  const activePage = fallbackPages.find((p) => p.id === activeTabId) || fallbackPages[0];

  const getPageIcon = (id: string) => {
    switch (id) {
      case "steno":
        return <Calculator className="w-5 h-5 shrink-0" />;
      case "typing":
        return <Keyboard className="w-5 h-5 shrink-0" />;
      case "age":
        return <Clock className="w-5 h-5 shrink-0" />;
      case "tax":
        return <FileSpreadsheet className="w-5 h-5 shrink-0" />;
      case "loan":
        return <Landmark className="w-5 h-5 shrink-0" />;
      case "bmi":
        return <Activity className="w-5 h-5 shrink-0" />;
      case "words":
        return <FileText className="w-5 h-5 shrink-0" />;
      default:
        return <Calculator className="w-5 h-5 shrink-0" />;
    }
  };

  // --- PRACTICE MODULE 7: TYPING PRACTICE STATE ---
  const initialPassages = [
    {
      id: "p1",
      lang: "en",
      title: "Stenographer Success Principles",
      text: "Success as a professional stenographer requires immense concentration, consistent speed drilling, and a thorough mastery of phonetic outlines. Regular practice builds the mechanical eye-hand coordination necessary to record speech instantly and accurately without hesitation."
    },
    {
      id: "p2",
      lang: "en",
      title: "Gujarat High Court General Dictation Prep",
      text: "The administration of justice is an essential service for the protection of constitutional rights. Every reporter in the High Court must maintain a standard typing speed of forty words per minute and shorthand outline speeds of over one hundred words per minute."
    },
    {
      id: "p3",
      lang: "gu",
      title: "સરકારી કાર્યાલય પદ્ધતિ અને શ્રુતલેખન",
      text: "ગુજરાત સરકાર દ્વારા લેવાતી સ્ટેનોગ્રાફરની સ્પર્ધાત્મક પરીક્ષાઓમાં લઘુલિપિનું લખાણ ચોકસાઈપૂર્વક લખવું અનિવાર્ય છે. નિયમિત મહાવરો કરવાથી ઉચ્ચારણ અનુસાર ચિહ્નો ઝડપથી અને સુંદર આલેખી શકાય છે."
    },
    {
      id: "p4",
      lang: "gu",
      title: "ગુજરાતી ભાષાનું ગૌરવ અને પ્રભાવ",
      text: "માતૃભાષામાં શ્રુતલેખન કરવાની પ્રક્રિયા અત્યંત પવિત્ર ક્ષણ છે. ગુજરાતી શોર્ટહેન્ડ વ્યાવસાયિકોએ કારકિર્દીમાં ઉચ્ચ પદો મેળવવા ભાષાકીય વ્યાકરણ અને સામાન્ય જ્ઞાનમાં પણ કુશળતા પ્રાપ્ત કરવી અવશ્યક છે."
    }
  ];

  const [selectedPassageId, setSelectedPassageId] = useState<string>("p1");
  const [customPassageText, setCustomPassageText] = useState<string>("");
  const [useCustomPassage, setUseCustomPassage] = useState<boolean>(false);
  const [typedInput, setTypedInput] = useState<string>("");
  const [practiceTimeLimit, setPracticeTimeLimit] = useState<number>(60); // in seconds
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [timerIntervalId, setTimerIntervalId] = useState<any>(null);
  const [isTypingStarted, setIsTypingStarted] = useState<boolean>(false);
  const [isTypingFinished, setIsTypingFinished] = useState<boolean>(false);

  const getActivePassageText = () => {
    if (useCustomPassage) {
      return customPassageText || (lang === "en" ? "Practice makes a professional stenographer perfect." : "સતત મહાવરો સ્ટેનોગ્રાફરને સક્ષમ બનાવે છે.");
    }
    const pass = initialPassages.find(p => p.id === selectedPassageId);
    return pass ? pass.text : "";
  };

  const activePassageText = getActivePassageText();

  const handleTypingInput = (val: string) => {
    if (isTypingFinished) return;

    if (!isTypingStarted) {
      setIsTypingStarted(true);
      setElapsedTime(0);
      const interval = setInterval(() => {
        setElapsedTime((prev) => {
          if (practiceTimeLimit > 0 && prev >= practiceTimeLimit - 1) {
            clearInterval(interval);
            setIsTypingFinished(true);
            return practiceTimeLimit;
          }
          return prev + 1;
        });
      }, 1000);
      setTimerIntervalId(interval);
    }

    setTypedInput(val);

    if (val.trim() === activePassageText.trim()) {
      if (timerIntervalId) clearInterval(timerIntervalId);
      setIsTypingFinished(true);
    }
  };

  const resetTypingPractice = () => {
    if (timerIntervalId) clearInterval(timerIntervalId);
    setTimerIntervalId(null);
    setTypedInput("");
    setIsTypingStarted(false);
    setIsTypingFinished(false);
    setElapsedTime(0);
  };

  React.useEffect(() => {
    return () => {
      if (timerIntervalId) clearInterval(timerIntervalId);
    };
  }, [timerIntervalId]);

  React.useEffect(() => {
    resetTypingPractice();
  }, [activeTabId, selectedPassageId, useCustomPassage]);

  const getTypingStats = () => {
    const timeInMins = elapsedTime > 0 ? elapsedTime / 60 : 1 / 60;
    const totalChars = typedInput.length;
    const grossWpm = Math.round((totalChars / 5) / timeInMins);

    let errorsCount = 0;
    const refChars = activePassageText;
    for (let i = 0; i < typedInput.length; i++) {
      if (typedInput[i] !== refChars[i]) {
        errorsCount++;
      }
    }

    const netWpm = Math.max(0, Math.round(((totalChars - errorsCount)/ 5) / timeInMins));
    const accuracy = totalChars > 0 ? Math.max(0, Math.round(((totalChars - errorsCount) / totalChars) * 100)) : 100;

    return { grossWpm, netWpm, accuracy, errorsCount, totalChars };
  };

  const typingStats = getTypingStats();

  // --- CALCULATOR 1: STENO SPEED STATE ---
  const [stenoWords, setStenoWords] = useState<number>(400);
  const [stenoMinutes, setStenoMinutes] = useState<number>(5);
  const [stenoErrors, setStenoErrors] = useState<number>(10);

  const calculateSteno = () => {
    const wpm = stenoMinutes > 0 ? Math.round(stenoWords / stenoMinutes) : 0;
    const accuracy = stenoWords > 0 ? Math.max(0, parseFloat((((stenoWords - stenoErrors) / stenoWords) * 100).toFixed(2))) : 0;
    return { wpm, accuracy };
  };
  const stenoRes = calculateSteno();

  // --- CALCULATOR 2: AGE CALCULATOR STATE ---
  const [birthDate, setBirthDate] = useState<string>("1998-06-15");
  const [targetDate, setTargetDate] = useState<string>(new Date().toISOString().split("T")[0]);

  const calculateAge = () => {
    const birth = new Date(birthDate);
    const target = new Date(targetDate);
    if (isNaN(birth.getTime()) || isNaN(target.getTime()) || birth > target) {
      return null;
    }

    let years = target.getFullYear() - birth.getFullYear();
    let months = target.getMonth() - birth.getMonth();
    let days = target.getDate() - birth.getDate();

    if (days < 0) {
      const prevMonth = new Date(target.getFullYear(), target.getMonth(), 0);
      days += prevMonth.getDate();
      months--;
    }
    if (months < 0) {
      months += 12;
      years--;
    }

    // Days until next birthday
    const nextBday = new Date(target.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBday < target) {
      nextBday.setFullYear(target.getFullYear() + 1);
    }
    const diffMs = nextBday.getTime() - target.getTime();
    const daysToBday = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

    return { years, months, days, daysToBday };
  };
  const ageRes = calculateAge();

  // --- CALCULATOR 3: INCOME TAX CALCULATOR STATE (New v/s Old FY 2026-27 / AY 2027-28) ---
  const [grossIncome, setGrossIncome] = useState<number>(1000000);
  const [ded80C, setDed80C] = useState<number>(150000); // Max 1.5L
  const [dedOther, setDedOther] = useState<number>(50000);

  const calculateTax = () => {
    // 1. OLD REGIME
    const oldStdDeduction = 50000;
    const old80C = Math.min(150000, Math.max(0, ded80C));
    const oldOther = Math.max(0, dedOther);
    const oldTaxable = Math.max(0, grossIncome - oldStdDeduction - old80C - oldOther);

    // Old Slabs: up to 2.5L Nil, 2.5L-5L 5%, 5L-10L 20%, above 10L 30%
    let oldTaxSum = 0;
    if (oldTaxable > 1000000) {
      oldTaxSum += (oldTaxable - 1000000) * 0.3;
      oldTaxSum += 500000 * 0.2; // 5L to 10L
      oldTaxSum += 250000 * 0.05; // 2.5L to 5L
    } else if (oldTaxable > 500000) {
      oldTaxSum += (oldTaxable - 500000) * 0.2;
      oldTaxSum += 250000 * 0.05;
    } else if (oldTaxable > 250000) {
      oldTaxSum += (oldTaxable - 250000) * 0.05;
    }

    // Rebate u/s 87A (Old Scheme: Nil if income <= 5,00,000)
    if (oldTaxable <= 500000) {
      oldTaxSum = 0;
    }
    const oldCess = oldTaxSum * 0.04;
    const oldTotalTax = oldTaxSum + oldCess;

    // 2. NEW REGIME (AY 2027-28 / FY 2026-27 latest slabs)
    const newStdDeduction = 75000;
    const newTaxable = Math.max(0, grossIncome - newStdDeduction);

    // New Slabs: Up to 3L Nil, 3-7L 5%, 7-10L 10%, 10-12L 15%, 12-15L 20%, above 15L 30%
    let newTaxSum = 0;
    if (newTaxable > 1500000) {
      newTaxSum += (newTaxable - 1500000) * 0.3;
      newTaxSum += 300000 * 0.2; // 12-15L
      newTaxSum += 200000 * 0.15; // 10-12L
      newTaxSum += 300000 * 0.10; // 7-10L
      newTaxSum += 400000 * 0.05; // 3-7L
    } else if (newTaxable > 1200000) {
      newTaxSum += (newTaxable - 1200000) * 0.2;
      newTaxSum += 200000 * 0.15;
      newTaxSum += 300000 * 0.10;
      newTaxSum += 400000 * 0.05;
    } else if (newTaxable > 1000000) {
      newTaxSum += (newTaxable - 1000000) * 0.15;
      newTaxSum += 300000 * 0.10;
      newTaxSum += 400000 * 0.05;
    } else if (newTaxable > 700000) {
      newTaxSum += (newTaxable - 700000) * 0.10;
      newTaxSum += 400000 * 0.05;
    } else if (newTaxable > 300000) {
      newTaxSum += (newTaxable - 300000) * 0.05;
    }

    // Rebate u/s 87A under New Regime (Rebate up to 20,000 u/s 87A makes tax NIL up to 7,00,000)
    if (newTaxable <= 700000) {
      newTaxSum = 0;
    }
    const newCess = newTaxSum * 0.04;
    const newTotalTax = newTaxSum + newCess;

    return {
      oldTaxable,
      oldTotalTax,
      newTaxable,
      newTotalTax,
      savings: Math.abs(oldTotalTax - newTotalTax),
      benefitRegime: oldTotalTax > newTotalTax ? "New Regime" : oldTotalTax < newTotalTax ? "Old Regime" : "Both identical"
    };
  };
  const taxRes = calculateTax();

  // --- CALCULATOR 4: LOAN EMI STATE ---
  const [loanVal, setLoanVal] = useState<number>(500000);
  const [loanRate, setLoanRate] = useState<number>(8.5);
  const [loanTenure, setLoanTenure] = useState<number>(5); // in years

  const calculateEMI = () => {
    const P = loanVal;
    const r = (loanRate / 12) / 100;
    const n = loanTenure * 12;

    if (r === 0) {
      const emi = P / n;
      const totalPay = P;
      const totalInterest = 0;
      return { emi, totalPay, totalInterest };
    }

    const emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPay = emi * n;
    const totalInterest = totalPay - P;

    return { emi, totalPay, totalInterest };
  };
  const emiRes = calculateEMI();

  // --- CALCULATOR 5: BMI STATE ---
  const [bmiWeight, setBmiWeight] = useState<number>(70);
  const [bmiHeight, setBmiHeight] = useState<number>(175);

  const calculateBMI = () => {
    const hM = bmiHeight / 100;
    if (hM <= 0) return { bmi: 0, cat: "Unknown", color: "text-slate-500" };
    const bmi = parseFloat((bmiWeight / (hM * hM)).toFixed(1));

    let cat = "Normal";
    let catGu = "સામાન્ય વજન";
    let color = "text-emerald-500 bg-emerald-500/10 border-emerald-500/20";
    let barWidth = "50%";

    if (bmi < 18.5) {
      cat = "Underweight";
      catGu = "ઓછું વજન";
      color = "text-amber-500 bg-amber-500/10 border-amber-500/20";
      barWidth = "25%";
    } else if (bmi < 25) {
      cat = "Normal Weight";
      catGu = "સ્વસ્થ સામાન્ય વજન";
      color = "text-emerald-500 bg-emerald-500/10 border-emerald-500/20";
      barWidth = "50%";
    } else if (bmi < 30) {
      cat = "Overweight";
      catGu = "વધુ વજન";
      color = "text-orange-500 bg-orange-500/10 border-orange-500/20";
      barWidth = "75%";
    } else {
      cat = "Obese";
      catGu = "મેદસ્વીતા";
      color = "text-rose-500 bg-rose-500/10 border-rose-500/20";
      barWidth = "95%";
    }

    return { bmi, cat, catGu, color, barWidth };
  };
  const bmiRes = calculateBMI();

  // --- CALCULATOR 6: WORDS STATE ---
  const [wordText, setWordText] = useState<string>(
    "Shorthand and administrative practice outlines are primary guidelines for clerical success. Jitendra Soni shorthand training institute offers complete audio guidance for stenography tests in Gujarat, India."
  );

  const calculateWords = () => {
    const charsWithSpace = wordText.length;
    const charsNoSpace = wordText.replace(/\s/g, "").length;
    const wordsArr = wordText.trim() === "" ? [] : wordText.trim().split(/\s+/);
    const wordsCount = wordsArr.length;
    const linesCount = wordText === "" ? 0 : wordText.split(/\r\n|\r|\n/).length;

    // Speeds: reading standard (200 WPM), steno standard (80 WPM), typing (40 WPM)
    const readMin = Math.max(1, Math.round(wordsCount / 200));
    const typeMin = Math.max(1, Math.round(wordsCount / 40));

    return { charsWithSpace, charsNoSpace, wordsCount, linesCount, readMin, typeMin };
  };
  const wordRes = calculateWords();

  return (
    <div className="space-y-6 animate-fade-in font-sans">
      {/* View Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <h1 className="text-3xl font-bold font-serif-literata text-slate-800 dark:text-white">
          {lang === "en" ? "Interactive Calculators" : "ઇન્ટરેક્ટિવ ઉપયોગિતા કેલ્ક્યુલેટર્સ"}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {lang === "en"
            ? "Free smart utility tools."
            : "મફત સ્માર્ટ ઉપયોગિતા સાધનો."}
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Left Side Tab Rails */}
        <div className="w-full lg:w-1/3 flex flex-col gap-2.5 shrink-0">
          {fallbackPages.map((page) => {
            const isActive = page.id === activeTabId;
            return (
              <button
                key={page.id}
                id={`tab-${page.id}`}
                onClick={() => setActiveTabId(page.id)}
                className={`flex items-center gap-3.5 px-4 py-4 rounded-xl text-xs md:text-sm font-bold border transition-all text-left cursor-pointer ${
                  isActive
                    ? "bg-indigo-600 text-white shadow-md border-indigo-600"
                    : "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-150 dark:border-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-850"
                }`}
              >
                <div className={`p-1.5 rounded-lg ${isActive ? "bg-white/20 text-white" : "bg-slate-100 dark:bg-slate-800 text-indigo-500"}`}>
                  {getPageIcon(page.id)}
                </div>
                <span>{lang === "en" ? page.titleEn : page.titleGu}</span>
              </button>
            );
          })}
        </div>

        {/* Right Side Main Interactive Interface Area */}
        <div className="flex-1 rounded-2xl bg-white dark:bg-[#0c101d]/60 border border-slate-200 dark:border-slate-800/80 p-6 md:p-8 shadow-sm relative overflow-hidden min-h-[460px]">
          <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

          <div className="space-y-6">
            {/* Tab Header title */}
            <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800/80 pb-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 dark:bg-indigo-400/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                {getPageIcon(activeTabId)}
              </div>
              <div>
                <h2 className="text-xl font-bold font-serif-literata text-slate-800 dark:text-white leading-snug">
                  {lang === "en" ? activePage.titleEn : activePage.titleGu}
                </h2>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mt-0.5">
                  {lang === "en" ? "Interactive Widget" : "ઇન્ટરેક્ટિવ વિજેટ"}
                </p>
              </div>
            </div>

            {/* --- 1. STENO ACCURACY & SPEED CALCULATOR --- */}
            {activeTabId === "steno" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Total Dictation Words" : "કુલ લઘુલેખન શબ્દો"}
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={stenoWords}
                      onChange={(e) => setStenoWords(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Time Taken (Minutes)" : "સમયગાળો (મિનિટ)"}
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={stenoMinutes}
                      onChange={(e) => setStenoMinutes(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Total Errors / Mistakes" : "કુલ ભૂલો અને છેકછાક"}
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={stenoErrors}
                      onChange={(e) => setStenoErrors(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>
                </div>

                {/* Score results card layout */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-4">
                  <div className="p-5 rounded-2xl bg-indigo-50/40 dark:bg-indigo-950/20 border border-indigo-100/50 dark:border-indigo-950/40 text-center space-y-1 block">
                    <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider">
                      {lang === "en" ? "Calculated Speed" : "ગણતરી કરેલી સ્પીડ"}
                    </span>
                    <p className="text-4xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                      {stenoRes.wpm} <span className="text-xs font-bold uppercase">WPM</span>
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {lang === "en" ? "Words per Minute pace" : "શબ્દો પ્રતિ મિનિટ ઝડપ"}
                    </p>
                  </div>

                  <div className="p-5 rounded-2xl bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100/50 dark:border-emerald-950/40 text-center space-y-1 block">
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                      {lang === "en" ? "Accuracy Percentage" : "ચોકસાઈ ટકાવારી"}
                    </span>
                    <p className="text-4xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                      {stenoRes.accuracy}%
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {lang === "en"
                        ? `Allowed Mistakes: ${Math.round(stenoWords * 0.05)} (at 95% limit)`
                        : `માન્ય ભૂલો: ${Math.round(stenoWords * 0.05)} (૯૫% લિમિટ પ્રમાણે)`}
                    </p>
                  </div>
                </div>

                {/* Accuracy validation feedback threshold */}
                <div className={`p-4 rounded-xl border text-xs leading-relaxed ${
                  stenoRes.accuracy >= 95 
                    ? "bg-emerald-500/5 border-emerald-500/20 text-emerald-700 dark:text-emerald-400" 
                    : stenoRes.accuracy >= 90 
                    ? "bg-indigo-500/5 border-indigo-500/20 text-indigo-700 dark:text-indigo-400" 
                    : "bg-rose-500/5 border-rose-500/20 text-rose-700 dark:text-rose-400"
                }`}>
                  <span className="font-bold underline uppercase mr-1">
                    {lang === "en" ? "Evaluation Status:" : "ચોકસાઈ અહેવાલ:"}
                  </span>
                  {stenoRes.accuracy >= 95 ? (
                    lang === "en" 
                      ? "Outstanding transcript! You meet the strict 95% threshold required by GSSSB, High Court, and GAD administrative examinations." 
                      : "અદ્ભુત ચોકસાઈ! તમે ગુજરાત ગૌણ સેવા (GSSSB) અને હાઇકોર્ટ દ્વારા લેવાતી પરીક્ષાઓના ૯૫% માપદંડોને સંપૂર્ણપણે ઓળંગો છો."
                  ) : stenoRes.accuracy >= 90 ? (
                    lang === "en"
                      ? "Good attempt. Your shorthand outlines are readable, but you need slightly tighter control on small omissions. Standard passes require 95%."
                      : "સારો પ્રયત્ન. આકૃતિઓ પ્રમાણસર છે, પણ પરીક્ષા પાસ કરવા ૯૫% લક્ષ્યાંક પ્રાપ્ત થાય ત્યાં સુધી દૈનિક ૨ ડિકટેશન લખવાની ટેવ પાડો."
                  ) : (
                    lang === "en"
                      ? "Practice needed. Mistakes exceed 10%. Slow down the playback speed, focus on correct vowel signs, and rewrite the difficult phrases."
                      : "હજુ વધુ મહેનત જરૂરી છે. ભૂલો ૧૦% થી વધારે છે. ઑડિયો પ્લેબેક હોલ્ડ કરો અને પાયાના સંક્ષિપ્ત રૂપોનું પુનરાવર્તન કરો."
                  )}
                </div>
              </div>
            )}

            {/* --- PRACTICE MODULE 7: INTERACTIVE TYPING PRACTICE STUDIO SCREEN --- */}
            {activeTabId === "typing" && (
              <div className="space-y-6">
                
                {/* Passage Configuration Options */}
                <div className="bg-slate-50/70 dark:bg-slate-900/40 p-4 rounded-xl border border-slate-200/50 dark:border-slate-800/65 space-y-4 text-xs font-sans">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <p className="font-bold text-slate-700 dark:text-slate-350 uppercase tracking-wider text-[11px]">
                      {lang === "en" ? "Configure Typing Session" : "સેશન માટે સેટિંગ્સ સેટ કરો"}
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setUseCustomPassage(false);
                          resetTypingPractice();
                        }}
                        className={`px-3 py-1.5 rounded-lg border text-[10.5px] font-bold cursor-pointer transition ${
                          !useCustomPassage
                            ? "bg-indigo-600 text-white border-indigo-600"
                            : "bg-white dark:bg-slate-950 text-slate-650 dark:text-slate-400 border-slate-200 dark:border-slate-800"
                        }`}
                      >
                        {lang === "en" ? "Use Presets" : "પ્રીસેટ્સ વાપરો"}
                      </button>
                      <button
                        onClick={() => {
                          setUseCustomPassage(true);
                          resetTypingPractice();
                        }}
                        className={`px-3 py-1.5 rounded-lg border text-[10.5px] font-bold cursor-pointer transition ${
                          useCustomPassage
                            ? "bg-indigo-600 text-white border-indigo-600"
                            : "bg-white dark:bg-slate-950 text-slate-650 dark:text-slate-400 border-slate-200 dark:border-slate-800"
                        }`}
                      >
                        {lang === "en" ? "Paste Custom Text" : "કસ્ટમ લખાણ પેસ્ટ કરો"}
                      </button>
                    </div>
                  </div>

                  {!useCustomPassage ? (
                    <div className="space-y-2">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                        {lang === "en" ? "Select Lesson Outline:" : "પાઠ મટીરીયલ પસંદ કરો:"}
                      </label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {initialPassages.map((p) => {
                          return (
                            <button
                              key={p.id}
                              onClick={() => {
                                setSelectedPassageId(p.id);
                                resetTypingPractice();
                              }}
                              className={`px-3 py-2.5 rounded-lg border text-left font-semibold transition cursor-pointer flex justify-between items-center ${
                                selectedPassageId === p.id
                                  ? "bg-indigo-50/60 dark:bg-indigo-950/20 border-indigo-500 text-indigo-700 dark:text-indigo-300"
                                  : "bg-white dark:bg-slate-950 text-slate-650 dark:text-slate-400 border-slate-200 dark:border-slate-850 hover:bg-slate-50"
                              }`}
                            >
                              <span className="truncate pr-2">{p.title}</span>
                              <span className="text-[9px] px-1.5 py-0.5 rounded uppercase font-mono tracking-wider font-extrabold bg-slate-100 dark:bg-slate-800 text-slate-400">
                                {p.lang.toUpperCase()}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                        {lang === "en" ? "Paste Custom Script Outline:" : "સંદર્ભ ફકરો અહીં પેસ્ટ કરો:"}
                      </label>
                      <textarea
                        rows={2}
                        value={customPassageText}
                        onChange={(e) => {
                          setCustomPassageText(e.target.value);
                          resetTypingPractice();
                        }}
                        placeholder={
                          lang === "en"
                            ? "Paste the shorthand transcript text or typing test contents here to practice..."
                            : "તમારો કસ્ટમ ગુજરાતી કે અંગ્રેજી ફકરો અહીં સબમિટ કરો..."
                        }
                        className="w-full text-xs font-mono p-3 bg-white dark:bg-slate-955 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-700 dark:text-white leading-relaxed focus:border-indigo-500 focus:outline-none bg-slate-50/20"
                      />
                    </div>
                  )}

                  {/* Timer selection configuration */}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200/40 dark:border-slate-800/40 pt-3 text-xs">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                        {lang === "en" ? "Set Practice Duration:" : "પ્રેક્ટિસ સમયગાળો સેટ કરો:"}
                      </span>
                      <div className="flex gap-1.5">
                        {[30, 60, 120, 300, 0].map((dur) => (
                          <button
                            key={dur}
                            onClick={() => {
                              setPracticeTimeLimit(dur);
                              resetTypingPractice();
                            }}
                            className={`px-2 md:px-2.5 py-1 rounded text-[10.5px] font-mono cursor-pointer font-bold transition border ${
                              practiceTimeLimit === dur
                                ? "bg-indigo-500/10 text-indigo-505 border-indigo-500/30"
                                : "bg-white dark:bg-slate-950 text-slate-500 border-slate-200 dark:border-slate-850 hover:bg-slate-100"
                            }`}
                          >
                            {dur === 0 ? (lang === "en" ? "Unlimited" : "અમર્યાદિત") : `${dur}s`}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={resetTypingPractice}
                      className="px-3 py-1.5 text-xs text-rose-500 hover:text-rose-600 dark:text-rose-400 font-bold border border-rose-500/20 hover:bg-rose-500/5 rounded-lg cursor-pointer transition flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>{lang === "en" ? "Restart" : "ફરીથી શરૂ"}</span>
                    </button>
                  </div>
                </div>

                {/* Display Passage Interactive Character Highlights */}
                <div className="space-y-2 font-sans">
                  <div className="flex justify-between items-center">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Reference Passage Text Monitor:" : "ઉપરોક્ત લખાણ મોનિટર દર્શક:"}
                    </label>
                    <span className="text-[10px] bg-indigo-550/10 text-indigo-500 dark:text-indigo-400 font-mono font-black px-2 py-0.5 rounded">
                      {activePassageText.length} Chars • {activePassageText.trim().split(/\s+/).filter(Boolean).length} Words
                    </span>
                  </div>
                  
                  {/* Matching rendering display box */}
                  <div className="p-4 bg-[#F4F6F9] dark:bg-[#111726]/60 border border-slate-200 dark:border-slate-800 rounded-2xl max-h-48 overflow-y-auto leading-relaxed select-none text-sm font-mono tracking-wider transition-colors duration-155">
                    {activePassageText.split("").map((char, index) => {
                      let charColorClass = "text-slate-400 dark:text-slate-500";
                      let charBgClass = "";

                      if (index < typedInput.length) {
                        if (typedInput[index] === char) {
                          charColorClass = "text-emerald-600 dark:text-emerald-400 font-bold";
                        } else {
                          charColorClass = "text-white";
                          charBgClass = "bg-rose-550 rounded px-[1px]";
                        }
                      } else if (index === typedInput.length) {
                        charBgClass = "bg-indigo-500/20 border-b-2 border-indigo-500 animate-pulse rounded-xs";
                      }

                      return (
                        <span key={index} className={`${charColorClass} ${charBgClass}`}>
                          {char}
                        </span>
                      );
                    })}
                  </div>
                </div>

                {/* Live Output typing interactive textbox area */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs font-sans">
                    <span className="font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Start typing right here down below:" : "નવી સ્પીડ ચકાસવા માટે નીચે ટાઈપ કરો:"}
                    </span>
                    
                    {/* Active Timer visual warning */}
                    <span className="font-mono text-xs font-bold flex items-center gap-1 text-slate-450 dark:text-slate-400">
                      {isTypingStarted && !isTypingFinished ? (
                        <span className="flex h-2 w-2 relative">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                        </span>
                      ) : null}
                      {lang === "en" ? "Time Elapsed:" : "સમય વિત્યો:"}{" "}
                      <strong className="text-slate-700 dark:text-white">
                        {elapsedTime}s
                      </strong>
                      {practiceTimeLimit > 0 && (
                        <>
                          <span>/</span>
                          <span className="text-indigo-500 font-bold">{practiceTimeLimit}s</span>
                        </>
                      )}
                    </span>
                  </div>

                  <textarea
                    rows={4}
                    value={typedInput}
                    onChange={(e) => handleTypingInput(e.target.value)}
                    disabled={isTypingFinished}
                    placeholder={
                      lang === "en"
                        ? "Start typing the visible characters from above. The timer will automatically begin as you enter the first letter..."
                        : "ઉપરના અક્ષરો ટાઈપ કરવાનું શરૂ કરો. તમે પ્રથમ અક્ષર ઉમેરતા જ સમયગાળો આપમેળે સક્રિય થશે..."
                    }
                    className="w-full text-sm font-mono p-4 bg-white dark:bg-slate-900 border-2 border-indigo-100/55 dark:border-slate-800 rounded-2xl leading-relaxed outline-none focus:border-indigo-500 text-slate-700 dark:text-white shadow-inner focus:ring-1 focus:ring-indigo-500/20 transition duration-150 disabled:bg-slate-100 dark:disabled:bg-slate-950/40"
                  />
                </div>

                {/* Live Realtime stats cards showcase */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2 font-sans">
                  <div className="p-4 rounded-xl bg-indigo-50/40 dark:bg-indigo-950/15 border border-indigo-100/40 dark:border-indigo-950/30 text-center">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-indigo-500 block">
                      {lang === "en" ? "Gross Speed" : "ગ્રોસ સ્પીડ"}
                    </span>
                    <p className="text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400 mt-1">
                      {typingStats.grossWpm} <span className="text-xs uppercase font-bold text-slate-400">WPM</span>
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-emerald-500/[0.04] border border-emerald-500/10 text-center">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-505 block">
                      {lang === "en" ? "Net Core WPM" : "નેટ સ્પીડ"}
                    </span>
                    <p className="text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                      {typingStats.netWpm} <span className="text-xs uppercase font-bold text-slate-400 font-sans">WPM</span>
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800 text-center">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                      {lang === "en" ? "Accuracy %" : "ચોકસાઈ ટકા"}
                    </span>
                    <p className="text-2xl font-black font-mono text-slate-800 dark:text-slate-100 mt-1">
                      {typingStats.accuracy}%
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-red-500/[0.04] border border-red-500/10 text-center">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-rose-500 block">
                      {lang === "en" ? "Typos / Errors" : "કુલ લખાણ ક્ષતિ"}
                    </span>
                    <p className="text-2xl font-black font-mono text-rose-600 dark:text-rose-400 mt-1">
                      {typingStats.errorsCount}
                    </p>
                  </div>
                </div>

                {/* Finish & Performance Evaluation Coaching Assessment */}
                {isTypingFinished && (
                  <div className="p-4 bg-emerald-500/5 dark:bg-emerald-500/[0.02] border border-emerald-500/15 rounded-xl space-y-1 text-xs animate-fadeIn font-sans">
                    <p className="font-extrabold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest text-[10px]">
                      🏆 {lang === "en" ? "Typing Session Completed!" : "ટાઇપિંગ સત્ર સફળતાપૂર્વક પૂર્ણ થયું!"}
                    </p>
                    <p className="text-slate-600 dark:text-slate-350 leading-relaxed font-sans">
                      {lang === "en" ? (
                        <>
                          Outstanding focus! You recorded a Net Shorthand typing speed of <strong className="text-emerald-500">{typingStats.netWpm} WPM</strong> with an accuracy rate of <strong>{typingStats.accuracy}%</strong>. Keep practicing daily to hit high GSSSB benchmarks!
                        </>
                      ) : (
                        <>
                          સરસ પ્રગતિ! તમારો સરેરાશ બિન-ક્ષતિ ટાઇપિંગ રેટ <strong className="text-emerald-500">{typingStats.netWpm} શબ્દો પ્રતિ મિનિટ</strong> છે અને ચોકસાઇનો દર <strong>{typingStats.accuracy}%</strong> રહ્યો છે. હજુ વધુ સ્પર્ધાત્મક પરિણામો મેળવવા માટે સત્ર પુનરાવર્તિત કરો.
                        </>
                      )}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* --- 2. AGE CALCULATOR CODE --- */}
            {activeTabId === "age" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Date of Birth (DOB)" : "જન્મ તારીખ"}
                    </label>
                    <input
                      type="date"
                      value={birthDate}
                      onChange={(e) => setBirthDate(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Age at the Date" : "આ તારીખે ઉંમર"}
                    </label>
                    <input
                      type="date"
                      value={targetDate}
                      onChange={(e) => setTargetDate(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>
                </div>

                {ageRes ? (
                  <div className="space-y-6 pt-2">
                    {/* Visual metrics badges */}
                    <div className="grid grid-cols-3 gap-3 md:gap-5 text-center">
                      <div className="p-4 bg-[#F4F6F9] dark:bg-[#111726]/60 border border-slate-150 dark:border-slate-800 rounded-2xl block shadow-inner">
                        <p className="text-3xl md:text-4xl font-extrabold font-mono text-indigo-600 dark:text-indigo-400">
                          {ageRes.years}
                        </p>
                        <p className="text-[10px] md:text-xs text-slate-500 font-bold uppercase mt-1">
                          {lang === "en" ? "Years" : "વર્ષ"}
                        </p>
                      </div>

                      <div className="p-4 bg-[#F4F6F9] dark:bg-[#111726]/60 border border-slate-150 dark:border-slate-800 rounded-2xl block shadow-inner">
                        <p className="text-3xl md:text-4xl font-extrabold font-mono text-indigo-600 dark:text-indigo-400">
                          {ageRes.months}
                        </p>
                        <p className="text-[10px] md:text-xs text-slate-500 font-bold uppercase mt-1">
                          {lang === "en" ? "Months" : "માસ"}
                        </p>
                      </div>

                      <div className="p-4 bg-[#F4F6F9] dark:bg-[#111726]/60 border border-slate-150 dark:border-slate-800 rounded-2xl block shadow-inner">
                        <p className="text-3xl md:text-4xl font-extrabold font-mono text-indigo-600 dark:text-indigo-400">
                          {ageRes.days}
                        </p>
                        <p className="text-[10px] md:text-xs text-slate-500 font-bold uppercase mt-1">
                          {lang === "en" ? "Days" : "દિવસ"}
                        </p>
                      </div>
                    </div>

                    {/* Upcoming birthday alert notification banner */}
                    <div className="flex items-center gap-3 p-4 bg-amber-500/5 border border-amber-500/15 rounded-xl text-xs text-amber-800 dark:text-amber-350">
                      <Calendar className="w-5 h-5 shrink-0 text-amber-500" />
                      <div>
                        {lang === "en" ? (
                          <p>
                            Your next birthday occurs in{" "}
                            <span className="font-bold underline text-amber-600 dark:text-amber-400">
                              {ageRes.daysToBday} days
                            </span>
                            ! Keep practicing to secure your appointment before you get older!
                          </p>
                        ) : (
                          <p>
                            તમારો આગામી જન્મદિવસ હવે{" "}
                            <span className="font-bold underline text-amber-600 dark:text-amber-400">
                              {ageRes.daysToBday} દિવસ
                            </span>{" "}
                            પછી આવે છે! ઉંમર વધે તે પહેલા તમારી સ્ટેનો સરકારી નોકરી સુરક્ષિત કરો!
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-12 text-center text-slate-400 dark:text-slate-600 italic text-xs">
                    {lang === "en"
                      ? "Please pick a valid Date of Birth which is older than target date."
                      : "કૃપા કરીને જન્મ તારીખની યોગ્ય પસંદગી કરો."}
                  </div>
                )}
              </div>
            )}

            {/* --- 3. INCOME TAX COMPARISON CALCULATOR (New vs Old) --- */}
            {activeTabId === "tax" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div className="space-y-1.5 md:col-span-1">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Gross Annual Income (₹)" : "કુલ વાર્ષિક આવક (₹)"}
                    </label>
                    <input
                      type="number"
                      step={50000}
                      value={grossIncome}
                      onChange={(e) => setGrossIncome(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Section 80C Ded. (₹)" : "કલમ 80C રોકાણ (₹)"}
                    </label>
                    <input
                      type="number"
                      max={150000}
                      step={10000}
                      value={ded80C}
                      onChange={(e) => setDed80C(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                    <span className="text-[9px] text-slate-400 block font-medium">Max limit ₹1.5L (Old Regime Only)</span>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Other Ded: 80D / HRA (₹)" : "અન્ય કપાત: 80D / HRA (₹)"}
                    </label>
                    <input
                      type="number"
                      step={5000}
                      value={dedOther}
                      onChange={(e) => setDedOther(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                    <span className="text-[9px] text-slate-400 block font-medium">Applies to Old Regime Only</span>
                  </div>
                </div>

                {/* Comparative details block */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                  {/* Old tax regime card */}
                  <div className="p-5 rounded-2xl bg-[#F4F6F9] dark:bg-[#111726]/60 border border-slate-200 dark:border-slate-800/80 space-y-3.5 shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-200/60 dark:border-slate-850 pb-2">
                      <h4 className="text-sm font-bold text-slate-700 dark:text-slate-200">
                        {lang === "en" ? "Old Tax Regime" : "જૂની ટેક્સ વ્યવસ્થા"}
                      </h4>
                      <span className="text-[9px] font-bold bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded-full">
                        AY 2027-28
                      </span>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
                        {lang === "en" ? "Net Taxable Income" : "કરપાત્ર ચોખ્ખી આવક"}
                      </p>
                      <p className="text-md font-mono font-bold text-slate-800 dark:text-slate-100">
                        ₹{taxRes.oldTaxable.toLocaleString("en-IN")}
                      </p>
                    </div>
                    <div className="space-y-1 pt-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
                        {lang === "en" ? "Total Payable Tax" : "કુલ લાયક આવકવેરો"}
                      </p>
                      <p className="text-2xl font-black font-mono text-slate-800 dark:text-slate-50">
                        ₹{Math.round(taxRes.oldTotalTax).toLocaleString("en-IN")}
                      </p>
                    </div>
                  </div>

                  {/* New tax regime card */}
                  <div className="p-5 rounded-2xl bg-indigo-50/20 dark:bg-indigo-950/10 border border-indigo-100/50 dark:border-indigo-950/40 space-y-3.5 shadow-sm relative overflow-hidden">
                    {taxRes.benefitRegime === "New Regime" && (
                      <span className="absolute top-2 right-2 bg-gradient-to-r from-emerald-500 to-indigo-500 text-white text-[8px] font-sans font-black tracking-wider uppercase px-2.5 py-1 rounded-bl-xl shadow-md">
                        {lang === "en" ? "Recommended" : "આગ્રહણીય"}
                      </span>
                    )}
                    <div className="flex items-center justify-between border-b border-indigo-100/40 dark:border-indigo-900 pb-2">
                      <h4 className="text-sm font-bold text-indigo-700 dark:text-indigo-300">
                        {lang === "en" ? "New Tax Regime" : "નવી ટેક્સ વ્યવસ્થા"}
                      </h4>
                      <span className="text-[9px] font-bold bg-indigo-500/10 dark:bg-indigo-400/10 text-indigo-500 px-2 py-0.5 rounded-full">
                        u/s 115BAC
                      </span>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wide">
                        {lang === "en" ? "Net Taxable Income" : "કરપાત્ર ચોખ્ખી આવક"}
                      </p>
                      <p className="text-md font-mono font-bold text-indigo-800 dark:text-indigo-350">
                        ₹{taxRes.newTaxable.toLocaleString("en-IN")}
                      </p>
                    </div>
                    <div className="space-y-1 pt-1">
                      <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wide">
                        {lang === "en" ? "Total Payable Tax" : "કુલ લાયક આવકવેરો"}
                      </p>
                      <p className="text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                        ₹{Math.round(taxRes.newTotalTax).toLocaleString("en-IN")}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Savings recommendations message */}
                {taxRes.savings > 0 ? (
                  <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/15 text-xs text-emerald-800 dark:text-emerald-400 flex items-center justify-between">
                    <div>
                      {lang === "en" ? (
                        <p>
                          You save{" "}
                          <span className="font-extrabold text-md bg-emerald-500 text-white dark:bg-slate-900 dark:text-emerald-400 px-1.5 py-0.5 rounded">
                            ₹{Math.round(taxRes.savings).toLocaleString("en-IN")}
                          </span>{" "}
                          annually by planning section allocation in standard{" "}
                          <span className="font-bold">{taxRes.benefitRegime}</span>.
                        </p>
                      ) : (
                        <p>
                          તમે સ્ટાન્ડર્ડ <span className="font-bold">{taxRes.benefitRegime === "New Regime" ? "નવી ટેક્સ વ્યવસ્થા" : "જૂની ટેક્સ વ્યવસ્થા"}</span> રાખવાથી વાર્ષિક{" "}
                          <span className="font-extrabold text-md bg-emerald-500 text-white dark:bg-slate-900 dark:text-emerald-400 px-1.5 py-0.5 rounded">
                            ₹{Math.round(taxRes.savings).toLocaleString("en-IN")}
                          </span>{" "}
                          બચાવી શકો છો.
                        </p>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-indigo-500/5 border border-indigo-150 text-xs text-indigo-700 dark:text-indigo-400 text-center">
                    {lang === "en"
                      ? "Both tax regimes yield exactly 100% identical tax liabilities for this income limit."
                      : "આ આવક મર્યાદા માટે બંને કર પ્રણાલીઓમાં સરખું જ ટેક્સ ભરવા પાત્ર બને છે."}
                  </div>
                )}
              </div>
            )}

            {/* --- 4. LOAN EMI CALCULATOR --- */}
            {activeTabId === "loan" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Loan Amount Principal (₹)" : "લોનની કુલ રકમ (મુદલ રકમ - ₹)"}
                    </label>
                    <input
                      type="number"
                      step={50000}
                      value={loanVal}
                      onChange={(e) => setLoanVal(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Annual Interest Rate (%)" : "વાર્ષિક વ્યાજ દર (%)"}
                    </label>
                    <input
                      type="number"
                      step={0.1}
                      min={0}
                      value={loanRate}
                      onChange={(e) => setLoanRate(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Tenure Duration (Years)" : "લોનની સમય મર્યાદા (વર્ષ)"}
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={loanTenure}
                      onChange={(e) => setLoanTenure(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>
                </div>

                {/* Return values outputs layout */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  <div className="p-4 bg-indigo-500/5 border border-indigo-500/10 rounded-2xl block text-center">
                    <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-wider block mb-1">
                      {lang === "en" ? "Monthly EMI Payment" : "માસિક હપ્તો (EMI કપાયેલ)"}
                    </span>
                    <p className="text-xl md:text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                      ₹{Math.round(emiRes.emi).toLocaleString("en-IN")}
                    </p>
                  </div>

                  <div className="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-250/30 rounded-2xl block text-center">
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                      {lang === "en" ? "Total Interest Cost" : "કુલ ચૂકવવા પાત્ર વ્યાજ"}
                    </span>
                    <p className="text-xl md:text-2xl font-black font-mono text-slate-700 dark:text-slate-200">
                      ₹{Math.round(emiRes.totalInterest).toLocaleString("en-IN")}
                    </p>
                  </div>

                  <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl block text-center font-bold">
                    <span className="text-[9px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block mb-1">
                      {lang === "en" ? "Total Repayment" : "કુલ ચુકવણી (મુદલ + વ્યાજ)"}
                    </span>
                    <p className="text-xl md:text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                      ₹{Math.round(emiRes.totalPay).toLocaleString("en-IN")}
                    </p>
                  </div>
                </div>

                {/* Micro visual comparative bar */}
                <div className="space-y-1.5 pt-2">
                  <div className="flex justify-between items-center text-[10px] font-bold text-slate-500">
                    <span>{lang === "en" ? "Principal Loan Amount" : "કુલ લોન રકમ (મુદલ)"}</span>
                    <span>{lang === "en" ? "Accumulated Interest" : "કુલ વ્યાજ ખર્ચ"}</span>
                  </div>
                  <div className="w-full h-3 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden flex">
                    <div
                      style={{ width: `${(loanVal / emiRes.totalPay) * 100}%` }}
                      className="h-full bg-indigo-500"
                    ></div>
                    <div
                      style={{ width: `${(emiRes.totalInterest / emiRes.totalPay) * 100}%` }}
                      className="h-full bg-amber-500 animate-pulse"
                    ></div>
                  </div>
                </div>
              </div>
            )}

            {/* --- 5. BMI BODY HEALTH CALCULATOR --- */}
            {activeTabId === "bmi" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Body Weight (kg)" : "શારીરિક વજન (કિલોગ્રામ)"}
                    </label>
                    <input
                      type="number"
                      value={bmiWeight}
                      onChange={(e) => setBmiWeight(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Body Height (cm)" : "ઊંચાઈ (સેન્ટીમીટર)"}
                    </label>
                    <input
                      type="number"
                      value={bmiHeight}
                      onChange={(e) => setBmiHeight(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    />
                  </div>
                </div>

                {bmiRes.bmi > 0 && (
                  <div className="p-6 md:p-8 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 space-y-4">
                    <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                      <div className="text-center md:text-left">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                          {lang === "en" ? "Calculated BMI Score" : "ગણતરી કરેલો BMI સ્કોર"}
                        </span>
                        <p className="text-5xl font-black font-mono text-slate-800 dark:text-white mt-1">
                          {bmiRes.bmi}
                        </p>
                      </div>

                      <div className={`px-5 py-3 rounded-xl border text-center font-bold font-sans text-xs ${bmiRes.color}`}>
                        <span className="block text-[9px] uppercase font-bold tracking-wider opacity-60 mb-0.5">
                          {lang === "en" ? "Health Category" : "આરોગ્ય કેટેગરી"}
                        </span>
                        <span>{lang === "en" ? bmiRes.cat : bmiRes.catGu}</span>
                      </div>
                    </div>

                    {/* Scale tracker visual */}
                    <div className="space-y-1.5 pt-2">
                      <div className="relative w-full h-2.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden flex">
                        {/* Underweight */}
                        <div className="w-[18.5%] h-full bg-amber-400/40"></div>
                        {/* Normal */}
                        <div className="w-[6.5%] h-full bg-emerald-500/40"></div>
                        <div className="w-[5%] h-full bg-orange-400/40"></div>
                        {/* Obese */}
                        <div className="w-[70%] h-full bg-rose-500/40"></div>
                      </div>
                      <div className="flex justify-between items-center text-[8px] md:text-[9px] font-bold text-slate-400 uppercase font-mono tracking-wider">
                        <span>18.5: {lang === "en" ? "Thin" : "પાતળું"}</span>
                        <span>25.0: {lang === "en" ? "Normal" : "સામાન્ય"}</span>
                        <span>30.0: {lang === "en" ? "Obese" : "મેદસ્વીતા"}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* --- 6. RICH TEXT WORDS CALCULATOR --- */}
            {activeTabId === "words" && (
              <div className="space-y-5">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    {lang === "en" ? "Paste Script to Calculate Properties" : "મહત્વપૂર્ણ લખાણ / ફકરો અહીં પેસ્ટ કરો"}
                  </label>
                  <textarea
                    rows={4}
                    value={wordText}
                    onChange={(e) => setWordText(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F4F6F9] dark:bg-[#111726]/60 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold transition"
                    placeholder={lang === "en" ? "Write or parse shorthand transcripts..." : "અહીં ડિકટેશન ટાઈપ કરી નવું સ્પીડ એનાલિસિસ કરો..."}
                  ></textarea>
                </div>

                {/* Counters detailed grid layout */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-3.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center shadow-inner">
                    <p className="text-xl md:text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                      {wordRes.wordsCount}
                    </p>
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Words" : "શબ્દો"}
                    </span>
                  </div>

                  <div className="p-3.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center shadow-inner">
                    <p className="text-xl md:text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                      {wordRes.charsWithSpace}
                    </p>
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Characters" : "અક્ષરો (ખાલી જગ્યા વગર)"}
                    </span>
                  </div>

                  <div className="p-3.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center shadow-inner">
                    <p className="text-xl md:text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                      {wordRes.linesCount}
                    </p>
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Line Breaks" : "લીટીઓ"}
                    </span>
                  </div>

                  <div className="p-3.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-center shadow-inner">
                    <p className="text-xl md:text-2xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                      {wordRes.typeMin} <span className="text-xs font-bold font-sans">Min</span>
                    </p>
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                      {lang === "en" ? "Steno Typing Estimate" : "સ્ટેનો ટ્રાન્સક્રિપ્શન સમય"}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
