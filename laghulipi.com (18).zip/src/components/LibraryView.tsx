import React, { useState } from "react";
import { DatabaseState, BookItem } from "../types";
import { Search, Download, ShoppingBag, Check, CreditCard, Sparkles, X, ChevronRight, BookOpen } from "lucide-react";

interface LibraryViewProps {
  lang: "en" | "gu";
  db: DatabaseState;
  currentUser: any;
}

export default function LibraryView({ lang, db, currentUser }: LibraryViewProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState<"All" | "Free" | "Paid">("All");

  // Purchased paid books list stored in localStorage or react state
  const [purchasedBooks, setPurchasedBooks] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("purchased_books");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Active checkout modal states
  const [activeCheckout, setActiveCheckout] = useState<BookItem | null>(null);
  const [checkoutName, setCheckoutName] = useState(currentUser?.name || "");
  const [checkoutEmail, setCheckoutEmail] = useState(currentUser?.email || "");
  const [checkoutPhone, setCheckoutPhone] = useState("");
  const [cardNo, setCardNo] = useState("4111 2222 3333 4444");
  const [cardExpiry, setCardExpiry] = useState("12/29");
  const [cardCvv, setCardCvv] = useState("123");
  const [isProcessing, setIsProcessing] = useState(false);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);

  const handlePurchaseComplete = () => {
    if (!activeCheckout) return;
    setIsProcessing(true);
    setTimeout(() => {
      const newPurchased = [...purchasedBooks, activeCheckout.id];
      setPurchasedBooks(newPurchased);
      try {
        localStorage.setItem("purchased_books", JSON.stringify(newPurchased));
      } catch (e) {
        console.error(e);
      }
      setIsProcessing(false);
      setCheckoutSuccess(true);
    }, 1500);
  };

  const filteredBooks = db.books.filter((book) => {
    const title = lang === "en" ? book.titleEn : book.titleGu;
    const author = lang === "en" ? book.authorEn : book.authorGu;
    const matchSearch =
      title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      author.toLowerCase().includes(searchTerm.toLowerCase());

    const isBookFree = book.price === 0;
    if (filter === "Free") return matchSearch && isBookFree;
    if (filter === "Paid") return matchSearch && !isBookFree;
    return matchSearch;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="border-b border-slate-100 dark:border-slate-800 pb-5">
        <h1 className="text-3xl font-bold font-serif-literata text-slate-800 dark:text-white">
          {lang === "en" ? "Digital Library" : "ડિજિટલ લાઇબ્રેરી"}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {lang === "en"
            ? "Expand your learning with free premium pdf books and professional dictation guides."
            : "મફત પ્રીમિયમ પીડીએફ પુસ્તકો અને વ્યાવસાયિક શ્રુતલેખન માર્ગદર્શિકાઓ સાથે તમારા શિક્ષણને વિસ્તૃત કરો."}
        </p>
      </div>

      {/* Searching & Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2 max-w-sm rounded-xl bg-white dark:bg-slate-800 px-3 py-2 border border-slate-200 dark:border-slate-700 shadow-sm w-full">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder={lang === "en" ? "Search books/guides..." : "પુસ્તકો શોધો..."}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-transparent text-sm w-full outline-none text-slate-700 dark:text-white"
          />
        </div>

        <div className="flex gap-1.5 p-1 bg-slate-100/80 dark:bg-slate-900/80 rounded-xl w-fit">
          {(["All", "Free", "Paid"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${
                filter === tab
                  ? "bg-white dark:bg-slate-800 text-slate-800 dark:text-white shadow-sm"
                  : "text-slate-500 dark:text-slate-400"
              }`}
            >
              {tab === "All" ? "All" : tab === "Free" ? "Free" : "Paid"}
            </button>
          ))}
        </div>
      </div>

      {/* Books Card grid (compact & high density as requested) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {filteredBooks.map((book) => {
          const isFree = book.price === 0;
          const isPurchased = purchasedBooks.includes(book.id);

          return (
            <div
              key={book.id}
              className="rounded-xl glass-card border border-white/20 dark:border-slate-800/80 p-3 flex flex-col justify-between hover:shadow-lg hover:translate-y-[-2px] transition-all duration-200 group"
            >
              <div className="space-y-2.5">
                {/* Book Cover mock */}
                <div className="relative aspect-[3/4.2] w-full rounded-lg overflow-hidden bg-gradient-to-br from-indigo-150 to-sky-100 dark:bg-slate-800 dark:bg-none flex flex-col justify-between p-3 shadow-inner">
                  {book.coverUrl ? (
                    <img
                      src={book.coverUrl}
                      alt={book.titleEn}
                      referrerPolicy="no-referrer"
                      className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : null}
                  <div className="absolute inset-0 bg-slate-900/40 dark:bg-black/50 pointer-events-none"></div>

                  <div className="relative flex justify-between items-start">
                    <span className={`text-[8px] font-extrabold tracking-wider uppercase px-1.5 py-0.5 rounded ${
                      isFree
                        ? "bg-emerald-500 text-white"
                        : "bg-amber-500 text-slate-950"
                    }`}>
                      {isFree ? (lang === "en" ? "FREE" : "મફત") : `₹ ${book.price}`}
                    </span>
                    <BookOpen className="w-4 h-4 text-white/80" />
                  </div>

                  <div className="relative text-white space-y-0.5">
                    <p className="text-[9px] font-semibold text-slate-300 tracking-wide uppercase">
                      {lang === "en" ? "Author:" : "લેખક:"} {lang === "en" ? book.authorEn : book.authorGu}
                    </p>
                    <h3 className="line-clamp-2 text-xs font-bold font-serif-literata leading-tight drop-shadow">
                      {lang === "en" ? book.titleEn : book.titleGu}
                    </h3>
                  </div>
                </div>

                {/* Description details */}
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-slate-800 dark:text-white line-clamp-1">
                    {lang === "en" ? book.titleEn : book.titleGu}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-tight font-sans">
                    {lang === "en" ? book.descriptionEn : book.descriptionGu}
                  </p>
                </div>
              </div>

              {/* Purchase/Download handles */}
              <div className="pt-2.5 mt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                <span className="text-[10px] font-semibold text-slate-400 font-sans uppercase">
                  {lang === "en" ? "PDF" : "પીડીએફ"}
                </span>

                {isFree ? (
                  <a
                    href={book.fileUrl || "#"}
                    onClick={(e) => {
                      if (!book.fileUrl) {
                        e.preventDefault();
                        alert(
                          lang === "en"
                            ? "This premium PDF is ready. Admin will attach final documents."
                            : "પીડીએફ બુલેટિન સીધા જોવા યોગ્ય છે."
                        );
                      }
                    }}
                    className="flex items-center justify-center gap-1 px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 dark:bg-indigo-950/40 dark:hover:bg-indigo-950/60 dark:text-indigo-400 text-[11px] font-bold rounded-lg transition text-center"
                  >
                    <Download className="w-3 h-3" />
                    <span>{lang === "en" ? "Free" : "ડાઉનલોડ"}</span>
                  </a>
                ) : isPurchased ? (
                  <a
                    href={book.fileUrl || "#"}
                    onClick={(e) => {
                      if (!book.fileUrl) {
                        e.preventDefault();
                        alert(
                          lang === "en"
                            ? "Completed purchase! Download files will be packed in final asset links."
                            : "ખરીદી સફળ! પીડીએફ ફોર્મેટ દસ્તાવેજો ઉપલબ્ધ."
                        );
                      }
                    }}
                    className="flex items-center justify-center gap-1 px-2.5 py-1.5 bg-emerald-50 text-emerald-600 dark:bg-emerald-950/30 dark:text-emerald-400 text-[11px] font-bold rounded-lg transition text-center"
                  >
                    <Check className="w-3 h-3" />
                    <span>{lang === "en" ? "Purchased" : "ઇ-બુક"}</span>
                  </a>
                ) : (
                  <button
                    onClick={() => {
                      setCheckoutSuccess(false);
                      setActiveCheckout(book);
                    }}
                    className="flex items-center justify-center gap-1 px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold rounded-lg transition cursor-pointer text-center"
                  >
                    <ShoppingBag className="w-3 h-3" />
                    <span>{lang === "en" ? "Buy" : "ખરીદો"}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* E-Commerce checkout modal */}
      {activeCheckout && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-md bg-white dark:bg-slate-950 rounded-2xl shadow-2xl overflow-hidden border border-slate-100 dark:border-slate-800">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-gradient-to-br from-indigo-50 to-purple-50 dark:bg-slate-900 dark:bg-none">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <h3 className="font-bold text-slate-800 dark:text-white font-serif-literata text-lg">
                  {lang === "en" ? "Secure Checkout" : "સુરક્ષિત ખરીદી"}
                </h3>
              </div>
              <button
                onClick={() => setActiveCheckout(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content body */}
            <div className="p-6 space-y-4">
              {!checkoutSuccess ? (
                <div className="space-y-4 font-sans text-xs md:text-sm">
                  {/* Ledger product overview */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-900/60 rounded-xl space-y-1.5">
                    <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                      {lang === "en" ? "Purchasing item:" : "ખરીદી વિગત:"}
                    </p>
                    <h4 className="font-bold text-slate-800 dark:text-white font-serif-literata">
                      {lang === "en" ? activeCheckout.titleEn : activeCheckout.titleGu}
                    </h4>
                    <p className="text-slate-500">
                      {lang === "en" ? "By " : "દ્વારા "} {lang === "en" ? activeCheckout.authorEn : activeCheckout.authorGu}
                    </p>
                    <div className="flex justify-between items-center pt-2 border-t border-slate-200/50 dark:border-slate-800/50 mt-2 font-bold text-slate-800 dark:text-white">
                      <span>{lang === "en" ? "Total Price" : "કુલ કિંમત"}</span>
                      <span className="text-indigo-600 dark:text-indigo-400 text-base">₹{activeCheckout.price}</span>
                    </div>
                  </div>

                  {/* Input billing profiles */}
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                      {lang === "en" ? "Billing Name:" : "ગ્રાહકનું નામ:"}
                    </label>
                    <input
                      type="text"
                      className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none text-slate-700 dark:text-white focus:ring-1 focus:ring-indigo-500"
                      value={checkoutName}
                      onChange={(e) => setCheckoutName(e.target.value)}
                      placeholder="e.g. Jitendra Soni"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                        {lang === "en" ? "Email Address:" : "ઇમેઇલ એડ્રેસ:"}
                      </label>
                      <input
                        type="email"
                        className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none text-slate-700 dark:text-white"
                        value={checkoutEmail}
                        onChange={(e) => setCheckoutEmail(e.target.value)}
                        placeholder="info@laghulipi.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">
                        {lang === "en" ? "Phone Number:" : "ફોન નંબર:"}
                      </label>
                      <input
                        type="tel"
                        className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none text-slate-700 dark:text-white"
                        value={checkoutPhone}
                        onChange={(e) => setCheckoutPhone(e.target.value)}
                        placeholder="+91 94283 51731"
                      />
                    </div>
                  </div>

                  {/* Simulated Cards Credentials */}
                  <div className="p-4 rounded-xl border border-dashed border-indigo-100 dark:border-slate-800 space-y-3 bg-indigo-50/20">
                    <div className="flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 text-xs">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span className="font-bold uppercase tracking-wider">{lang === "en" ? "Simulated Payment Details" : "ખરીદી ચૂકવણી માહિતી"}</span>
                    </div>

                    <div className="space-y-2">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase">
                        {lang === "en" ? "Card Number:" : "કાર્ડ નંબર:"}
                      </label>
                      <input
                        type="text"
                        className="w-full text-xs p-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded outline-none text-slate-700 dark:text-white"
                        value={cardNo}
                        onChange={(e) => setCardNo(e.target.value)}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-400 uppercase">
                          Expiry:
                        </label>
                        <input
                          type="text"
                          className="w-full text-xs p-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded outline-none text-slate-700 dark:text-white"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-400 uppercase">
                          CVV:
                        </label>
                        <input
                          type="password"
                          className="w-full text-xs p-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded outline-none text-slate-700 dark:text-white"
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handlePurchaseComplete}
                    disabled={isProcessing}
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-semibold rounded-xl text-sm transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    {isProcessing ? (
                      <span>{lang === "en" ? "Processing secured payment..." : "ચૂકવણી ચકાસણી ચાલુ..."}</span>
                    ) : (
                      <>
                        <ShoppingBag className="w-4 h-4" />
                        <span>{lang === "en" ? `Pay ₹${activeCheckout.price} and Unlock` : `જમા કરો ₹${activeCheckout.price}`}</span>
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <div className="text-center py-6 space-y-4">
                  <div className="mx-auto p-3 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-500 rounded-full w-fit">
                    <Check className="w-8 h-8" />
                  </div>
                  <div className="space-y-1 text-xs md:text-sm">
                    <h4 className="font-bold text-slate-800 dark:text-white font-serif-literata text-base">
                      {lang === "en" ? "Payment Successful!" : "ખરીદી સફળ થઈ!"}
                    </h4>
                    <p className="text-slate-500 dark:text-slate-400">
                      {lang === "en"
                        ? "Thank you for purchasing our premium shorthand guide. Your PDF access is now available."
                        : "અમારા પ્રીમિયમ શોર્ટહેન્ડ ગાઇડ ખરીદવા બદલ આભાર. તમારો ફાઇલ ડાઉનલોડ વિકલ્પ અનલોક થઈ ગયો છે."}
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveCheckout(null)}
                    className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    {lang === "en" ? "Back to Library" : "લાઇબ્રેરી પર પાછા ફરો"}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
