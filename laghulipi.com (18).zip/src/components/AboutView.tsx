import React from "react";
import { DatabaseState } from "../types";
import { Award, Briefcase, Mail, Phone, MapPin, Shield, Star, Users, MessageSquare } from "lucide-react";

interface AboutViewProps {
  lang: "en" | "gu";
  db: DatabaseState;
}

export default function AboutView({ lang, db }: AboutViewProps) {
  const { missionEn, missionGu, pillars, team } = db.aboutUs;

  const iconMap: Record<string, React.ReactNode> = {
    Shield: <Shield className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />,
    Award: <Star className="w-6 h-6 text-amber-500 dark:text-amber-400" />,
    Users: <Users className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
  };

  return (
    <div className="space-y-10 animate-fade-in font-sans">
      <div className="border-b border-slate-100 dark:border-slate-800 pb-5">
        <h1 className="text-3xl font-bold font-serif-literata text-slate-800 dark:text-white">
          {lang === "en" ? "About Us" : "અમારા વિશે"}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          {lang === "en"
            ? "Learn more about our core mission, vision, leaders, and our collective aspirations across Gujarat."
            : "અમારા મૂળ ઉદ્દેશ્યો, સિદ્ધિઓ અને ગુજરાતભરના લઘુલેખકો માટેના લક્ષ્યાંકો જાણો."}
        </p>
      </div>

      {/* Our Mission */}
      <div className="rounded-2xl glass-card p-6 md:p-8 border border-white/20 dark:border-slate-800 space-y-4">
        <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
          <Star className="w-5 h-5 fill-indigo-600 dark:fill-indigo-400" />
          <h2 className="text-lg font-bold font-serif-literata uppercase tracking-wide">
            {lang === "en" ? "Our Mission" : "અમારું મિશન"}
          </h2>
        </div>
        <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed font-sans">
          {lang === "en" ? missionEn : missionGu}
        </p>
      </div>

      {/* Pillars Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {pillars.map((pil) => (
          <div
            key={pil.id}
            className="rounded-xl glass-card p-6 border border-white/20 dark:border-slate-800 flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="p-3 bg-indigo-50 dark:bg-slate-800 rounded-xl w-fit">
                {iconMap[pil.iconName] || <Award className="w-6 h-6 text-indigo-600" />}
              </div>
              <h3 className="text-base font-bold text-slate-800 dark:text-white">
                {lang === "en" ? pil.titleEn : pil.titleGu}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                {lang === "en" ? pil.descEn : pil.descGu}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Leadership Team Layout matches visual perfectly */}
      <div className="space-y-6">
        <h2 className="text-2xl font-bold font-serif-literata text-slate-800 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3 uppercase tracking-wider text-center md:text-left">
          {lang === "en" ? "Leadership Team" : "અગ્રણી ટીમ"}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {team.map((member) => (
            <div
              key={member.id}
              className="rounded-2xl bg-gradient-to-br from-indigo-900 to-slate-900 dark:bg-slate-900 dark:bg-none p-6 text-white relative overflow-hidden group shadow-xl"
            >
              <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
                <Briefcase className="w-48 h-48" />
              </div>

              <div className="relative flex flex-col sm:flex-row items-center gap-6">
                {/* Photo frame with glowing border */}
                <div className="relative shrink-0">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden border-2 border-amber-400 p-0.5 shadow-md">
                    <img
                      src={member.photoUrl}
                      alt={member.nameEn}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover rounded-full group-hover:scale-105 transition duration-300"
                    />
                  </div>
                  <span className="absolute bottom-0 right-1 p-1 bg-amber-400 text-slate-950 rounded-full text-xs shadow">
                    <Award className="w-4 h-4 fill-slate-950" />
                  </span>
                </div>

                <div className="space-y-2 text-center sm:text-left">
                  <h3 className="text-lg font-bold font-serif-literata tracking-wide uppercase text-amber-300">
                    {lang === "en" ? member.nameEn : member.nameGu}
                  </h3>
                  <div className="space-y-0.5">
                    <p className="text-sm font-semibold">{lang === "en" ? member.roleEn : member.roleGu}</p>
                    <p className="text-xs text-slate-300 opacity-90 leading-normal">
                      {lang === "en" ? member.orgEn : member.orgGu}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Communications channels details */}
      <div className="rounded-2xl glass-card p-6 md:p-8 border border-white/20 dark:border-slate-800 space-y-4">
        <h2 className="text-lg font-bold font-serif-literata text-slate-800 dark:text-white uppercase tracking-wider">
          {lang === "en" ? "Interactive Contact channels" : "સંપર્ક સાધનો"}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs md:text-sm font-sans text-slate-600 dark:text-slate-300">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 dark:bg-slate-800 text-indigo-600 rounded-xl">
              <MapPin className="w-5 h-5 shrink-0" />
            </div>
            <div>
              <p className="font-bold">{lang === "en" ? "Address" : "સરનામું"}</p>
              <p className="text-xs opacity-75">{lang === "en" ? db.footer.addressEn : db.footer.addressGu}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 dark:bg-slate-800 text-indigo-600 rounded-xl">
              <Phone className="w-5 h-5 shrink-0" />
            </div>
            <div>
              <p className="font-bold">{lang === "en" ? "Mobile Number" : "મોબાઇલ"}</p>
              <p className="text-xs opacity-75">{db.footer.mobile}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 dark:bg-slate-800 text-indigo-600 rounded-xl">
              <Mail className="w-5 h-5 shrink-0" />
            </div>
            <div>
              <p className="font-bold">{lang === "en" ? "Email Address" : "ઇમેઇલ એડ્રેસ"}</p>
              <p className="text-xs opacity-75">{db.footer.email}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
