import React, { useState } from "react";
import { MessageSquare, Star, X, Send, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface FeedbackWidgetProps {
  lang: "en" | "gu";
}

export default function FeedbackWidget({ lang }: FeedbackWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [message, setMessage] = useState("");

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (!name || !email || !mobile || !message || !rating) {
      setError(lang === "en" ? "Please fill in all parameters." : "કૃપા કરીને બધી માહિતી દાખલ કરો.");
      setLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/feedback/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, mobile, email, rating, message }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Submission failed");
      }

      setSuccess(true);
      // Reset inputs
      setName("");
      setMobile("");
      setEmail("");
      setRating(5);
      setMessage("");
    } catch (err: any) {
      setError(err.message || "Failed submitting feedback.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-40 no-copy-protect">
        <motion.button
          id="btn-floating-feedback"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => {
            setIsOpen(!isOpen);
            if (!isOpen) {
              setSuccess(false);
              setError("");
            }
          }}
          className="flex items-center justify-start h-12 w-12 hover:w-56 md:hover:w-64 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-full shadow-lg transition-all duration-300 ease-in-out cursor-pointer overflow-hidden group px-3.5 hover:px-5 gap-2"
        >
          <MessageSquare className="w-5 h-5 shrink-0 animate-pulse" />
          <span className="whitespace-nowrap transition-all duration-300 opacity-0 group-hover:opacity-100 max-w-0 group-hover:max-w-xs overflow-hidden text-xs md:text-sm">
            {lang === "en" ? "Feedback / Suggestions" : "અભિપ્રાય અને સૂચનો"}
          </span>
        </motion.button>
      </div>

      {/* Slide-over Slider Drawer overlay */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Dark backing overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-slate-950/70 z-40 backdrop-blur-sm"
            />

            {/* Slider Sheet content portal container */}
            <motion.div
              initial={{ y: 100, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 100, opacity: 0, scale: 0.95 }}
              transition={{ type: "spring", damping: 25, stiffness: 280 }}
              className="fixed bottom-22 right-6 w-[92%] sm:w-96 bg-slate-50 dark:bg-[#1e293b] border-2 border-indigo-100 dark:border-indigo-900 rounded-2xl shadow-2xl p-6 z-55 max-h-[80vh] overflow-y-auto no-copy-protect"
            >
              <div className="flex justify-between items-center border-b border-light pb-3">
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                  <h3 className="font-bold font-serif-literata text-base text-slate-800 dark:text-white">
                    {lang === "en" ? "Submit Feedback" : "તમારો અભિપ્રાય મોકલો"}
                  </h3>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {success ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-8 text-center space-y-4"
                >
                  <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-950/30 rounded-full flex items-center justify-center text-emerald-600 mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <div className="space-y-1.5">
                    <p className="font-bold text-slate-800 dark:text-white text-md">
                      {lang === "en" ? "Thank You!" : "ખૂબ ખૂબ આભાર!"}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {lang === "en"
                        ? "Your feedback of quality parameters has been registered safely to support our continuous stenography platform validation."
                        : "તમારો મહત્વપૂર્ણ પ્રતિભાવ સફળતાપૂર્વક સાચવવામાં આવ્યો છે."}
                    </p>
                  </div>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-md"
                  >
                    {lang === "en" ? "Close Dialog" : "સંવાદ બંધ કરો"}
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs md:text-sm">
                  {error && (
                    <div className="p-2.5 bg-rose-50 text-rose-600 border border-rose-100 rounded-lg text-xs leading-relaxed">
                      {error}
                    </div>
                  )}

                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-bold text-slate-400">
                      {lang === "en" ? "Your name:" : "તમારું પૂરું નામ:"}
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      placeholder=""
                      className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-lg outline-none text-slate-700 dark:text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="block text-[10px] uppercase font-bold text-slate-400">
                        {lang === "en" ? "Mobile No:" : "મોબાઇલ નંબર:"}
                      </label>
                      <input
                        type="tel"
                        value={mobile}
                        onChange={(e) => setMobile(e.target.value)}
                        required
                        placeholder=""
                        className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-lg outline-none text-slate-700 dark:text-white font-mono"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] uppercase font-bold text-slate-400">
                        {lang === "en" ? "Email ID:" : "ઇમેઇલ આઈડી:"}
                      </label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        placeholder=""
                        className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-lg outline-none text-slate-700 dark:text-white font-mono"
                      />
                    </div>
                  </div>

                  {/* Rating Stars flow selection */}
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-bold text-slate-400">
                      {lang === "en" ? "Your Steno Platform Rating:" : "લઘુલિપિ પ્લેટફોર્મ રેટિંગ:"}
                    </label>
                    <div className="flex gap-1.5 pt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(null)}
                          onClick={() => setRating(star)}
                          className="focus:outline-none transition shrink-0 cursor-pointer"
                        >
                          <Star
                            className={`w-6 h-6 transition ${
                              star <= (hoverRating !== null ? hoverRating : rating)
                                ? "text-amber-500 fill-amber-500 scale-105"
                                : "text-slate-300 dark:text-slate-700 scale-100 hover:scale-105"
                            }`}
                          />
                        </button>
                      ))}
                      <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 ml-2 self-center font-mono">
                        {(hoverRating !== null ? hoverRating : rating)} / 5 Star
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-bold text-slate-400">
                      {lang === "en" ? "Suggestions / Message:" : "તમારા પ્રશ્નો અથવા સુધારો સૂચવો:"}
                    </label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      required
                      placeholder={lang === "en" ? "Write suggestions here..." : "અહીં તમારી મહત્વપૂર્ણ ટિપ્પણી કરો..."}
                      rows={3}
                      className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-lg outline-none text-slate-700 dark:text-white leading-relaxed resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1 shadow-md"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{loading ? (lang === "en" ? "Submitting..." : "મોકલી રહ્યું છે...") : (lang === "en" ? "Submit Feedback" : "અભિપ્રાય મોકલો")}</span>
                  </button>
                </form>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
