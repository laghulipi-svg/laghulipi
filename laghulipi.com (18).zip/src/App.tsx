import React, { useState, useEffect } from "react";
import { DatabaseState } from "./types";
import HomeView from "./components/HomeView";
import DictationView from "./components/DictationView";
import LibraryView from "./components/LibraryView";
import DirectoryView from "./components/DirectoryView";
import DownloadView from "./components/DownloadView";
import UtilityView from "./components/UtilityView";
import AboutView from "./components/AboutView";
import AdminPanel from "./components/AdminPanel";
import FeedbackWidget from "./components/FeedbackWidget";
import {
  Sun, Moon, Globe, Volume2, BookOpen, Search, Landmark, Award, ShieldCheck, Mail, Phone, MapPin, ExternalLink, Menu, X, ArrowUpRight, ChevronRight, UserCheck, ShieldAlert, Facebook, Twitter, Youtube, Instagram, Linkedin,
  Home, Download, Info
} from "lucide-react";

export default function App() {
  const [db, setDb] = useState<DatabaseState | null>(null);
  const [loading, setLoading] = useState(true);

  // Layout Theme & Language togglers
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    try {
      const saved = localStorage.getItem("theme");
      if (saved) return saved as "light" | "dark";
    } catch {}
    return "light";
  });
  const [lang, setLang] = useState<"en" | "gu">("en");

  // Helper to resolve route values from the browser pathname
  const getViewFromPath = (path: string): "home" | "dictation" | "library" | "directory" | "download" | "utilities" | "about" | "admin" => {
    const cleanPath = path.toLowerCase().trim().replace(/\/$/, "");
    if (cleanPath === "/dictation") return "dictation";
    if (cleanPath === "/library") return "library";
    if (cleanPath === "/directory") return "directory";
    if (cleanPath === "/download" || cleanPath === "/downloads") return "download";
    if (cleanPath === "/utilities" || cleanPath === "/utility") return "utilities";
    if (cleanPath === "/about" || cleanPath === "/about-us") return "about";
    if (cleanPath === "/admin" || cleanPath === "/admin-panel") return "admin";
    return "home";
  };

  // Router view navigator initialized relative to the starting location pathname
  const [currentView, setCurrentView] = useState<
    "home" | "dictation" | "library" | "directory" | "download" | "utilities" | "about" | "admin"
  >(() => {
    try {
      return getViewFromPath(window.location.pathname);
    } catch {
      return "home";
    }
  });

  // Keep browser address bar URL path synchronized with React view status (Single Source of Truth)
  useEffect(() => {
    try {
      const cleanPath = currentView === "home" ? "/" : `/${currentView}`;
      if (window.location.pathname !== cleanPath) {
        window.history.pushState({ view: currentView }, "", cleanPath);
      }
    } catch (e) {
      console.warn("Browser pushState sync skipped:", e);
    }
  }, [currentView]);

  // Listen for native backward/forward history popping triggers
  useEffect(() => {
    const handleBrowserNavigatePop = () => {
      try {
        setCurrentView(getViewFromPath(window.location.pathname));
      } catch {}
    };
    window.addEventListener("popstate", handleBrowserNavigatePop);
    return () => window.removeEventListener("popstate", handleBrowserNavigatePop);
  }, []);

  // Dictation active subtab helper
  const [dictationTab, setDictationTab] = useState<"words" | "paragraphs">("paragraphs");

  // Admin session authentication
  const [currentUser, setCurrentUser] = useState<any>(() => {
    try {
      const saved = sessionStorage.getItem("admin_session");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Mobile menu visibility
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Real-time active live users
  const [activeUsers, setActiveUsers] = useState(() => Math.floor(Math.random() * 8) + 15);

  // Synchronize database state from express server and trigger visitor hit
  useEffect(() => {
    async function initDB() {
      try {
        const response = await fetch(`/api/db?t=${Date.now()}`);
        if (!response.ok) throw new Error("Database fetch error");
        let data = await response.json();
        
        // POST live hit to server to count visits
        const hitResponse = await fetch("/api/visitors/hit", { method: "POST" }).catch(() => null);
        if (hitResponse && hitResponse.ok) {
          const hitData = await hitResponse.json();
          data.siteVisitors = hitData.visitors;
        }
        
        setDb(data);
      } catch (err) {
        console.error("Unable to load db.json state", err);
      } finally {
        setLoading(false);
      }
    }
    initDB();
  }, []);

  // Update active users periodically for a true real-time liveliness feeling
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveUsers((prev) => {
        const delta = Math.random() > 0.5 ? 1 : -1;
        const next = prev + delta;
        return next >= 11 && next <= 29 ? next : prev;
      });
      // Occasionally simulate a real-time new hit incoming to keep total count dynamic
      setDb((prev) => {
        if (!prev) return null;
        if (Math.random() > 0.7) {
          return { ...prev, siteVisitors: prev.siteVisitors + 1 };
        }
        return prev;
      });
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Update theme html node
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    try {
      localStorage.setItem("theme", theme);
    } catch {}
  }, [theme]);

  // Synchronize database state periodically so admin edits dynamically reflect for all users
  useEffect(() => {
    if (currentView === "admin" || currentUser !== null) {
      return; // Pause auto-sync to avoid wiping active CMS modifications
    }

    const syncInterval = setInterval(async () => {
      try {
        const response = await fetch(`/api/db?t=${Date.now()}`);
        if (response.ok) {
          const data = await response.json();
          setDb((prev) => {
            if (!prev) return data;
            // Retain locally incremented/changing dynamic visitor additions gracefully
            return {
              ...data,
              siteVisitors: Math.max(data.siteVisitors || 0, prev.siteVisitors || 0)
            };
          });
        }
      } catch (err) {
        // Soft-skip database fetch interval gaps
      }
    }, 6000); // sync every 6 seconds!
    return () => clearInterval(syncInterval);
  }, [currentView, currentUser]);

  // Handle administrator save interactions
  const handleSaveDB = async (newState: DatabaseState, action: string) => {
    try {
      const response = await fetch("/api/db/save", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          newState,
          operator: currentUser?.email || "Admin",
          action: action || "CMS Content Update",
        }),
      });

      if (!response.ok) throw new Error("Save database failed");
      const savedData = await response.json();
      setDb(savedData.state);
      return savedData.state;
    } catch (err) {
      console.error(err);
      alert("Failed saving database state to backend server.");
      throw err;
    }
  };

  const handleRefreshDB = async () => {
    try {
      const response = await fetch(`/api/db?t=${Date.now()}`);
      if (response.ok) {
        const data = await response.json();
        setDb(data);
        return data;
      }
    } catch (err) {
      console.error("Failed to refresh DB:", err);
    }
  };

  const notifyLogout = () => {
    sessionStorage.removeItem("admin_session");
    setCurrentUser(null);
  };

  const notifyLogin = (user: any) => {
    sessionStorage.setItem("admin_session", JSON.stringify(user));
    setCurrentUser(user);
  };

  if (loading || !db) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center space-y-4">
        <div className="w-10 h-10 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs font-mono text-slate-500 animate-pulse">
          Welcome to LaghuLipi.com
        </p>
      </div>
    );
  }

  // Styling properties for header and menu customize (admin-editable)
  const logoSizeVal = db.header.logoSize || 80;
  const headerBgVal = db.header.headerBg || "";
  const headerTextVal = db.header.headerTextColor || "";
  const menuBgVal = db.header.menuBg || "";
  const menuTextColorVal = db.header.menuTextColor || "";

  const isHeaderBgCss = headerBgVal && (headerBgVal.startsWith("#") || headerBgVal.includes("rgb") || headerBgVal.includes("hsl") || headerBgVal.includes("gradient") || headerBgVal.startsWith("linear-") || headerBgVal.startsWith("radial-"));
  const isHeaderTextCss = headerTextVal && (headerTextVal.startsWith("#") || headerTextVal.includes("rgb") || headerTextVal.includes("hsl"));
  const isMenuBgCss = menuBgVal && (menuBgVal.startsWith("#") || menuBgVal.includes("rgb") || menuBgVal.includes("hsl") || menuBgVal.includes("gradient") || menuBgVal.startsWith("linear-") || menuBgVal.startsWith("radial-"));
  const isMenuTextCss = menuTextColorVal && (menuTextColorVal.startsWith("#") || menuTextColorVal.includes("rgb") || menuTextColorVal.includes("hsl"));

  const getSocialIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "facebook": return <Facebook className="w-4 h-4" />;
      case "twitter": return <Twitter className="w-4 h-4" />;
      case "youtube": return <Youtube className="w-4 h-4" />;
      case "instagram": return <Instagram className="w-4 h-4" />;
      case "linkedin": return <Linkedin className="w-4 h-4" />;
      default: return <ArrowUpRight className="w-4 h-4" />;
    }
  };

  // Multi-lingual terminology tags picker
  const navLabels = {
    home: lang === "en" ? "Home" : "મુખ્ય પૃષ્ઠ",
    dictation: lang === "en" ? "Dictation" : "શ્રુતલેખન",
    library: lang === "en" ? "Library" : "પુસ્તકાલય",
    directory: lang === "en" ? "Directory" : " નિર્દેશિકા",
    download: lang === "en" ? "Download" : "ડાઉનલોડ ",
    utilities: lang === "en" ? "Utilities" : "ઉપયોગિતાઓ",
    about: lang === "en" ? "About Us" : "અમારા વિશે",
    admin: lang === "en" ? "Sign in" : "એડમિન પેનલ",
  };

  const navIcons: Record<string, React.ReactNode> = {
    home: <Home className="w-4 h-4" />,
    dictation: <Volume2 className="w-4 h-4" />,
    library: <BookOpen className="w-4 h-4" />,
    directory: <Landmark className="w-4 h-4" />,
    download: <Download className="w-4 h-4" />,
    utilities: <Globe className="w-4 h-4" />,
    about: <Info className="w-4 h-4" />,
    admin: <UserCheck className="w-4 h-4" />,
  };

  const navColors: Record<string, { bg: string, text: string }> = {
    home: { bg: "bg-blue-500/10 text-blue-600 dark:text-blue-400", text: "text-blue-500" },
    dictation: { bg: "bg-rose-500/10 text-rose-600 dark:text-rose-400", text: "text-rose-500" },
    library: { bg: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400", text: "text-emerald-500" },
    directory: { bg: "bg-amber-500/10 text-amber-600 dark:text-amber-400", text: "text-amber-500" },
    download: { bg: "bg-purple-500/10 text-purple-600 dark:text-purple-400", text: "text-purple-500" },
    utilities: { bg: "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400", text: "text-indigo-500" },
    about: { bg: "bg-teal-500/10 text-teal-600 dark:text-teal-400", text: "text-teal-500" },
    admin: { bg: "bg-slate-500/10 text-slate-600 dark:text-slate-400", text: "text-slate-500" },
  };

  const navSubtitles: Record<string, { en: string, gu: string }> = {
    home: { en: "Home Dashboard", gu: "મુખ્ય ડેશબોર્ડ" },
    dictation: { en: "Shorthand Audios", gu: "શ્રુતલેખન ઓડિયો" },
    library: { en: "E-Books & Outlines", gu: "ઈ-પુસ્તકો સંસાધન" },
    directory: { en: "Administrative Directory", gu: "વહીવટી સંપર્ક યાદી" },
    download: { en: "Syllabus & Linebooks", gu: "અભ્યાસક્રમ અને પીડીએફ" },
    utilities: { en: "Speed Calculators", gu: "સ્પીડ કેલ્ક્યુલેટર્સ" },
    about: { en: "Pillars & Tutors Info", gu: "અમારા સ્તંભો અને ટીમ" },
    admin: { en: "Portal Content CMS", gu: "એડમિન કન્ટેન્ટ મેનેજર" },
  };

  return (
    <div className={`min-h-screen bg-[#F4F6F9] dark:bg-[#090D16] text-slate-800 dark:text-slate-100 flex flex-col selection:bg-indigo-200 ${lang === 'gu' ? 'font-gujarati' : ''}`}>
      
      {/* 1. STICKY GLASSMORPHIC HEADER */}
      <header 
        style={{
          background: isHeaderBgCss ? headerBgVal : undefined,
          color: isHeaderTextCss ? headerTextVal : undefined,
        }}
        className={`sticky top-0 z-40 w-full backdrop-blur-md border-b border-white/20 dark:border-slate-800/60 shadow-sm transition ${
          !isHeaderBgCss ? (headerBgVal || "bg-white/70 dark:bg-[#0e1424]/75") : ""
        } ${
          !isHeaderTextCss ? (headerTextVal || "text-slate-800 dark:text-white") : ""
        }`}
      >
        <div className="w-full px-6 md:px-10 py-4 flex items-center justify-between">
          
          {/* Logo Brand info */}
          <div 
            onClick={() => setCurrentView("home")}
            className="flex items-center gap-4 cursor-pointer select-none active:opacity-85 transition-opacity duration-150 hover:opacity-95"
            title={lang === "en" ? "Go to Home" : "હોમ પેજ પર જાઓ"}
          >
            <div 
              style={{ width: `min(100%, ${logoSizeVal}px)`, height: `min(100%, ${logoSizeVal}px)` }}
              className="max-w-[48px] sm:max-w-[64px] md:max-w-none max-h-[48px] sm:max-h-[64px] md:max-h-none rounded-xl md:rounded-2xl overflow-hidden bg-white/10 p-0.5 border border-white/20 dark:border-slate-700 shadow-md shrink-0 flex items-center justify-center transition-all duration-300"
            >
              <img
                src={db.header.logoUrl || "https://laghulipi.com/logo.png"}
                alt="LaghuLipi.com"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  // Fallback beautiful handwriting logo preview
                  (e.target as HTMLElement).style.display = "none";
                }}
                className="w-full h-full object-contain"
              />
            </div>
            <div className="space-y-2.5">
              <h1 className="text-md sm:text-lg md:text-2xl lg:text-3xl font-extrabold font-serif-literata tracking-wide leading-tight">
                {lang === "en" ? db.header.titleEn : db.header.titleGu}
              </h1>
              <p className="text-[9px] sm:text-[10px] md:text-sm font-semibold italic tracking-wider opacity-90 leading-tight">
                {lang === "en" ? db.header.taglineEn : db.header.taglineGu}
              </p>
            </div>
          </div>

          {/* Right Action buttons */}
          <div className="flex items-center gap-3">
            {/* Theme switcher */}
            <button
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className="p-3 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-slate-100 dark:border-slate-800 text-slate-600 dark:text-amber-400 cursor-pointer shadow-sm hover:scale-105 transition"
              title="Toggle Light/Dark Theme"
            >
              {theme === "light" ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </button>

            {/* Language Toggle */}
            <button
              onClick={() => setLang(lang === "en" ? "gu" : "en")}
              className="px-4 py-3 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-slate-100 dark:border-slate-800 text-slate-600 dark:text-indigo-400 cursor-pointer text-xs font-bold shadow-sm flex items-center gap-1.5 hover:scale-105 transition"
              title="Toggle Language"
            >
              <Globe className="w-4 h-4" />
              <span>{lang === "en" ? "ગુજરાતી" : "English"}</span>
            </button>

            {/* Mobile Nav Menu */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-3 bg-white/80 dark:bg-slate-900/85 border border-slate-100 dark:border-slate-800 rounded-xl lg:hidden text-slate-600 dark:text-slate-200 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* 2. MENU BAR (HORIZONTAL PAGE NAVIGATION) */}
        <nav 
          style={{
            background: isMenuBgCss ? menuBgVal : undefined,
            color: isMenuTextCss ? menuTextColorVal : undefined,
          }}
          className={`w-full border-t border-b border-white/10 dark:border-slate-850 px-6 md:px-10 py-1.5 lg:block hidden ${
            !isMenuBgCss ? (menuBgVal || "bg-[#EAEFF5]/80 dark:bg-[#0c101d]/60") : ""
          } ${
            !isMenuTextCss ? (menuTextColorVal || "text-slate-700 dark:text-slate-200") : ""
          }`}
        >
          <div className="flex items-center gap-1.5 overflow-x-auto text-[13px] md:text-sm font-sans font-bold no-scrollbar py-1">
            {(["home", "dictation", "library", "directory", "download", "utilities", "about", "admin"] as const).map((view) => {
              const active = currentView === view;
              return (
                <button
                  key={view}
                  onClick={() => setCurrentView(view)}
                  style={{
                    color: active ? undefined : (isMenuTextCss ? menuTextColorVal : undefined)
                  }}
                  className={`px-4 py-2 rounded-lg cursor-pointer transition-all duration-200 ease-in-out hover:-translate-y-0.5 active:translate-y-0 active:scale-95 ${
                    active
                      ? "bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-md shadow-indigo-100/40 dark:shadow-none"
                      : "hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-white/80 dark:hover:bg-slate-800/40"
                  }`}
                >
                  {navLabels[view]}
                </button>
              );
            })}
          </div>
        </nav>
      </header>

      {/* MOBILE DRILLDOWN MENU BAR */}
      {mobileMenuOpen && (
        <div className="lg:hidden w-full bg-white/95 dark:bg-[#0e1424] border-b border-light flex flex-col p-4 space-y-2 z-30 font-sans font-bold animate-fade-in text-sm">
          {(["home", "dictation", "library", "directory", "download", "utilities", "about", "admin"] as const).map((view) => {
            const active = currentView === view;
            return (
              <button
                key={view}
                onClick={() => {
                  setCurrentView(view);
                  setMobileMenuOpen(false);
                }}
                className={`py-2.5 px-4 rounded-xl text-left cursor-pointer transition-all duration-150 ${
                  active 
                    ? "bg-indigo-600 text-white font-bold" 
                    : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/50 hover:text-indigo-600 dark:hover:text-indigo-400 pl-6"
                }`}
              >
                {navLabels[view]}
              </button>
            );
          })}
        </div>
      )}

      {/* 3. MULTI-PANEL GRID LAYOUT */}
      <main className={`flex-1 w-full px-4 md:px-10 py-6 grid grid-cols-1 ${currentView === "admin" ? "" : "lg:grid-cols-12"} gap-8`}>
        
        {/* LEFT COMPACT PANEL (Updates & Quick Links side panels) */}
        {currentView !== "admin" && (
          <aside className="lg:col-span-3 order-2 lg:order-1 space-y-6 flex flex-col">
          
          {currentView === "home" ? (
            <>
              {/* Ticker Notifications panel */}
              <div className="rounded-2xl glass-card p-5 border border-white/30 dark:border-slate-800/80 flex flex-col h-[525px] justify-between relative overflow-hidden bg-white/20 dark:bg-slate-900/10">
                
                {/* Header */}
                <div>
                  <div className="flex items-center gap-2 border-b border-light dark:border-slate-800 pb-3">
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-ping"></span>
                    <h2 className="text-md font-bold text-slate-800 dark:text-white font-serif-literata tracking-wide uppercase">
                      {lang === "en" ? "Latest News" : "નવીનતમ સમાચાર"}
                    </h2>
                  </div>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 uppercase font-semibold font-sans">
                    {lang === "en" ? "General Information" : ";સામાન્ય માહિતી"}
                  </p>
                </div>

                {/* Continuous bottom-to-top custom scrolling announcement board container (Selected Element - Styled Colourful) */}
                <div className="flex-1 overflow-hidden relative my-4 border border-indigo-100 dark:border-indigo-950/60 rounded-2xl bg-gradient-to-b from-indigo-500/5 via-purple-500/5 to-rose-500/5 dark:bg-[#0c101d] dark:bg-none p-2.5 select-none z-10 shadow-inner">
                  <div className="absolute inset-x-0 top-0 h-4 bg-gradient-to-b from-[#F4F6F9] dark:from-[#090D16] to-transparent pointer-events-none z-20"></div>
                  <div className="absolute inset-x-0 bottom-0 h-4 bg-gradient-to-t from-[#F4F6F9] dark:from-[#090D16] to-transparent pointer-events-none z-20"></div>

                  {/* Infinite Scrolling Ticker Area */}
                  <div className="animate-scroll-up space-y-4 py-6">
                    {[...db.updates, ...db.updates].map((item, idx) => (
                      <div
                        key={item.id + "_" + idx}
                        onClick={() => {
                          if (item.pdfUrl) {
                            window.open(item.pdfUrl, "_blank");
                          }
                        }}
                        className={`p-3 bg-white/80 dark:bg-slate-900 border border-slate-100 dark:border-slate-850 rounded-xl space-y-1.5 shadow-sm transform transition-all duration-200 ${
                          item.pdfUrl 
                            ? "cursor-pointer hover:border-indigo-400 hover:shadow-md hover:scale-[1.01] active:scale-[0.99]" 
                            : ""
                        }`}
                      >
                        <div className="flex justify-between items-center text-[10px] font-mono text-indigo-500 font-bold">
                          <span>REF: #{item.id.substring(3, 7)}</span>
                          <span>{item.date}</span>
                        </div>

                        <p className="text-xs font-semibold leading-relaxed text-slate-700 dark:text-slate-200">
                          {lang === "en" ? item.textEn : item.textGu}
                        </p>

                        <div className="flex items-center justify-between pt-1">
                          {item.pdfUrl ? (
                            <span 
                              className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-600 hover:underline"
                              title="Click to open official PDF document"
                            >
                              <span className="bg-rose-500 text-white rounded px-1 text-[8px] font-sans font-extrabold tracking-wider">PDF</span>
                              <span>{lang === "en" ? "Open Circular" : "પરિપત્ર જુઓ"}</span>
                            </span>
                          ) : (
                            <span className="text-[9px] text-slate-400 font-sans">
                              {lang === "en" ? "Plain Bulletin" : "માહિતી પત્રક"}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Info footer */}
                <div className="text-[10px] text-slate-400 bg-slate-100/50 dark:bg-slate-900/60 p-2 rounded-lg leading-relaxed text-center font-sans tracking-wide">
                  {lang === "en"
                    ? "Click on any News update to view."
                    : "કોઈપણ સમાચાર અપડેટ જોવા માટે તેના પર ક્લિક કરો."}
                </div>
              </div>

              {/* iOS block-styled Quick Links panel */}
              <div className="rounded-2xl glass-card p-5 border border-white/30 dark:border-slate-800/80 flex flex-col space-y-3 relative bg-white/20 dark:bg-slate-900/10 shadow-sm animate-fade-in animate-duration-300">
                <div>
                  <div className="flex items-center gap-2 border-b border-light dark:border-slate-800 pb-3">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    <h2 className="text-md font-bold text-slate-800 dark:text-white font-serif-literata tracking-wide uppercase">
                      {lang === "en" ? "Quick Links" : "ઝડપી લિંક્સ"}
                    </h2>
                  </div>
                </div>

                <div className="space-y-2.5 mt-2">
                  {db.quickLinks.map((item) => (
                    <a
                      key={item.id}
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-between p-2.5 bg-white/70 dark:bg-slate-900/70 hover:bg-indigo-50/50 dark:hover:bg-slate-800/70 rounded-xl border border-slate-100/60 dark:border-slate-800/60 transition group cursor-pointer shadow-sm"
                    >
                      <div className="flex items-center gap-2.5">
                        {/* iOS mini circular color plate icon */}
                        <div className="w-7 h-7 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 shadow-inner">
                          <ExternalLink className="w-3.5 h-3.5" />
                        </div>
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-200 group-hover:text-amber-500 dark:group-hover:text-indigo-400 transition">
                          {lang === "en" ? item.nameEn : item.nameGu}
                        </span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition" />
                    </a>
                  ))}
                </div>
              </div>
            </>
          ) : (
            /* Elegant Vertical Page Navigation Panel */
            <div className="rounded-2xl glass-card p-5 border border-white/30 dark:border-slate-800/80 flex flex-col space-y-4 relative bg-white/20 dark:bg-slate-900/10 shadow-sm animate-fade-in animate-duration-300">
               {/* Header */}
               <div className="border-b border-light dark:border-slate-800 pb-3">
                 <div className="flex items-center gap-2">
                   <div className="w-2.5 h-2.5 rounded-full bg-indigo-600 dark:bg-indigo-400 animate-pulse"></div>
                   <h2 className="text-md font-bold text-slate-800 dark:text-white font-serif-literata tracking-wide uppercase">
                     {lang === "en" ? "Page Navigation" : "વિભાગ નેવિગેશન"}
                   </h2>
                 </div>
                 <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 uppercase font-semibold font-sans">
                   {lang === "en" ? "Quick Section Explorer" : "ઝડપી વિભાગ સંશોધક"}
                 </p>
               </div>

               {/* Navigation buttons list */}
               <div className="space-y-2">
                 {(["home", "dictation", "library", "directory", "download", "utilities", "about", "admin"] as const).map((view) => {
                   const active = currentView === view;
                   return (
                     <button
                       key={view}
                       onClick={() => setCurrentView(view)}
                       className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all duration-200 group text-left cursor-pointer ${
                         active
                           ? "bg-indigo-600 border-indigo-600/20 text-white shadow-md font-bold"
                           : "bg-white/75 dark:bg-slate-900/60 hover:bg-indigo-50/50 dark:hover:bg-slate-800/60 border-slate-100/60 dark:border-slate-800/60 text-slate-700 dark:text-slate-200 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98]"
                       }`}
                     >
                       <div className="flex items-center gap-3">
                         {/* Mini circular colored panel for active/inactive state */}
                         <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 shadow-sm transition-all duration-300 ${
                           active ? "bg-white/20 text-white" : navColors[view].bg
                         }`}>
                           {navIcons[view]}
                         </div>
                         <div>
                           <p className={`text-xs font-bold leading-tight ${active ? "text-white" : "text-slate-700 dark:text-slate-200"}`}>
                             {navLabels[view]}
                           </p>
                           <p className={`text-[9px] mt-0.5 font-medium tracking-wide ${active ? "text-white/80" : "text-slate-400"}`}>
                             {lang === "en" ? navSubtitles[view].en : navSubtitles[view].gu}
                           </p>
                         </div>
                       </div>
                       <ChevronRight className={`w-3.5 h-3.5 transition ${active ? "text-white hover:translate-x-0.5" : "text-slate-404 group-hover:text-indigo-500 group-hover:translate-x-0.5"}`} />
                     </button>
                   );
                 })}
               </div>
            </div>
          )}
          </aside>
        )}

      {/* RIGHT CORE AREA (Navigation views router dispatcher) */}
      <section className={`${currentView === "admin" ? "col-span-12" : "lg:col-span-9"} order-1 lg:order-2 space-y-6`}>
          <div className="w-full">
            
            {currentView === "home" && (
              <HomeView
                lang={lang}
                db={db}
                setView={(v) => setCurrentView(v as any)}
                setDictationTab={setDictationTab}
              />
            )}
            
            {currentView === "dictation" && (
              <DictationView
                lang={lang}
                db={db}
                activeTab={dictationTab}
                setActiveTab={setDictationTab}
                currentUser={currentUser}
                onSaveDB={handleSaveDB}
              />
            )}
            
            {currentView === "library" && <LibraryView lang={lang} db={db} currentUser={currentUser} />}
            
            {currentView === "directory" && <DirectoryView lang={lang} db={db} />}
            
            {currentView === "download" && <DownloadView lang={lang} db={db} />}
            
            {currentView === "utilities" && <UtilityView lang={lang} db={db} />}
            
            {currentView === "about" && <AboutView lang={lang} db={db} />}
            
            {currentView === "admin" && (
              <AdminPanel
                lang={lang}
                db={db}
                currentUser={currentUser}
                onLogin={notifyLogin}
                onLogout={notifyLogout}
                onSaveDB={handleSaveDB}
                onRefreshDB={handleRefreshDB}
              />
            )}
          </div>
        </section>
      </main>

      {/* 4. DESIGNED FOOTER */}
      <footer 
        style={{
          background: isHeaderBgCss ? headerBgVal : undefined,
          color: isHeaderTextCss ? headerTextVal : undefined,
        }}
        className={`mt-12 font-sans border-t border-slate-200 dark:border-slate-800 transition ${
          !isHeaderBgCss ? (headerBgVal || "bg-slate-900 text-white") : ""
        } ${
          !isHeaderTextCss ? (headerTextVal || "text-white") : ""
        }`}
      >

        

        {/* Foot bottom details */}
        <div className="w-full px-6 md:px-10 py-3.5 flex flex-col md:flex-row items-center justify-between text-xs opacity-85 gap-4">
          
          {/* Left Column: Brand name and description */}
          <div className="text-center md:text-left md:w-[35%] space-y-1">
            <h3 className="text-sm font-extrabold opacity-95 font-serif-literata tracking-wide text-indigo-300 dark:text-indigo-400">LaghuLipi.com</h3>
            <p className="text-[11px] opacity-75 leading-relaxed max-w-xs md:max-w-sm mx-auto md:mx-0 font-sans">
              {lang === "en"
                ? "A leading platform dedicated to technical excellence and professional welfare of stenographers, reporters, and shorthand professionals in Gujarat."
                : "ગુજરાતમાં સ્ટેનોગ્રાફર્સ, રિપોર્ટર્સ અને શોર્ટહેન્ડ વ્યાવસાયિકોના ટેકનિકલ શ્રેષ્ઠતા અને વ્યાવસાયિક કલ્યાણ માટે સમર્પિત એક અગ્રણી પ્લેટફોર્મ."}
            </p>
          </div>

          {/* Visitors statistics and social channels perfectly centered in middle */}
          <div className="flex flex-col items-center justify-center gap-2.5 mx-auto">
            <div className="flex flex-wrap items-center justify-center gap-2.5">
              <div className="flex gap-1.5 bg-slate-950 px-2 py-1 rounded border border-slate-800 shadow-inner items-center text-[10px]">
                <span className="text-[9px] text-slate-400">SITE VISITORS:</span>
                <span className="font-mono text-emerald-400 font-bold tracking-widest">{db.siteVisitors.toLocaleString()}</span>
              </div>

              {/* Realtime Live active users counter */}
              <div className="flex items-center gap-1.5 bg-slate-950/60 px-2 py-1 rounded border border-slate-800 shadow-sm text-[10px]">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                </span>
                <span className="text-[9px] text-slate-300 font-medium tracking-wider font-sans">
                  {lang === "en" ? `${activeUsers} LIVE` : `${activeUsers} સક્રિય`}
                </span>
              </div>
            </div>

            {/* Social handles links styled with authentic original brand logo themes */}
            <div className="flex items-center justify-center gap-2">
              {db.socialLinks.map((item) => {
                let brandClass = "bg-slate-800 text-slate-300 hover:bg-indigo-600 hover:text-white";
                switch (item.platform.toLowerCase()) {
                  case "facebook":
                    brandClass = "bg-[#1877F2] text-white hover:bg-[#145dbf]";
                    break;
                  case "youtube":
                    brandClass = "bg-[#FF0000] text-white hover:bg-[#cc0000]";
                    break;
                  case "twitter":
                  case "x":
                    brandClass = "bg-[#090D16] text-white hover:bg-slate-800 border border-slate-800";
                    break;
                  case "instagram":
                    brandClass = "bg-gradient-to-tr from-[#fdf497] via-[#d62976] to-[#4f5bd5] text-white hover:opacity-90";
                    break;
                  case "linkedin":
                    brandClass = "bg-[#0077B5] text-white hover:bg-[#005a87]";
                    break;
                }
                return (
                  <a
                    key={item.id}
                    href={item.url}
                    target="_blank"
                    rel="noreferrer"
                    className={`p-1.5 ${brandClass} rounded-lg transition-transform hover:scale-105 active:scale-95 cursor-pointer flex items-center justify-center`}
                    title={`Follow us on ${item.platform}`}
                  >
                    {getSocialIcon(item.platform)}
                  </a>
                );
              })}
            </div>
          </div>

          {/* Right Column: Communications and copyright aligned on the right side */}
          <div className="text-center md:text-right md:w-[35%] space-y-1.5">
            <div className="flex flex-col md:items-end space-y-0.5">
              <p className="font-extrabold text-indigo-300 dark:text-indigo-400 font-sans text-[10px] uppercase tracking-wider">
                {lang === "en" ? "Communications" : "સંપર્ક માહિતી"}
              </p>
              <p className="font-sans text-[11px] font-semibold opacity-95 flex flex-wrap items-center justify-center md:justify-end gap-1.5">
                <span>+91 9428351731</span>
                <span className="opacity-40">•</span>
                <span>info@laghulipi.com</span>
              </p>
            </div>
            
            <p className="opacity-75 font-sans text-[10.5px] leading-relaxed border-t border-slate-200/10 dark:border-slate-800/20 pt-1">
              © 2026 LaghuLipi.com | All Rights Reserved | Designed by Jitendra Soni.
            </p>
          </div>
        </div>
      </footer>
      <FeedbackWidget lang={lang} />
    </div>
  );
}
